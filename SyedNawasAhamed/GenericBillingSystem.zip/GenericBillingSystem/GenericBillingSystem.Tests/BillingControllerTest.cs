﻿using System;
using System.Collections.Generic;
using NUnit.Framework;
using System.Reflection;
using GenericBillingSystem.Models;
using System.Web.Mvc;
using System.Linq;
using System.Collections.Specialized;
using System.Globalization;
using System.ComponentModel.DataAnnotations;

namespace GenericBillingSystem.Tests
{
    [TestFixture]
    public class BillingControllerTest
    {
        Assembly assembly = Assembly.Load("GenericBillingSystem");
        Type BillingControllerClass;

        [Test]
        public void Test_IndexMethod_ReturnsLiveProductList()
        {
            var allBindings = BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;
            BillingDBContext db = new BillingDBContext();
            try
            {
                BillingControllerClass = assembly.GetType("GenericBillingSystem.Controllers.BillingController");
                if (BillingControllerClass != null)
                {
                    MethodInfo IndexMethod = BillingControllerClass.GetMethod("Index", allBindings);
                    Assert.IsNotNull(IndexMethod, "Action 'Index' NOT implemented OR check spelling");
                    Assert.AreEqual(typeof(ActionResult), IndexMethod.ReturnType, "Action 'Index' return type MUST be 'ActionResult'");

                    ConstructorInfo classConstructor = BillingControllerClass.GetConstructor(Type.EmptyTypes);
                    object BillingControllerclassObject = classConstructor.Invoke(new object[] { });

                    var viewResult = (ViewResult)IndexMethod.Invoke(BillingControllerclassObject, new object[] { });
                    var productslist = (IEnumerable<GenericBillingSystem.Models.Product>)viewResult.ViewData.Model;

                    int productscount = db.Products.Where(x => x.Status == ProductStatus.Live).Count();
                    Assert.AreEqual(productslist.Count(), productscount);
                }
                else
                    Assert.Fail("No class with the name 'BillingController' is implemented OR Did you change the class name");
            }
            catch (Exception ex)
            {
                Assert.Fail("Exception should not be thrown. Please check the application logic");
            }
        }

        [Test]
        public void Test_ListBySearchMethod_ReturnsSearchedLiveProductList()
        {
            var allBindings = BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;
            BillingDBContext db = new BillingDBContext();
            try
            {
                BillingControllerClass = assembly.GetType("GenericBillingSystem.Controllers.BillingController");
                if (BillingControllerClass != null)
                {
                    MethodInfo ListBySearchMethod = BillingControllerClass.GetMethod("ListBySearch", allBindings);
                    Assert.IsNotNull(ListBySearchMethod, "Action 'ListBySearch' NOT implemented OR check spelling");
                    Assert.AreEqual(typeof(ActionResult), ListBySearchMethod.ReturnType, "Action 'Index' return type MUST be 'ActionResult'");

                    ConstructorInfo classConstructor = BillingControllerClass.GetConstructor(Type.EmptyTypes);
                    object BillingControllerclassObject = classConstructor.Invoke(new object[] { });

                    Product firstproduct = db.Products.Where(x => x.Status == ProductStatus.Live).FirstOrDefault();
                    string productSearch = "";
                    if (firstproduct != null)
                    {
                        productSearch = firstproduct.ProdName;
                    }

                    var viewResult = (ViewResult)ListBySearchMethod.Invoke(BillingControllerclassObject, new object[] { productSearch });
                    var productslist = (IEnumerable<GenericBillingSystem.Models.Product>)viewResult.ViewData.Model;

                    int productscount = db.Products.Where(x => x.Status == ProductStatus.Live && x.ProdName.Contains(productSearch)).Count();
                    Assert.AreEqual(productslist.Count(), productscount);
                }
                else
                    Assert.Fail("No class with the name 'BillingController' is implemented OR Did you change the class name");
            }
            catch (Exception ex)
            {
                Assert.Fail("Exception should not be thrown. Please check the application logic");
            }
        }

        [Test]
        public void Test_AddItemtoCartMethod_AddItemstoCart()
        {
            var allBindings = BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;
            BillingDBContext db = new BillingDBContext();
            try
            {
                BillingControllerClass = assembly.GetType("GenericBillingSystem.Controllers.BillingController");
                if (BillingControllerClass != null)
                {
                    MethodInfo AddItemtoCartMethod = BillingControllerClass.GetMethod("AddItemtoCart", allBindings);
                    Assert.IsNotNull(AddItemtoCartMethod, "Action 'AddItemtoCart' NOT implemented OR check spelling");
                    Assert.AreEqual(typeof(ActionResult), AddItemtoCartMethod.ReturnType, "Action 'Index' return type MUST be 'ActionResult'");

                    ConstructorInfo classConstructor = BillingControllerClass.GetConstructor(Type.EmptyTypes);
                    object BillingControllerclassObject = classConstructor.Invoke(new object[] { });

                    NameValueCollection nvc1 = new NameValueCollection();
                    nvc1.Add("item.ProductCode", "1");
                    nvc1.Add("item.ProdName", "Badam");
                    nvc1.Add("item.Units", "0");
                    nvc1.Add("item.Price", "150");
                    nvc1.Add("txtQty", "2");
                    FormCollection formCollection1 = new FormCollection(nvc1);
                    NameValueCollection nvc2 = new NameValueCollection();
                    nvc2.Add("item.ProductCode", "2");
                    nvc2.Add("item.ProdName", "Walnut");
                    nvc2.Add("item.Units", "0");
                    nvc2.Add("item.Price", "1500");
                    nvc2.Add("txtQty", "1");
                    FormCollection formCollection2 = new FormCollection(nvc2);
                    int caritemcount = 2;

                    var viewResult1 = (RedirectToRouteResult)AddItemtoCartMethod.Invoke(BillingControllerclassObject, new object[] { formCollection1 });
                    Assert.AreEqual(viewResult1.RouteValues["action"].Equals("Index"), true);
                    var viewResult2 = (RedirectToRouteResult)AddItemtoCartMethod.Invoke(BillingControllerclassObject, new object[] { formCollection2 });
                    Assert.AreEqual(viewResult2.RouteValues["action"].Equals("Index"), true);

                    FieldInfo cartlistFieldinfo = (FieldInfo)BillingControllerClass.GetMember("cartItemsList").GetValue(0);
                    List<CartItem> cartlistobject = (List<CartItem>)cartlistFieldinfo.GetValue(BillingControllerclassObject);
                    Assert.AreEqual(cartlistobject.Count(), caritemcount);
                }
                else
                    Assert.Fail("No class with the name 'BillingController' is implemented OR Did you change the class name");
            }
            catch (Exception ex)
            {
                Assert.Fail("Exception should not be thrown. Please check the application logic");
            }
        }

        [Test]
        public void Test_CheckOutMethod_SavesItemstoDatabase()
        {
            var allBindings = BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;
            BillingDBContext db = new BillingDBContext();
            try
            {
                BillingControllerClass = assembly.GetType("GenericBillingSystem.Controllers.BillingController");
                if (BillingControllerClass != null)
                {
                    MethodInfo AddItemtoCartMethod = BillingControllerClass.GetMethod("AddItemtoCart", allBindings);
                    Assert.IsNotNull(AddItemtoCartMethod, "Action 'AddItemtoCart' NOT implemented OR check spelling");
                    Assert.AreEqual(typeof(ActionResult), AddItemtoCartMethod.ReturnType, "Action 'Index' return type MUST be 'ActionResult'");

                    ConstructorInfo classConstructor = BillingControllerClass.GetConstructor(Type.EmptyTypes);
                    object BillingControllerclassObject = classConstructor.Invoke(new object[] { });

                    FieldInfo cartlistFieldinfo = (FieldInfo)BillingControllerClass.GetMember("cartItemsList").GetValue(0);
                    List<CartItem> cartlistobject = (List<CartItem>)cartlistFieldinfo.GetValue(BillingControllerclassObject);
                    cartlistobject.Clear();

                    // added items to cart
                    NameValueCollection nvc1 = new NameValueCollection();
                    nvc1.Add("item.ProductCode", "1");
                    nvc1.Add("item.ProdName", "Badam");
                    nvc1.Add("item.Units", "0");
                    nvc1.Add("item.Price", "150");
                    nvc1.Add("txtQty", "2");
                    FormCollection formCollection1 = new FormCollection(nvc1);
                    NameValueCollection nvc2 = new NameValueCollection();
                    nvc2.Add("item.ProductCode", "2");
                    nvc2.Add("item.ProdName", "Walnut");
                    nvc2.Add("item.Units", "0");
                    nvc2.Add("item.Price", "1500");
                    nvc2.Add("txtQty", "1");
                    FormCollection formCollection2 = new FormCollection(nvc2);
                    int caritemcount = 2;

                    var viewResult1 = (RedirectToRouteResult)AddItemtoCartMethod.Invoke(BillingControllerclassObject, new object[] { formCollection1 });
                    Assert.AreEqual(viewResult1.RouteValues["action"].Equals("Index"), true);
                    var viewResult2 = (RedirectToRouteResult)AddItemtoCartMethod.Invoke(BillingControllerclassObject, new object[] { formCollection2 });
                    Assert.AreEqual(viewResult2.RouteValues["action"].Equals("Index"), true);

                    int cartcount = cartlistobject.Count();

                    // invoking checkout method
                    MethodInfo CheckOutMethod = BillingControllerClass.GetMethod("CheckOut", allBindings);
                    var checkoutResult = (RedirectToRouteResult)CheckOutMethod.Invoke(BillingControllerclassObject, null);

                    db = new BillingDBContext();
                    var qryResult = from bills in db.Billings 
                                    join bitems in db.BilledItems
                                    on bills.BillNumber equals bitems.BillNumber
                                    orderby bills.BillNumber descending
                                    select bills;
                    int billcount = qryResult.FirstOrDefault().Items.Count;

                    Assert.AreEqual(cartcount, billcount);
                }
                else
                    Assert.Fail("No class with the name 'BillingController' is implemented OR Did you change the class name");
            }
            catch (Exception ex)
            {
                Assert.Fail("Exception should not be thrown. Please check the application logic");
            }
        }

        [Test]
        public void Test_ShowBillHistoryMethod_ReturnsCartItems()
        {
            var allBindings = BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;
            BillingDBContext db = new BillingDBContext();
            try
            {
                BillingControllerClass = assembly.GetType("GenericBillingSystem.Controllers.BillingController");
                if (BillingControllerClass != null)
                {
                    MethodInfo ShowBillHistoryMethod = BillingControllerClass.GetMethod("ShowBillHistory", allBindings);
                    Assert.IsNotNull(ShowBillHistoryMethod, "Action 'ShowBillHistory' NOT implemented OR check spelling");
                    Assert.AreEqual(typeof(ViewResult), ShowBillHistoryMethod.ReturnType, "Action 'ShowBillHistory' return type MUST be 'ViewResult'");

                    ConstructorInfo classConstructor = BillingControllerClass.GetConstructor(Type.EmptyTypes);
                    object BillingControllerclassObject = classConstructor.Invoke(new object[] { });

                    Billing firstBill = db.Billings.FirstOrDefault();
                    int billnumber = 0;
                    if (firstBill != null)
                    {
                        billnumber = firstBill.BillNumber;
                    }

                    var viewResult = (ViewResult)ShowBillHistoryMethod.Invoke(BillingControllerclassObject, new object[] { billnumber });
                    IQueryable<GenericBillingSystem.Models.CartItem> qry = 
                        (IQueryable<GenericBillingSystem.Models.CartItem>)viewResult.ViewData.Model;
                    int cartcount = qry.Count();

                    db = new BillingDBContext();
                    var qryResult = from bills in db.Billings
                                    join bitems in db.BilledItems
                                    on bills.BillNumber equals bitems.BillNumber
                                    where bills.BillNumber == billnumber
                                    select bitems;
                    int billitemscount = qryResult.Count();

                    Assert.AreEqual(cartcount, billitemscount);
                }
                else
                    Assert.Fail("No class with the name 'BillingController' is implemented OR Did you change the class name");
            }
            catch (Exception ex)
            {
                Assert.Fail("Exception should not be thrown. Please check the application logic");
            }
        }

    }
}
