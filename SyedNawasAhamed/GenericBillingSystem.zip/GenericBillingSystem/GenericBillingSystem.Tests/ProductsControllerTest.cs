﻿using System;
using System.Collections.Generic;
using NUnit.Framework;
using System.Reflection;
using GenericBillingSystem.Models;
using System.Web.Mvc;
using System.Linq;
using System.Collections.Specialized;
using System.Globalization;
using System.ComponentModel.DataAnnotations;

namespace GenericBillingSystem.Tests
{
    [TestFixture]
    public class ProductsControllerTest
    {
        Assembly assembly = Assembly.Load("GenericBillingSystem");
        Type ProductControllerClass;

        [Test]
        public void Test_IndexMethod_ReturnsProductList()
        {
            var allBindings = BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;
            BillingDBContext db = new BillingDBContext();
            try
            {
                ProductControllerClass = assembly.GetType("GenericBillingSystem.Controllers.ProductsController");
                if (ProductControllerClass != null)
                {
                    MethodInfo IndexMethod = ProductControllerClass.GetMethod("Index", allBindings);
                    Assert.IsNotNull(IndexMethod, "Action 'Index' NOT implemented OR check spelling");
                    Assert.AreEqual(typeof(ActionResult), IndexMethod.ReturnType, "Action 'Index' return type MUST be 'ActionResult'");

                    ConstructorInfo classConstructor = ProductControllerClass.GetConstructor(Type.EmptyTypes);
                    object ProductControllerclassObject = classConstructor.Invoke(new object[] { });

                    var viewResult = (ViewResult)IndexMethod.Invoke(ProductControllerclassObject, new object[] { });
                    var productslist = (IEnumerable<GenericBillingSystem.Models.Product>)viewResult.ViewData.Model;

                    int productscount = db.Products.Count();
                    Assert.AreEqual(productslist.Count(), productscount);
                }
                else
                    Assert.Fail("No class with the name 'ProductsController' is implemented OR Did you change the class name");
            }
            catch (Exception ex)
            {
                Assert.Fail("Exception should not be thrown. Please check the application logic");
            }
        }

        [Test]
        public void Test_Create_PostMethod_SavesProductToDatabase()
        {
            var allBindings = BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;
            Product product = new Product
            {
                ProdName = "Walnut",
                Units = UnitOfMeasure.Kgs,
                Price = 1500,
                Status = ProductStatus.Live
            };
            try
            {
                ProductControllerClass = assembly.GetType("GenericBillingSystem.Controllers.ProductsController");
                if (ProductControllerClass != null)
                {
                    MethodInfo[] AllMethods = ProductControllerClass.GetMethods(allBindings);
                    MethodInfo CreateMethod = null;
                    foreach (MethodInfo info in AllMethods)
                    {
                        if (info.Name == "Create_Post")
                        {
                            if (info.CustomAttributes.Count() > 0 &&
                                info.CustomAttributes.FirstOrDefault().AttributeType.Equals(typeof(HttpPostAttribute)))
                            {
                                CreateMethod = info;
                            }
                        }

                    }
                    Assert.IsNotNull(CreateMethod, "Action 'Create' NOT implemented OR check spelling");

                    ConstructorInfo classConstructor = ProductControllerClass.GetConstructor(Type.EmptyTypes);
                    object ProductControllerclassObject = classConstructor.Invoke(new object[] { });

                    var result = (RedirectToRouteResult)CreateMethod.Invoke(ProductControllerclassObject, new object[] { product });
                    Assert.AreEqual(result.RouteValues["action"].Equals("Index"), true);
                }
                else
                    Assert.Fail("No class with the name 'ProductsController' is implemented OR Did you change the class name");
            }
            catch (Exception ex)
            {
                Assert.Fail("Adding Product details to the database failed. Exception should not be thrown. Please provide all mandatory fields valid data and check the destination action name.");
            }
        }

        [Test]
        public void Test_DetailsMethod_RetrievesProduct()
        {
            var allBindings = BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;
            try
            {
                ProductControllerClass = assembly.GetType("GenericBillingSystem.Controllers.ProductsController");
                if (ProductControllerClass != null)
                {
                    MethodInfo[] AllMethods = ProductControllerClass.GetMethods(allBindings);
                    MethodInfo DetailsMethod = ProductControllerClass.GetMethod("Details", allBindings);
                    Assert.IsNotNull(DetailsMethod, "Action 'Details' NOT implemented OR check spelling");

                    BillingDBContext db = new BillingDBContext();
                    Product firstproduct = db.Products.Where(prod => prod.ProductCode == 1).FirstOrDefault();
                    int id = 0;
                    if (firstproduct != null)
                    {
                        // Retrieve the product code of first product
                        id = firstproduct.ProductCode;
                    }

                    ConstructorInfo classConstructor = ProductControllerClass.GetConstructor(Type.EmptyTypes);
                    object ProductControllerclassObject = classConstructor.Invoke(new object[] { });

                    var viewresult = (ViewResult)DetailsMethod.Invoke(ProductControllerclassObject, new object[] { id });
                    var productdetail = (GenericBillingSystem.Models.Product)viewresult.ViewData.Model;
                    float price = productdetail.Price;

                    Assert.AreEqual(price, firstproduct.Price);
                }
                else
                    Assert.Fail("No class with the name 'ProductsController' is implemented OR Did you change the class name");
            }
            catch (Exception ex)
            {
                Assert.Fail("Adding Product details to the database failed. Exception should not be thrown. Please provide all mandatory fields valid data and check the destination action name.");
            }
        }

        [Test]
        public void Test_Edit_PostMethod_UpdateProductToDatabase()
        {
            var allBindings = BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;
            try
            {
                ProductControllerClass = assembly.GetType("GenericBillingSystem.Controllers.ProductsController");
                if (ProductControllerClass != null)
                {
                    MethodInfo[] AllMethods = ProductControllerClass.GetMethods(allBindings);
                    MethodInfo EditMethod = null;
                    foreach (MethodInfo info in AllMethods)
                    {
                        if (info.Name == "Edit_Post")
                        {
                            if (info.CustomAttributes.Count() > 0 &&
                                info.CustomAttributes.FirstOrDefault().AttributeType.Equals(typeof(HttpPostAttribute)))
                            {
                                EditMethod = info;
                            }
                        }

                    }
                    Assert.IsNotNull(EditMethod, "Action 'Create' NOT implemented OR check spelling");
                    BillingDBContext db = new BillingDBContext();
                    Product firstproduct = db.Products.Where(prod => prod.ProductCode == 1).FirstOrDefault();
                    float pricebefore = 0;
                    if (firstproduct != null)
                    {
                        // change the price by adding 100.
                        pricebefore = firstproduct.Price;
                        firstproduct.Price += 100;
                    }

                    ConstructorInfo classConstructor = ProductControllerClass.GetConstructor(Type.EmptyTypes);
                    object ProductControllerclassObject = classConstructor.Invoke(new object[] { });

                    var result = (RedirectToRouteResult)EditMethod.Invoke(ProductControllerclassObject, new object[] { firstproduct });

                    // Check the result
                    Product firstproductafterexecution = db.Products.Where(prod => prod.ProductCode == 1).FirstOrDefault();

                    float priceafter = 0;
                    if (firstproductafterexecution != null)
                    {
                        priceafter = firstproductafterexecution.Price;
                    }
                    Assert.AreEqual(priceafter, pricebefore  + 100);
                }
                else
                    Assert.Fail("No class with the name 'ProductsController' is implemented OR Did you change the class name");
            }
            catch (Exception ex)
            {
                Assert.Fail("Adding Product details to the database failed. Exception should not be thrown. Please provide all mandatory fields valid data and check the destination action name.");
            }
        }

        [Test]
        public void Test_Delete_PostMethod_DeleteProductToDatabase()
        {
            var allBindings = BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;
            try
            {
                ProductControllerClass = assembly.GetType("GenericBillingSystem.Controllers.ProductsController");
                if (ProductControllerClass != null)
                {
                    MethodInfo[] AllMethods = ProductControllerClass.GetMethods(allBindings);
                    MethodInfo DeleteMethod = null;
                    foreach (MethodInfo info in AllMethods)
                    {
                        if (info.Name == "Delete_Post")
                        {
                            if (info.CustomAttributes.Count() > 0 &&
                                info.CustomAttributes.FirstOrDefault().AttributeType.Equals(typeof(HttpPostAttribute)))
                            {
                                DeleteMethod = info;
                            }
                        }
                    }
                    Assert.IsNotNull(DeleteMethod, "Action 'Delete' NOT implemented OR check spelling");
                    BillingDBContext db = new BillingDBContext();
                    Product firstproduct = db.Products.Where(prod => prod.ProductCode == 1).FirstOrDefault();
                    int id = 0;
                    if (firstproduct != null)
                    {
                        id = firstproduct.ProductCode;
                    }

                    ConstructorInfo classConstructor = ProductControllerClass.GetConstructor(Type.EmptyTypes);
                    object ProductControllerclassObject = classConstructor.Invoke(new object[] { });

                    var result = (RedirectToRouteResult)DeleteMethod.Invoke(ProductControllerclassObject, new object[] { id });

                    // Check the result
                    db = new BillingDBContext();
                    Product firstproductafterexecution = db.Products.Where(prod => prod.ProductCode == 1).FirstOrDefault();
                    bool flag = false;
                    if (firstproductafterexecution != null)
                    {
                        if (firstproductafterexecution.Status == ProductStatus.Removed)
                        {
                            flag = true;
                        }
                    }
                    Assert.IsTrue(flag);
                }
                else
                    Assert.Fail("No class with the name 'ProductsController' is implemented OR Did you change the class name");
            }
            catch (Exception ex)
            {
                Assert.Fail("Adding Product details to the database failed. Exception should not be thrown. Please provide all mandatory fields valid data and check the destination action name.");
            }
        }

        [Test]
        public void Test_Create_PostMethod_PriceNull()
        {
            var allBindings = BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;
            Product product = new Product
            {
                ProdName = "Groundnut",
                Units = UnitOfMeasure.Kgs,
                Price = 0,
                Status = ProductStatus.Live
            };
            //Init ModelState
            var modelBinder = new ModelBindingContext()
            {
                ModelMetadata = ModelMetadataProviders.Current.GetMetadataForType(
                                  () => product, product.GetType()),
                ValueProvider = new NameValueCollectionValueProvider(
                                    new NameValueCollection(), CultureInfo.InvariantCulture),
                ModelState = new ModelStateDictionary()
            };
            var binder = new DefaultModelBinder().BindModel(
                             new ControllerContext(), modelBinder);

            try
            {
                ProductControllerClass = assembly.GetType("GenericBillingSystem.Controllers.ProductsController");
                if (ProductControllerClass != null)
                {
                    MethodInfo[] AllMethods = ProductControllerClass.GetMethods(allBindings);
                    MethodInfo CreateMethod = null;
                    foreach (MethodInfo info in AllMethods)
                    {
                        if (info.Name == "Create_Post")
                        {
                            if (info.CustomAttributes.Count() > 0 &&
                                info.CustomAttributes.FirstOrDefault().AttributeType.Equals(typeof(HttpPostAttribute)))
                            {
                                CreateMethod = info;
                            }
                        }
                    }
                    Assert.IsNotNull(CreateMethod, "Action 'Create' NOT implemented OR check spelling");

                    ConstructorInfo classConstructor = ProductControllerClass.GetConstructor(Type.EmptyTypes);
                    object ProductControllerclassObject = classConstructor.Invoke(new object[] { });

                    ((Controller)ProductControllerclassObject).ModelState.Clear();
                    ((Controller)ProductControllerclassObject).ModelState.Merge(modelBinder.ModelState);

                    string errorMessage = "Price Should be between 1 and 5000";
                    var ctx = new ValidationContext(product);
                    var results = new List<ValidationResult>();
                    if (!Validator.TryValidateObject(product, ctx, results, true))
                    {
                        foreach (ValidationResult vr in results)
                        {
                            if (vr.ErrorMessage == errorMessage)
                            {
                                Assert.IsTrue(vr.ErrorMessage.Equals(errorMessage));
                            }
                        }
                    }

                }
                else
                    Assert.Fail("No class with the name 'ProductsController' is implemented OR Did you change the class name");
            }
            catch (Exception ex)
            {
                Assert.Fail("Adding Product details to the database failed. Exception should not be thrown. Please provide all mandatory fields valid data and check the destination action name.");
            }
        }

    }
}
