﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace GenericBillingSystem.Models
{
    public class Billing
    {
        [Key]
        public int BillNumber { get; set; }
        public DateTime BillDate { get; set; }
        public virtual List<BilledItem> Items { get; set; }
    }
}