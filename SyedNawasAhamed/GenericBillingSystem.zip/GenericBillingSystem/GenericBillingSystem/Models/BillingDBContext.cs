﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
//Added
using System.Data.Entity;

namespace GenericBillingSystem.Models
{
    public class BillingDBContext:DbContext
    {
        public DbSet<Product> Products { get; set; }
        public DbSet<Billing> Billings { get; set; }
        public DbSet<BilledItem> BilledItems { get; set; }
        public BillingDBContext() : base("BillingDBConStr"){}
    }
}