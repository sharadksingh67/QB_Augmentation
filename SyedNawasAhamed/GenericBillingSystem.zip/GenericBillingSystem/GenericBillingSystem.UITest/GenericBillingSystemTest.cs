﻿using System;
using System.Reflection;
using System.Collections.Generic;
using System.Globalization;
using NUnit.Framework;
using OpenQA.Selenium;

namespace GenericBillingSystem.UITest
{
    [TestFixture]
    public class GenericBillingSystemTest : SeleniumTest
    {

        public GenericBillingSystemTest() : base("GenericBillingSystem")
        {

        }

        [Test]
        public void Test_ProductController_Index()
        {
            WebDriver.Navigate().GoToUrl(GetAbsoluteUrl(@"Products/Index"));
            Assert.AreEqual("Index - Generic Billing System", WebDriver.Title);
            var links =
                WebDriver.FindElements(By.TagName("a"));
            Assert.AreEqual("Generic Billing System", links[0].Text);
            Assert.AreEqual("Home", links[1].Text);
            Assert.AreEqual("Products", links[2].Text);
            Assert.AreEqual("Billing", links[3].Text);
            Assert.AreEqual("View Bills", links[4].Text);
            Assert.AreEqual("Create New", links[5].Text);
            Assert.AreEqual("Edit", links[6].Text);
            Assert.AreEqual("Details", links[7].Text);
            Assert.AreEqual("Remove", links[8].Text);
        }

        [Test]
        public void Test_ProductController_Create_RangeFields()
        {
            WebDriver.Navigate().GoToUrl(GetAbsoluteUrl(@"Products/Create"));

            // Don't enter / select inputs
            WebDriver.FindElement(By.Id("create")).Click();
            foreach (IWebElement iw in WebDriver.FindElements(By.ClassName("text-danger")))
            {
                try
                {
                    if (iw.Text.Length > 0)
                    {
                        Assert.AreEqual("Price Should be between 1 and 5000", iw.Text);
                    }
                }
                catch { }
            }
        }

        [Test]
        public void Test_ProductController_Create_ValidData()
        {
            WebDriver.Navigate().GoToUrl(GetAbsoluteUrl(@"Products/Create"));

            // Enter Price
            WebDriver.FindElement(By.Id("Price")).SendKeys("150");

            WebDriver.FindElement(By.Id("create")).Click();
            foreach (IWebElement iw in WebDriver.FindElements(By.ClassName("text-danger")))
            {
                try
                {
                    IWebElement nameErrorMessage =
                        WebDriver.FindElement(By.ClassName("text-danger"));
                }
                catch {
                    Assert.IsFalse(false);
                }
            }
        }

        [Test]
        public void Test_ProductController_Edit_RangeFields()
        {
            try
            {
                WebDriver.Navigate().GoToUrl(GetAbsoluteUrl(@"Products/Edit/1"));

                // Don't enter / select inputs
                WebDriver.FindElement(By.Id("save")).Click();
                foreach (IWebElement iw in WebDriver.FindElements(By.ClassName("text-danger")))
                {
                    if (iw.Text.Length > 0)
                    {
                        Assert.AreEqual("Price Should be between 1 and 5000", iw.Text);
                    }
                }
            }
            catch { }
        }

        [Test]
        public void Test_ProductController_Edit_ValidData()
        {
            try
            {
                WebDriver.Navigate().GoToUrl(GetAbsoluteUrl(@"Products/Edit/1"));

                // Enter Price
                WebDriver.FindElement(By.Id("Price")).SendKeys("150");

                WebDriver.FindElement(By.Id("save")).Click();
                foreach (IWebElement iw in WebDriver.FindElements(By.ClassName("text-danger")))
                {
                    if (iw.Text.Length > 0)
                    {
                        Assert.AreEqual("Price Should be between 1 and 5000", iw.Text);
                    }
                }
            }
            catch { }
        }

    }
}
