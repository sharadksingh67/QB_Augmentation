﻿using System;
using System.Web;
using System.Collections.Generic;
using System.Web.Mvc;
using System.Linq;
using System.Data.Entity.Migrations;
using GenericBillingSystem.Models;

namespace GenericBillingSystem.Controllers
{
    public class ProductsController : Controller
    {
        public static BillingDBContext db;
        // GET: Products
        public ActionResult Index()
        {
            //Add Code
            return View();
        }

        [HttpGet]
        public ActionResult Create()
        {
            //Add Code
            return View();
        }

        [HttpPost]
        [ActionName("Create")]
        public ActionResult Create_Post(Product Prod)
        {
            //Add Code
            return View();
        }

        [HttpGet]
        public ActionResult Details(int id)
        {
            //Add Code
            return View();
        }

        [HttpGet]
        public ActionResult Edit(int id)
        {
            //Add Code
            return View();
        }

        [HttpPost]
        [ActionName("Edit")]
        public ActionResult Edit_Post(Product prod)
        {
            //Add Code
            return View();
        }

        [HttpGet]
        public ActionResult Delete(int id)
        {
            //Add Code
            return View();
        }

        [HttpPost]
        [ActionName("Delete")]
        public ActionResult Delete_Post(int id)
        {
            //Add Code
            return View();
        }
    }
}