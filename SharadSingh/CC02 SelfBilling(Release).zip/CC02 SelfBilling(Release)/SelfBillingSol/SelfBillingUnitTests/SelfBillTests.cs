﻿using NUnit.Framework;
using SelfBilling.Controllers;
using SelfBilling.Models;
using System;
using System.Linq;
using System.Reflection;
using System.Web.Mvc;

namespace SelfBilling.UnitTests
{
    [TestFixture]
    public class SelfBillTests
    {
        Assembly assembly;
        Type className;

        [SetUp]
        public void Setup()
        {
            assembly = Assembly.Load("SelfBilling");
            className = assembly.GetType("SelfBilling.Controllers.SelfBillingController");
        }


        [TestCase]
        public void Test_Controller_ClassExistence()
        {
            if (className == null)
                Assert.Fail("No controller class with the name 'SelfBillingController' is implemented OR Did you change the class name");
        }

        [TestCase]
        public void Test1_DoSelfBilling_ActionMethodExist()
        {
            if (className != null)
            {
                MethodInfo testMethod = className.GetMethods().Where(x => x.Name.Equals("DoSelfBilling")
                                            && x.GetParameters().Count() == 0
                                            && x.ReturnType == typeof(ActionResult)).FirstOrDefault();
                Assert.IsNotNull(testMethod, "Method DoSelfBilling NOT implemented as per the requirement OR check the spelling");
            }
            else
                Assert.Fail("No class with the name 'SelfBillingController' is implemented  as per the requirement OR Did you change the class name");
        }

        [TestCase]
        public void Test2_DoSelfBilling_ActionMethodExist()
        {
            if (className != null)
            {
                MethodInfo testMethod = className.GetMethods().Where(x => x.Name.Equals("DoSelfBilling")
                                            && x.GetParameters().Count() == 1
                                            && x.GetParameters().First().ParameterType == typeof(SelfBill)
                                            && x.ReturnType == typeof(ActionResult)
                                            && x.CustomAttributes.First().AttributeType.
                                                    Name.Equals("HttpPostAttribute")).FirstOrDefault();

                Assert.IsNotNull(testMethod, "Method DoSelfBilling NOT implemented as per the requirement OR check the spelling");
            }
            else
                Assert.Fail("No class with the name 'SelfBillingController' is implemented OR Did you change the class name");
        }

        [TestCase]
        public void Test3_PrintBill_ActionMethodExist()
        {
            if (className != null)
            {
                MethodInfo testMethod = className.GetMethods().Where(x => x.Name.Equals("PrintBill")
                                            && x.GetParameters().Count() == 1
                                            && x.GetParameters().First().ParameterType == typeof(SelfBill)
                                            && x.ReturnType == typeof(ActionResult)).FirstOrDefault();

                Assert.IsNotNull(testMethod, "Method PrintBill NOT implemented as per the requirement OR check the spelling");
            }
            else
                Assert.Fail("No class with the name 'SelfBillingController' is implemented OR Did you change the class name");

        }

        [TestCase]
        public void TestPostController1()
        {
            SelfBillingController controller =
                        new SelfBillingController();

            SelfBill selfBill = new SelfBill()
            {
                ConsumerID = 1111,
                ConsumerName = "ABCD",
                PreviousReading = 1448,
                CurrentReading = 1472
            };

            var viewResult = controller.DoSelfBilling(selfBill) as ViewResult;
            SelfBill calculated = (SelfBill)viewResult.ViewData.Model;
            Assert.AreEqual(665.20, calculated.BillAmount);
        }



        [TestCase]
        public void TestPostController2()
        {
            SelfBillingController controller =
                        new SelfBillingController();

            SelfBill selfBill = new SelfBill()
            {
                ConsumerID = 1111,
                ConsumerName = "ABCD",
                PreviousReading = 4523,
                CurrentReading = 4589
            };

            var viewResult = controller.DoSelfBilling(selfBill) as ViewResult;
            SelfBill calculated = (SelfBill)viewResult.ViewData.Model;
            Assert.AreEqual(1864.30, calculated.BillAmount);
        }


        [TestCase]
        public void TestCalculateBillMethod3()
        {
            SelfBill selfBill = new SelfBill()
            {
                ConsumerID = 1111,
                ConsumerName = "ABCD",
                PreviousReading = 4523,
                CurrentReading = 4589
            };

            selfBill.CalculateBill();
            Assert.AreEqual(1864.30, selfBill.BillAmount);
        }

        [TestCase]
        public void TestCalculateBillMethod4()
        {
            SelfBill selfBill = new SelfBill()
            {
                ConsumerID = 1111,
                ConsumerName = "ABCD",
                PreviousReading = 1448,
                CurrentReading = 1472
            };


            selfBill.CalculateBill();
            Assert.AreEqual(665.20, selfBill.BillAmount);
        }

        [TestCase]
        public void TestCalculateBillMethod5()
        {
            SelfBill selfBill = new SelfBill()
            {
                ConsumerID = 1111,
                ConsumerName = "ABCD",
                PreviousReading = 3345,
                CurrentReading = 3398
            };


            selfBill.CalculateBill();
            Assert.AreEqual(1493.15, selfBill.BillAmount);
        }

        [TestCase]
        public void TestCalculateBillMethod6()
        {
            SelfBill selfBill = new SelfBill()
            {
                ConsumerID = 1111,
                ConsumerName = "ABCD",
                PreviousReading = 0,
                CurrentReading = 0
            };


            selfBill.CalculateBill();
            Assert.AreEqual(0.00, selfBill.BillAmount);
        }

        [TestCase]
        public void TestCalculateBillMethod7()
        {
            SelfBill selfBill = new SelfBill()
            {
                ConsumerID = 1111,
                ConsumerName = "ABCD",
                PreviousReading = 1234,
                CurrentReading = 1111
            };


            selfBill.CalculateBill();
            Assert.AreEqual(0.00, selfBill.BillAmount);
        }


        [TestCase]
        public void TestCalculateBillMethod8()
        {
            SelfBill selfBill = new SelfBill()
            {
                ConsumerID = 1111,
                ConsumerName = "ABCD",
                PreviousReading = 12345,
                CurrentReading = 1267
            };


            selfBill.CalculateBill();
            Assert.AreEqual(0.00, selfBill.BillAmount);
        }


        [TestCase]
        public void TestCalculateBillMethod9()
        {
            SelfBill selfBill = new SelfBill()
            {
                ConsumerID = 1111,
                ConsumerName = "ABCD",
                PreviousReading = 1234,
                CurrentReading = 12676
            };


            selfBill.CalculateBill();
            Assert.AreEqual(0.00, selfBill.BillAmount);
        }
    }
}