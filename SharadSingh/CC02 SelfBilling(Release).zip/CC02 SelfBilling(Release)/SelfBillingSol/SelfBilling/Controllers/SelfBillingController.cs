using SelfBilling.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SelfBilling.Controllers
{
    public class SelfBillingController : Controller
    {
        // GET: DoSelfBilling
        public ActionResult DoSelfBilling()
        {
            return View();
        }

        [HttpPost]
        public ActionResult DoSelfBilling(SelfBill selfBill)
        {
            selfBill.CalculateBill();
            if (selfBill.BillAmount == 0)
            {
                ViewBag.Message = "Bill is not generated";
            }
            return View(selfBill);
        }

        public ActionResult PrintBill(SelfBill selfBill)
        {
            return View(selfBill);
        }
    }
}