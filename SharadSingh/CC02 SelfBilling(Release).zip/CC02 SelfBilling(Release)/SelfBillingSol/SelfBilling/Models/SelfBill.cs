﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace SelfBilling.Models
{
    public class SelfBill
    {
        public int ConsumerID { get; set; }

        public string ConsumerName { get; set; }

        [DisplayFormat(DataFormatString = "{0:d}")]
        public DateTime PreviousReadingDate { get; set; }

        public int PreviousReading { get; set; }

        [DisplayFormat(DataFormatString = "{0:d}")]
        public DateTime CurrentReadingDate { get; set; }

        public int CurrentReading { get; set; }

        [DisplayFormat(DataFormatString = "{0:0.00}", ApplyFormatInEditMode = true)]
        public double BillAmount { get; set; }

        public void CalculateBill()
        {
            if (CurrentReading == 0
                || PreviousReading == 0
                || CurrentReading < PreviousReading
                || (PreviousReading < 1000 || PreviousReading > 9999)
                || (CurrentReading < 1000 || CurrentReading > 9999)
                )
            {
                BillAmount = 0;
            }
            else
            {
                int consumption = CurrentReading - PreviousReading;
                double bill = consumption * 28.55 - 20.0;
                BillAmount = bill;
            }
        }
    }
}
