using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
 
namespace SelfBilling.UITests
{
    class Selenium_Tests
    {
        String test_url = "https://localhost:44384/";

        IWebDriver driver;

        [SetUp]
        public void start_Browser()
        {
            // Local Selenium WebDriver
            driver = new ChromeDriver();
            
            driver.Manage().Window.Maximize();
        }
                
        [Test]
        public void TestForm()
        {
            driver.Url = test_url;
            System.Threading.Thread.Sleep(2000);
            Assert.AreEqual("PNG Self Billing", driver.Title);
            IWebElement searchText1 = driver.FindElement(By.Id("Consumer_ID"));
            IWebElement searchText2 = driver.FindElement(By.Id("Consumer_Name"));
            IWebElement searchText3 = driver.FindElement(By.Id("PreviousReading_Date"));
            IWebElement searchText4 = driver.FindElement(By.Id("Previous_Reading"));
            IWebElement searchText5 = driver.FindElement(By.Id("CurrentReading_Date"));
            IWebElement searchText6 = driver.FindElement(By.Id("Current_Reading"));
            IWebElement searchText7 = driver.FindElement(By.Id("Submit"));
            IWebElement searchText8 = driver.FindElement(By.LinkText("Print Bill"));
            searchText7.Click();
            System.Threading.Thread.Sleep(3000);
            IWebElement searchText9 = driver.FindElement(By.Id("Billing_Amount"));

            var links = driver.FindElements(By.TagName("a"));
            Assert.AreEqual("Print Bill", links[0].Text);
            Console.WriteLine("Test Passed");
        }

        [Test]
        public void TestSubmit_Print_1()
        {
            driver.Url = test_url;
            System.Threading.Thread.Sleep(2000);
            IWebElement searchText4 = driver.FindElement(By.Id("Submit"));

            searchText4.Click();
            System.Threading.Thread.Sleep(3000);
            IWebElement searchText6 = driver.FindElement(By.Id("Billing_Amount"));
            Assert.IsTrue(searchText6.Text.Contains("Bill is not generated"));

            Console.WriteLine("Test Passed");
        }

        [Test]
        public void TestSubmit_Print_2()
        {
            driver.Url = test_url;
            System.Threading.Thread.Sleep(2000);

            IWebElement searchText4 = driver.FindElement(By.Id("Previous_Reading"));
            IWebElement searchText6 = driver.FindElement(By.Id("Current_Reading"));
            searchText4.SendKeys("4523");
            searchText6.SendKeys("4589");
            IWebElement searchText7 = driver.FindElement(By.Id("Submit"));
            searchText7.Click();
            System.Threading.Thread.Sleep(3000);
            IWebElement searchText9 = driver.FindElement(By.Id("Billing_Amount"));

            Assert.IsTrue(searchText9.Text.Contains("Your Billing Amount:1864.30"));

            IWebElement searchText5 = driver.FindElement(By.LinkText("Print Bill"));
            searchText5.Click();
            System.Threading.Thread.Sleep(3000);

            
            IWebElement heading = driver.FindElement(By.XPath("//*[text() = 'PNG Self Billing']"));
            IWebElement amount = driver.FindElement(By.XPath("//*[text() = '1864.30']"));

            Console.WriteLine("Test Passed");
        }

        [Test]
        public void TestSubmit_Print_3()
        {
            driver.Url = test_url;
            System.Threading.Thread.Sleep(2000);

            IWebElement searchText4 = driver.FindElement(By.Id("Previous_Reading"));
            IWebElement searchText6 = driver.FindElement(By.Id("Current_Reading"));
            searchText4.SendKeys("3345");
            searchText6.SendKeys("3398");
            IWebElement searchText7 = driver.FindElement(By.Id("Submit"));
            searchText7.Click();
            System.Threading.Thread.Sleep(3000);
            IWebElement searchText9 = driver.FindElement(By.Id("Billing_Amount"));

            Assert.IsTrue(searchText9.Text.Contains("Your Billing Amount:1493.15"));

            IWebElement searchText5 = driver.FindElement(By.LinkText("Print Bill"));
            searchText5.Click();
            System.Threading.Thread.Sleep(3000);


            IWebElement heading = driver.FindElement(By.XPath("//*[text() = 'PNG Self Billing']"));
            IWebElement amount = driver.FindElement(By.XPath("//*[text() = '1493.15']"));

            Console.WriteLine("Test Passed");
        }


        [Test]
        public void TestSubmit_Print_4()
        {
            driver.Url = test_url;
            System.Threading.Thread.Sleep(2000);

            IWebElement searchText4 = driver.FindElement(By.Id("Previous_Reading"));
            IWebElement searchText6 = driver.FindElement(By.Id("Current_Reading"));
            searchText4.SendKeys("7711");
            searchText6.SendKeys("7799");
            IWebElement searchText7 = driver.FindElement(By.Id("Submit"));
            searchText7.Click();
            System.Threading.Thread.Sleep(3000);
            IWebElement searchText9 = driver.FindElement(By.Id("Billing_Amount"));

            Assert.IsTrue(searchText9.Text.Contains("Your Billing Amount:2492.40"));

            IWebElement searchText5 = driver.FindElement(By.LinkText("Print Bill"));
            searchText5.Click();
            System.Threading.Thread.Sleep(3000);


            IWebElement heading = driver.FindElement(By.XPath("//*[text() = 'PNG Self Billing']"));
            IWebElement amount = driver.FindElement(By.XPath("//*[text() = '2492.40']"));

            Console.WriteLine("Test Passed");
        }

        [Test]
        public void TestSubmit_Print_5()
        {
            driver.Url = test_url;
            System.Threading.Thread.Sleep(2000);

            IWebElement searchText4 = driver.FindElement(By.Id("Previous_Reading"));
            IWebElement searchText6 = driver.FindElement(By.Id("Current_Reading"));
            searchText4.SendKeys("7711");
            searchText6.SendKeys("7699");
            IWebElement searchText7 = driver.FindElement(By.Id("Submit"));
            searchText7.Click();
            System.Threading.Thread.Sleep(3000);
            IWebElement searchText9 = driver.FindElement(By.Id("Billing_Amount"));

            Assert.IsTrue(searchText9.Text.Contains("Bill is not generated"));

            IWebElement searchText5 = driver.FindElement(By.LinkText("Print Bill"));
            searchText5.Click();
            System.Threading.Thread.Sleep(3000);


            IWebElement heading = driver.FindElement(By.XPath("//*[text() = 'PNG Self Billing']"));
            IWebElement amount = driver.FindElement(By.XPath("//*[text() = '0.00']"));

            Console.WriteLine("Test Passed");
        }

        [Test]
        public void TestSubmit_Print_6()
        {
            driver.Url = test_url;
            System.Threading.Thread.Sleep(2000);

            IWebElement searchText4 = driver.FindElement(By.Id("Previous_Reading"));
            IWebElement searchText6 = driver.FindElement(By.Id("Current_Reading"));
            searchText4.SendKeys("77116");
            searchText6.SendKeys("77196");
            IWebElement searchText7 = driver.FindElement(By.Id("Submit"));
            searchText7.Click();
            System.Threading.Thread.Sleep(3000);
            IWebElement searchText9 = driver.FindElement(By.Id("Billing_Amount"));

            Assert.IsTrue(searchText9.Text.Contains("Bill is not generated"));

            IWebElement searchText5 = driver.FindElement(By.LinkText("Print Bill"));
            searchText5.Click();
            System.Threading.Thread.Sleep(3000);


            IWebElement heading = driver.FindElement(By.XPath("//*[text() = 'PNG Self Billing']"));
            IWebElement amount = driver.FindElement(By.XPath("//*[text() = '0.00']"));

            Console.WriteLine("Test Passed");
        }


        [TearDown]
        public void close_Browser()
        {
            driver.Quit();
            Console.WriteLine("Test Finished");
        }

        public void Dispose()
        {            
            driver.Dispose();
        }
    }
}