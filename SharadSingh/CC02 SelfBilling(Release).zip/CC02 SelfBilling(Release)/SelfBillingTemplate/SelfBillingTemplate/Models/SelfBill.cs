﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace SelfBilling.Models
{
    public class SelfBill
    {
        public int ConsumerID { get; set; }

        public string ConsumerName { get; set; }

        [DisplayFormat(DataFormatString = "{0:d}")]
        public DateTime PreviousReadingDate { get; set; }

        public int PreviousReading { get; set; }

        [DisplayFormat(DataFormatString = "{0:d}")]
        public DateTime CurrentReadingDate { get; set; }

        public int CurrentReading { get; set; }

        [DisplayFormat(DataFormatString = "{0:0.00}", ApplyFormatInEditMode = true)]
        public double BillAmount { get; set; }

        public void CalculateBill()
        {
            //Implement your code        
        }
    }
}
