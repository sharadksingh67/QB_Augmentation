﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Models
{
    public class Bonus
    {
        public int Emp_ID { set; get; }
        public String Emp_Name { set; get; }
        public int Project_Hours { set; get; }
        public int Documentation_Hours { set; get; }
        public int Bonus_Amount { set; get; } 
    }
}
