using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace BankAccountsMgmt.Controllers
{
    public class BankAccountsController : Controller
    {
        // GET
        public ActionResult Index()
        {
            //Implement your code 
            return View();
        }
        //Implement other action methods
    }
}
