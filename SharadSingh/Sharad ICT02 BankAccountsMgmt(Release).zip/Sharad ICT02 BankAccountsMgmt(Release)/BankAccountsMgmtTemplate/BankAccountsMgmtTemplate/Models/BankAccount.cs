using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace BankAccountsMgmt.Models
{
    public enum City
    {
        Select,
        Chennai,
        Dehradun,
        Delhi,
        Hyderabad,
        Kolkata,
        Mumbai
    }

    public enum Gender
    {
        Select,
        Male,
        Female,
        Others
    }

    public class BankAccount
    {
        //Implement DataAnnotations 

        public int AccountID { get; set; }

        public string AccountHolderName { get; set; }

        public string PAN { get; set; }

        public City City { get; set; }

        public Gender Gender { get; set; }

        public bool KYCComplete { get; set; }

        public int Amount { get; set; }

        public DateTime? OpeningDate { get; set; }

        public double Interest { get; set; }

        public void CalculateInterest()
        {
            //Implement your code 
        }
    }
}
