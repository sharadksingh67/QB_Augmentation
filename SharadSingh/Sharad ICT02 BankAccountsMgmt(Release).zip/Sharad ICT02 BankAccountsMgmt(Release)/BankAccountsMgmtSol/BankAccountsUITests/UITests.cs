﻿using BankAccountsMgmt.Data;
using BankAccountsMgmt.Models;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Remote;
using System;
using System.Linq;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Reflection;

namespace BankAccountsUITests
{
    [TestFixture]
    public abstract class IISServerTest
    {
        private const int WebAppPort = 26357;

        private Process _webHostProcess;
        private readonly string _applicationName;

        protected IISServerTest(string applicationName)
        {
            _applicationName = applicationName;
        }

        [SetUp]
        public void TestInitialize()
        {
            // Start IISExpress here
            StartIIS();

            Initialize();
        }

        [TearDown]
        public void TestCleanup()
        {
            Cleanup();
            // Make sure that IISExpress is stopped here
            if (_webHostProcess.HasExited == false)
            {
                _webHostProcess.Kill();
            }
        }

        public abstract void Initialize();

        public abstract void Cleanup();

        private void StartIIS()
        {
            var applicationPath = GetApplicationPath(_applicationName);
            var key = Environment.Is64BitOperatingSystem ? "programfiles(x86)" : "programfiles";
            var programfiles = Environment.GetEnvironmentVariable(key);

            var iisExpressStartInfo = new ProcessStartInfo
            {
                WindowStyle = ProcessWindowStyle.Normal,
                ErrorDialog = true,
                LoadUserProfile = true,
                CreateNoWindow = false,
                UseShellExecute = false,
                Arguments = String.Format("/path:\"{0}\" /port:{1}", applicationPath, WebAppPort),
                FileName = string.Format("{0}\\IIS Express\\iisexpress.exe", programfiles)
            };
            _webHostProcess = Process.Start(iisExpressStartInfo);
        }

        protected virtual string GetApplicationPath(string applicationName)
        {
            var solutionFolder = Path.GetDirectoryName(Path.GetDirectoryName(Path.GetDirectoryName(AppDomain.CurrentDomain.BaseDirectory)));
            return Path.Combine(solutionFolder, applicationName);
        }

        public string GetAbsoluteUrl(string relativeUrl)
        {
            return String.Format(@"http://localhost:{0}/{1}", WebAppPort, relativeUrl);
        }
    }

    public abstract class SeleniumTest : IISServerTest
    {
        private RemoteWebDriver _remoteWebDriver;
        protected IWebDriver WebDriver
        {
            get { return _remoteWebDriver; }
        }

        protected SeleniumTest(string applicationName) : base(applicationName)
        {
        }

        public override void Initialize()
        {
            _remoteWebDriver = new ChromeDriver();
        }

        public override void Cleanup()
        {
            _remoteWebDriver.Dispose();
        }
    }

    [TestFixture]
    public class BankAccountsMgmtTests : SeleniumTest, IDisposable
    {
        public BankAccountsMgmtTests() : base("Bank Accounts Management")
        {

        }

        [Test]
        public void Test_Index()
        {
            try
            {
                WebDriver.Navigate().GoToUrl(GetAbsoluteUrl("BankAccounts/Index"));

                //Maximize the window
                WebDriver.Manage().Window.Maximize();

                Assert.AreEqual("Index - Bank Accounts Management", WebDriver.Title);

                WebDriver.FindElement(By.LinkText("Bank Accounts Management"));
                WebDriver.FindElement(By.LinkText("Accounts List"));
                WebDriver.FindElement(By.LinkText("Create New"));

                IWebElement searchText1 = WebDriver.FindElement(By.XPath("//*[text() = 'Account Holder Name']"));
                IWebElement searchText2 = WebDriver.FindElement(By.XPath("//*[text() = 'PAN Number']"));
                IWebElement searchText3 = WebDriver.FindElement(By.XPath("//*[text() = 'City']"));
                IWebElement searchText4 = WebDriver.FindElement(By.XPath("//*[text() = 'Gender']"));
                IWebElement searchText5 = WebDriver.FindElement(By.XPath("//*[text() = 'Amount']"));
                IWebElement searchText7 = WebDriver.FindElement(By.XPath("//*[text() = 'Opening Date']"));
                IWebElement searchText8 = WebDriver.FindElement(By.XPath("//*[text() = 'KYC Complete?']"));
                IWebElement searchText6 = WebDriver.FindElement(By.XPath("//*[text() = 'Interest Upto 30 Aug']"));

                var checkBoxElement = WebDriver.FindElement(By.Id("KYC"));
                var submitElement = WebDriver.FindElement(By.Id("Submit"));

                BankAccountDBContext context = new BankAccountDBContext();
                string total = context.BankAccounts.Sum(r => r.Interest).ToString();

                var totalElement = WebDriver.FindElement(By.Id("total"));
                Assert.AreEqual(totalElement.Text, total);
            }
            catch (Exception)
            {
                Assert.Fail("Exception should not occur here. Verify the value entered");
            }
        }

        [Test]
        public void Test_AddBankAccountView()
        {
            try
            {
                WebDriver.Navigate().GoToUrl(GetAbsoluteUrl(@"BankAccounts/AddBankAccount"));

                //Maximize the window
                WebDriver.Manage().Window.Maximize();

                IWebElement searchTextl1 = WebDriver.FindElement(By.XPath("//*[text() = 'Create']"));
                IWebElement searchTextl2 = WebDriver.FindElement(By.XPath("//*[text() = 'Bank Account']"));

                IWebElement searchText1 = WebDriver.FindElement(By.XPath("//*[text() = 'Account Holder Name']"));
                IWebElement searchText2 = WebDriver.FindElement(By.XPath("//*[text() = 'PAN Number']"));
                IWebElement searchText3 = WebDriver.FindElement(By.XPath("//*[text() = 'City']"));
                IWebElement searchText4 = WebDriver.FindElement(By.XPath("//*[text() = 'Gender']"));
                IWebElement searchText5 = WebDriver.FindElement(By.XPath("//*[text() = 'Amount']"));
                IWebElement searchText7 = WebDriver.FindElement(By.XPath("//*[text() = 'Opening Date']"));
                IWebElement searchText8 = WebDriver.FindElement(By.XPath("//*[text() = 'KYC Complete?']"));

            }
            catch (Exception)
            {
                Assert.Fail("Exception should not occur here. Verify the value entered");
            }
        }

        [Test]
        public void Test_AddBankAccount_RequiredFields()
        {
            try
            {
                WebDriver.Navigate().GoToUrl(GetAbsoluteUrl(@"BankAccounts/AddBankAccount"));

                //Maximize the window
                WebDriver.Manage().Window.Maximize();

                IWebElement searchText1 = WebDriver.FindElement(By.Id("Submit"));
                searchText1.Click();
                System.Threading.Thread.Sleep(2000);

                IWebElement searchText11 = WebDriver.FindElement(By.XPath("//*[text() = 'Please Provide Account Holder Name']"));
                IWebElement searchText12 = WebDriver.FindElement(By.XPath("//*[text() = 'Please Provide PAN Number']"));
                IWebElement searchText13 = WebDriver.FindElement(By.XPath("//*[text() = 'Please Select a City']"));
                IWebElement searchText14 = WebDriver.FindElement(By.XPath("//*[text() = 'Please Select Gender']"));
                IWebElement searchText15 = WebDriver.FindElement(By.XPath("//*[text() = 'Please Provide Opening Date']"));
                IWebElement searchText16 = WebDriver.FindElement(By.XPath("//*[text() = 'Should be between 1000 and 50000']"));
            }
            catch (Exception)
            {
                Assert.Fail("Exception should not occur here. Verify the value entered");
            }
        }

        [Test]
        public void Test_AddBankAccount_ValidData()
        {
            try
            {
                WebDriver.Navigate().GoToUrl(GetAbsoluteUrl(@"BankAccounts/AddBankAccount"));

                //Maximize the window
                WebDriver.Manage().Window.Maximize();

                WebDriver.FindElement(By.Id("AccountHolderName")).SendKeys("Account1");
                WebDriver.FindElement(By.Id("PAN")).SendKeys("ABCDE1234Z");
                WebDriver.FindElement(By.Id("City")).SendKeys("Delhi");
                WebDriver.FindElement(By.Id("Gender")).SendKeys("Male");
                WebDriver.FindElement(By.Id("Amount")).SendKeys("2500");
                WebDriver.FindElement(By.Id("OpeningDate")).SendKeys("05/02/2020");

                WebDriver.FindElement(By.Id("Submit")).Click();

                Assert.AreEqual("Bank Account added successfully!",
                                    WebDriver.FindElement(By.Id("message")).Text);
            }
            catch (Exception)
            {
                Assert.Fail("Exception should not occur here. Verify the value entered");
            }
        }

        [Test]
        public void Test_Details()
        {
            try
            {
                WebDriver.Navigate().GoToUrl(GetAbsoluteUrl(@"BankAccounts/Details/2"));

                //Maximize the window
                WebDriver.Manage().Window.Maximize();

                Assert.AreEqual("Details - Bank Accounts Management", WebDriver.Title);

                WebDriver.FindElement(By.LinkText("Back to List"));

                var messageElement = WebDriver.FindElement(By.Id("message"));
                Assert.AreEqual("Bank Account added successfully!", messageElement.Text);
            }
            catch (Exception)
            {
                Assert.Fail("Exception should not occur here. Verify the value entered");
            }
        }

        [Test]
        public void Test_KYCFilter()
        {
            try
            {
                WebDriver.Navigate().GoToUrl(GetAbsoluteUrl(@"BankAccounts/Index"));

                //Maximize the window
                WebDriver.Manage().Window.Maximize();

                BankAccount bankAccount1 = new BankAccount
                {
                    AccountHolderName = "name1",
                    City = City.Hyderabad,
                    Amount = 3000,
                    Gender = Gender.Male,
                    KYCComplete = true,
                    PAN = "ABCDE1234Z",
                    Interest = 5.67,
                    OpeningDate = DateTime.Today
                };

                BankAccount bankAccount2 = new BankAccount
                {
                    AccountHolderName = "name1",
                    City = City.Hyderabad,
                    Amount = 3000,
                    Gender = Gender.Male,
                    KYCComplete = false,
                    PAN = "ABCDE1234Z",
                    Interest = 5.67,
                    OpeningDate = DateTime.Today
                };

                BankAccountDBContext dBContext = new BankAccountDBContext();

                //delete previous dummy records
                var toDelete = dBContext.BankAccounts.Where(r => r.AccountHolderName == "name1");
                dBContext.BankAccounts.RemoveRange(toDelete);
                dBContext.SaveChanges();

                //Add New KYC data
                dBContext.BankAccounts.Add(bankAccount1);
                dBContext.BankAccounts.Add(bankAccount2);
                dBContext.SaveChanges();

                WebDriver.Navigate().GoToUrl(GetAbsoluteUrl(@"BankAccounts/Index"));

                Assert.AreEqual("Index - Bank Accounts Management", WebDriver.Title);
                var check = WebDriver.FindElement(By.Id("KYC"));
                var submit = WebDriver.FindElement(By.Id("Submit"));

                check.Click();
                submit.Click();

                //Checking checkboxes selected
                foreach (IWebElement e in WebDriver.FindElements(By.XPath("//input[@type='checkbox']")))
                {
                    if (!e.Selected)
                        Assert.Fail("Filter is not working...");
                }

                //check Interest Total after filter
                string total = dBContext.BankAccounts
                                    .Where(s => s.KYCComplete == true)
                                    .Sum(r => r.Interest).ToString();
                var totalElement = WebDriver.FindElement(By.Id("total"));
                Assert.AreEqual(totalElement.Text, total);

                check = WebDriver.FindElement(By.Id("KYC"));
                submit = WebDriver.FindElement(By.Id("Submit"));
                check.Click();
                submit.Click();

                //Checking checkboxes not selected
                foreach (IWebElement e in WebDriver.FindElements(By.XPath("//input[@type='checkbox']")))
                {
                    if (e.Selected)
                        Assert.Fail("Filter is not working...");
                }
                //check Interest Total after filter
                total = dBContext.BankAccounts
                                    .Where(s => s.KYCComplete == false)
                                    .Sum(r => r.Interest).ToString();
                totalElement = WebDriver.FindElement(By.Id("total"));
                Assert.AreEqual(totalElement.Text, total);
            }
            catch (Exception)
            {
                Assert.Fail("Exception should not occur here. Verify the value entered");
            }
        }

        [Test]
        public void Test_Details_BackToList()
        {
            try
            {
                WebDriver.Navigate().GoToUrl(GetAbsoluteUrl(@"BankAccounts/Details/2"));

                //Maximize the window
                WebDriver.Manage().Window.Maximize();

                Assert.AreEqual("Details - Bank Accounts Management", WebDriver.Title);
                var link = WebDriver.FindElement(By.LinkText("Back to List"));                
                link.Click();
                Assert.AreEqual("Index - Bank Accounts Management", WebDriver.Title);
            }
            catch (Exception)
            {
                Assert.Fail("Exception should not occur here. Verify the value entered");
            }
        }

        public void Dispose()
        {
            WebDriver.Quit();
            WebDriver.Dispose();
        }
    }
}
