﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using BankAccountsMgmt.Models;

namespace BankAccountsMgmt.Data
{
    public class BankAccountDBContext : DbContext
    {
        public BankAccountDBContext():base("name=BAM_DB")
        {
        }
        public DbSet<BankAccount>  BankAccounts { get; set; }
    }
}