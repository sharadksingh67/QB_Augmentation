using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BankAccountsMgmt.Data;
using BankAccountsMgmt.Models;

namespace BankAccountsMgmt.Controllers
{
    [CustomFilters.CustomExceptionFilter]
    public class BankAccountsController : Controller
    {
        // GET
        public ActionResult Index()
        {
            var context = new BankAccountDBContext();
            var list = context.BankAccounts
                                .OrderBy(h => h.City)
                                .Select(h => h)
                                .ToList<BankAccount>();
            return View(list);
        }

        [HttpPost]
        public ActionResult Index(bool KYC)
        {
            var context = new BankAccountDBContext();
            var list = context.BankAccounts
                                .Where(x => x.KYCComplete == KYC)
                                .OrderBy(h => h.City)
                                .Select(h => h)
                                .ToList<BankAccount>();
            return View(list);
        }

        public ActionResult AddBankAccount()
        {
            BankAccount res = new BankAccount();
            return View(res);
        }

        [HttpPost]
        public ActionResult AddBankAccount(BankAccount BankAccount)
        {
            if (ModelState.IsValid)
            {
                ViewBag.msg = "Bank Account added successfully!";
                var context = new BankAccountDBContext();
                BankAccount.CalculateInterest();
                context.BankAccounts.Add(BankAccount);
                context.SaveChanges();
                return RedirectToAction("Details",
                    new { id = BankAccount.AccountID });
            }
            else
            {
                return View();
            }
        }

        public ActionResult Details(int id)
        {
            var db = new BankAccountDBContext();
            var model = db.BankAccounts
                            .Where(r => r.AccountID == id)
                            .FirstOrDefault();
            return View(model);
        }
    }
}   
