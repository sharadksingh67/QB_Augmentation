using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace BankAccountsMgmt.Models
{
    public enum City
    {
        Select,
        Chennai,
        Dehradun,
        Delhi,
        Hyderabad,
        Kolkata,
        Mumbai
    }

    public enum Gender
    {
        Select,
        Male,
        Female,
        Others
    }

    public class BankAccount
    {
        [Key]
        public int AccountID { get; set; }

        [Required(ErrorMessage = "Please Provide Account Holder Name")]
        [MaxLength(255)]
        [Display(Name = "Account Holder Name")]
        public string AccountHolderName { get; set; }

        [Required(ErrorMessage = "Please Provide PAN Number")]
        [MaxLength(10)]
        [RegularExpression(@"^[A-Z]{5}[0-9]{4}[A-Z]{1}$", ErrorMessage = "Please Provide a valid PAN")]
        [Display(Name = "PAN Number")]
        public string PAN { get; set; }

        [Required, Range(1, 6, ErrorMessage = "Please Select a City")]
        [Display(Name = "City")]
        public City City { get; set; }

        [Required, Range(1, 3, ErrorMessage = "Please Select Gender")]
        [Display(Name = "Gender")]
        public Gender Gender { get; set; }

        [Display(Name = "KYC Complete?")]
        public bool KYCComplete { get; set; }

        [Required]
        [Display(Name = "Amount")]
        [Range(1000, 50000, ErrorMessage = "Should be between 1000 and 50000")]
        public int Amount { get; set; }

        [Required(ErrorMessage = "Please Provide Opening Date")]
        [DataType(DataType.Date)]
        [Display(Name = "Opening Date")]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yy}", ApplyFormatInEditMode = true)]
        public DateTime? OpeningDate { get; set; }

        [DisplayFormat(DataFormatString = "{0:0.00}")]
        [Display(Name = "Interest Upto 30 Aug")]
        public double Interest { get; set; }

        public void CalculateInterest()
        {
            double rateOfInterest;

            if (Gender == Gender.Male)
            {
                rateOfInterest = 2.5;
            }
            else
                rateOfInterest = 3.5;

            DateTime upto = new DateTime(2020, 08, 31);
            int days = (upto - (DateTime)OpeningDate).Days;
            Interest = Math.Round((Amount * days * rateOfInterest) / (30 * 12 * 100.0), 2);
        }
    }
}
