﻿using BankAccountsMgmt.Controllers;
using BankAccountsMgmt.Data;
using BankAccountsMgmt.Models;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Web.Mvc;

namespace BankAccountsUnitTests
{
    [TestFixture]
    public class NUnitTests
    {
        Assembly assembly;
        Type className, dbContextclassName, modelClassName;

        [SetUp]
        public void Setup()
        {
            assembly = Assembly.Load("BankAccountsMgmt");
            className = assembly.GetType("BankAccountsMgmt.Controllers.BankAccountsController");
            modelClassName = assembly.GetType("BankAccountsMgmt.Models.BankAccount");
            dbContextclassName = assembly.GetType("BankAccountsMgmt.Data.BankAccountDBContext");
        }

        [TestCase]
        public void BankAccountsController_WhenNoSuchClassFound_WarnsUser()
        {
            if (className == null)
                Assert.Fail("No controller class with the name 'BankAccountsController' is implemented OR Did you change the class name");
        }

        [TestCase]
        public void DBContext_WhenNoSuchClassFound_WarnsUser()
        {
            if (dbContextclassName == null)
                Assert.Fail("No DBContext class with the name 'BankAccountDBContext' is implemented as required OR Did you change the class name");
        }

        [TestCase]
        public void BankAccountDBContext_InitalizesDbContext()
        {
            BankAccountDBContext db = new BankAccountDBContext();
            try
            {
                if (className != null)
                {
                    ConstructorInfo classConstructor = className.GetConstructor(Type.EmptyTypes);
                    object classObject = classConstructor.Invoke(new object[] { });

                    Assert.IsNotNull(db);
                }
                else
                    Assert.Fail("No class with the name 'BankAccountsController' is implemented OR Did you change the class name");
            }
            catch (Exception)
            {
                Assert.Fail("Adding BankAccount details to the database failed. Exception should not be thrown. Please provide all mandatory fields valid data and check the destination action name.");
            }
        }

        [TestCase]
        public void Index_WhenNoSuchActionMethodFound_WarnsUser()
        {
            if (className != null)
            {
                MethodInfo testMethod = className.GetMethods().Where(x => x.Name.Equals("Index")
                                           && x.GetParameters().Count() == 0
                                           && x.ReturnType == typeof(ActionResult)).FirstOrDefault();
                Assert.IsNotNull(testMethod, "Method Index NOT implemented as per the requirement OR check the spelling");
            }
            else
                Assert.Fail("No class with the name 'BankAccountsController' is implemented  as per the requirement OR Did you change the class name");
        }

        [TestCase]
        public void Index_WhenNoSuchPostActionMethodFound_WarnsUser()
        {
            if (className != null)
            {
                MethodInfo testMethod = className.GetMethods().Where(x => x.Name.Equals("Index")
                                           && x.GetParameters().Count() == 1
                                           && x.GetParameters().First().ParameterType == typeof(bool)
                                           && x.ReturnType == typeof(ActionResult)
                                           && x.CustomAttributes.First().AttributeType.Name
                                                    .Equals("HttpPostAttribute")).FirstOrDefault();

                Assert.IsNotNull(testMethod, "Method Index NOT implemented as per the requirement OR check the spelling");
            }
            else
                Assert.Fail("No class with the name 'BankAccountsController' is implemented  as per the requirement OR Did you change the class name");
        }

        [TestCase]
        public void AddBankAccount_WhenNoSuchActionMethodFound_WarnsUser()
        {
            if (className != null)
            {
                MethodInfo testMethod = className.GetMethods().Where(x => x.Name.Equals("AddBankAccount")
                                           && x.GetParameters().Count() == 0
                                           && x.ReturnType == typeof(ActionResult)).FirstOrDefault();

                Assert.IsNotNull(testMethod, "Method AddBankAccount NOT implemented as per the requirement OR check the spelling");
            }
            else
                Assert.Fail("No class with the name 'BankAccountsController' is implemented  as per the requirement OR Did you change the class name");
        }

        [TestCase]
        public void AddBankAccount_WhenNoSuchPostActionMethodFound_WarnsUser()
        {

            if (className != null)
            {
                MethodInfo testMethod = className.GetMethods().Where(x => x.Name.Equals("AddBankAccount")
                                            && x.GetParameters().Count() == 1
                                            && x.GetParameters().First().ParameterType == typeof(BankAccount)
                                            && x.ReturnType == typeof(ActionResult)
                                            && x.CustomAttributes.First().AttributeType.Name
                                                    .Equals("HttpPostAttribute")).FirstOrDefault();

                Assert.IsNotNull(testMethod, "Method AddBankAccount NOT implemented as per the requirement OR check the spelling");
            }
            else
                Assert.Fail("No class with the name 'BankAccountsController' is implemented  as per the requirement OR Did you change the class name");
        }

        [TestCase]
        public void Details_WhenNoSuchActionMethodFound_WarnsUser()
        {
            if (className != null)
            {
                MethodInfo testMethod = className.GetMethods().Where(x => x.Name.Equals("Details")
                                            && x.GetParameters().Count() == 1
                                            && x.GetParameters().First().ParameterType == typeof(int)
                                            && x.ReturnType == typeof(ActionResult)).FirstOrDefault();

                Assert.IsNotNull(testMethod, "Method Details NOT implemented as per the requirement OR check the spelling");
            }
            else
                Assert.Fail("No class with the name 'BankAccountsController' is implemented  as per the requirement OR Did you change the class name");
        }

        [Test]
        public void BankAccount_Should_Not_Be_Valid_When_Some_Properties_Incorrect()
        {
            //Arrange 
            var allBindings = BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;

            var BankAccountsController = new BankAccountsController();
            BankAccountDBContext db = new BankAccountDBContext();
            BankAccount account = new BankAccount()
            {
                AccountHolderName = null,
                PAN = null,
                Amount = 0,
                Interest = 0,
                City = City.Select,
                Gender = Gender.Select,
                OpeningDate = null
            };

            //Initialize ModelState 
            var modelBinder = new ModelBindingContext()
            {
                ModelMetadata = ModelMetadataProviders.Current.GetMetadataForType(
                                  () => account, account.GetType()),
                ValueProvider = new NameValueCollectionValueProvider(
                                    new NameValueCollection(), CultureInfo.InvariantCulture)
            };
            var binder = new DefaultModelBinder().BindModel(
                             new ControllerContext(), modelBinder);

            try
            {
                className = assembly.GetType("BankAccountsMgmt.Controllers.BankAccountsController");

                if (className != null)
                {
                    MethodInfo[] testMethods = className.GetMethods(allBindings);
                    MethodInfo testMethod = default;

                    foreach (var item in testMethods)
                    {
                        if (item.CustomAttributes.Count() > 0)
                        {
                            if (item.IsGenericMethod == false && item.Name.Equals("AddBankAccount")
                                && item.CustomAttributes.First().AttributeType
                                .Name.Equals("HttpPostAttribute"))
                            {
                                testMethod = item;
                                break;
                            }
                        }
                    }

                    Assert.IsNotNull(testMethod, "Action 'AddBankAccount' NOT implemented OR check spelling");

                    ConstructorInfo classConstructor = className.GetConstructor(Type.EmptyTypes);
                    object classObject = classConstructor.Invoke(new object[] { });
                    ((Controller)classObject).ModelState.Clear();
                    ((Controller)classObject).ModelState.Merge(modelBinder.ModelState);

                    Assert.IsFalse(((Controller)classObject).ModelState.IsValid, "Verify the model state values");
                }
                else
                    Assert.Fail("No class with the name 'BankAccountsController' is implemented OR Did you change the class name");
            }
            catch (Exception)
            {
                Assert.Fail("Adding new account to the database failed. verify the state of model object");
            }
        }

        [Test]
        public void BankAccount_Should_Be_Valid_When_All_Properties_Correct()
        {
            //Arrange 
            var allBindings = BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;

            var BankAccountsController = new BankAccountsController();
            BankAccountDBContext db = new BankAccountDBContext();
            BankAccount account = new BankAccount()
            {
                AccountHolderName = "TestAccount",
                PAN = "ABCDE2134Y",
                Amount = 10000,
                Interest = 123.0,
                City = City.Delhi,
                Gender = Gender.Female,
                OpeningDate = DateTime.Today
            };

            //Initialize ModelState 
            var modelBinder = new ModelBindingContext()
            {
                ModelMetadata = ModelMetadataProviders.Current.GetMetadataForType(
                                  () => account, account.GetType()),
                ValueProvider = new NameValueCollectionValueProvider(
                                    new NameValueCollection(), CultureInfo.InvariantCulture)
            };
            var binder = new DefaultModelBinder().BindModel(
                             new ControllerContext(), modelBinder);

            try
            {
                className = assembly.GetType("BankAccountsMgmt.Controllers.BankAccountsController");

                if (className != null)
                {
                    MethodInfo[] testMethods = className.GetMethods(allBindings);
                    MethodInfo testMethod = default;

                    foreach (var item in testMethods)
                    {
                        if (item.CustomAttributes.Count() > 0)
                        {
                            if (item.IsGenericMethod == false && item.Name.Equals("AddBankAccount")
                                && item.CustomAttributes.First().AttributeType
                                .Name.Equals("HttpPostAttribute"))
                            {
                                testMethod = item;
                                break;
                            }
                        }
                    }

                    Assert.IsNotNull(testMethod, "Action 'AddBankAccount' NOT implemented OR check spelling");

                    ConstructorInfo classConstructor = className.GetConstructor(Type.EmptyTypes);
                    object classObject = classConstructor.Invoke(new object[] { });
                    ((Controller)classObject).ModelState.Clear();
                    ((Controller)classObject).ModelState.Merge(modelBinder.ModelState);

                    Assert.IsTrue(((Controller)classObject).ModelState.IsValid, "Verify the model state values");
                }
                else
                    Assert.Fail("No class with the name 'BankAccountsController' is implemented OR Did you change the class name");
            }
            catch (Exception)
            {
                Assert.Fail("Adding new account to the database failed. verify the state of model object");
            }
        }

        [Test]
        public void IndexAction_When_Invoked_Return_AccountsList()
        {
            //Arrange 
            BankAccountDBContext db = new BankAccountDBContext();
            try
            {
                className = assembly.GetType("BankAccountsMgmt.Controllers.BankAccountsController");

                if (className != null)
                {
                    MethodInfo testMethod = className.GetMethods().Where(x => x.Name.Equals("Index")
                                           && x.GetParameters().Count() == 0
                                           && x.ReturnType == typeof(ActionResult)).FirstOrDefault();

                    Assert.IsNotNull(testMethod,
                        "Action 'Index' GET NOT implemented with return type 'ActionResult' OR check spelling");

                    ConstructorInfo classConstructor = className.GetConstructor(Type.EmptyTypes);
                    object classObject = classConstructor.Invoke(new object[] { });

                    var viewResult = (ViewResult)testMethod.Invoke(classObject, new object[] { });
                    var accountsList = (IEnumerable<BankAccount>)viewResult.ViewData.Model;
                    Assert.AreEqual(db.BankAccounts.ToList().Count, accountsList.ToList().Count,
                        "Verify whether you fetched the data from the database correctly or not");

                    //to test list is sorted on City
                    var uCities = accountsList.Select(c => c.City).Distinct().ToList();

                    //Copy of the List
                    var nCities = new List<City>(uCities);
                    //new List<City> { City.Delhi, City.Chennai, City.Mumbai, City.Kolkata }; //To test
                    nCities.Sort();
                    //Compare UniqueCities with Sorted UniqueCities
                    bool isSorted = uCities.SequenceEqual(nCities);
                    Assert.That(isSorted, "List should be sorted on City");
                }
                else
                    Assert.Fail("No class with the name 'BankAccountsController' is implemented OR Did you change the class name");
            }
            catch (Exception)
            {
                Assert.Fail("Exception should not be thrown. Please check the application logic");
            }
        }

        [Test]
        public void IndexActionPOST_When_Invoked_Return_FilteredAccountsList()
        {
            //Arrange 
            BankAccountDBContext db = new BankAccountDBContext();
            try
            {
                className = assembly.GetType("BankAccountsMgmt.Controllers.BankAccountsController");

                if (className != null)
                {
                    MethodInfo testMethod = className.GetMethods().Where(x => x.Name.Equals("Index")
                                           && x.GetParameters().Count() == 1
                                           && x.GetParameters().First().ParameterType == typeof(bool)
                                           && x.ReturnType == typeof(ActionResult)).FirstOrDefault();

                    Assert.IsNotNull(testMethod,
                        "Action 'Index' POST NOT implemented with bool parameter and return type 'ActionResult' OR check spelling");

                    ConstructorInfo classConstructor = className.GetConstructor(Type.EmptyTypes);
                    object classObject = classConstructor.Invoke(new object[] { });

                    //Checking for KYC Done - true
                    var viewResult1 = (ViewResult)testMethod.Invoke(classObject, new object[] { true });
                    var accountsList1 = (IEnumerable<BankAccount>)viewResult1.ViewData.Model;

                    Assert.AreEqual(db.BankAccounts.Where(r => r.KYCComplete == true).ToList().Count,
                        accountsList1.ToList().Count,
                        "Verify whether you fetched the filtered data from the database correctly or not");

                    //to test Interest Total based on Filter

                    Assert.AreEqual(db.BankAccounts.Where(r => r.KYCComplete == true).ToList().Sum(i => i.Interest),
                        accountsList1.ToList().Sum(i => i.Interest),
                        "Verify whether you fetched the filtered data from the database correctly or not");

                    //to test list is sorted on City
                    var uCities = accountsList1
                                        .Where(c => c.KYCComplete == true)
                                        .Select(c => c.City).Distinct().ToList();

                    //Copy of the List
                    var nCities = new List<City>(uCities);
                    //new List<City> { City.Delhi, City.Chennai, City.Mumbai, City.Kolkata }; //To test
                    nCities.Sort();
                    //Compare UniqueCities with Sorted UniqueCities
                    bool isSorted = uCities.SequenceEqual(nCities);
                    Assert.That(isSorted, "List should be sorted on City");

                    //Checking for KYC Done - false
                    var viewResult2 = (ViewResult)testMethod.Invoke(classObject, new object[] { false });
                    var accountsList2 = (IEnumerable<BankAccount>)viewResult2.ViewData.Model;

                    Assert.AreEqual(db.BankAccounts.Where(r => r.KYCComplete == false).ToList().Count,
                        accountsList2.ToList().Count,
                        "Verify whether you fetched the filtered data from the database correctly or not");

                    //to test list is sorted on City
                    var uCities2 = accountsList2
                                        .Where(c => c.KYCComplete == false)
                                        .Select(c => c.City).Distinct().ToList();

                    //Copy of the List
                    var nCities2 = new List<City>(uCities2);
                    //new List<City> { City.Delhi, City.Chennai, City.Mumbai, City.Kolkata }; //To test
                    nCities2.Sort();
                    //Compare UniqueCities with Sorted UniqueCities
                    bool isSorted2 = uCities2.SequenceEqual(nCities2);
                    Assert.That(isSorted2, "List should be sorted on City");
                }
                else
                    Assert.Fail("No class with the name 'BankAccountsController' is implemented OR Did you change the class name");
            }
            catch (Exception)
            {
                Assert.Fail("Exception should not be thrown. Please check the application logic");
            }
        }

        [Test]
        public void DetailsAction_Returns_Valid_Account_When_Given_ValidId()
        {
            //Arrange 
            var allBindings = BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;
            BankAccountDBContext db = new BankAccountDBContext();
            try
            {
                className = assembly.GetType("BankAccountsMgmt.Controllers.BankAccountsController");

                if (className != null)
                {
                    MethodInfo testMethod = className.GetMethod("Details", allBindings);
                    Assert.IsNotNull(testMethod, "Action 'Details' NOT implemented OR check spelling");
                    Assert.AreEqual(typeof(ActionResult), testMethod.ReturnType, "The return type of the Details action MUST be 'ActionResult'");

                    ConstructorInfo classConstructor = className.GetConstructor(Type.EmptyTypes);
                    object classObject = classConstructor.Invoke(new object[] { });

                    //Arrange
                    int validId = db.BankAccounts.Max(r => r.AccountID);//getting valid max id

                    var viewResult1 = (ViewResult)testMethod.Invoke(classObject, new object[] { validId });
                    var hospital1 = (BankAccount)viewResult1.ViewData.Model;

                    viewResult1.View = null;

                    int invalidId = validId += 5000;//adding 5000 to valid id to make it invalid to test
                    classObject = classConstructor.Invoke(new object[] { });
                    //Act
                    var viewResult2 = (ViewResult)testMethod.Invoke(classObject, new object[] { invalidId });
                    var hospital2 = (BankAccount)viewResult2.ViewData.Model;

                    //Assert
                    Assert.IsTrue(hospital1 != null && hospital2 == null);
                }
                else
                    Assert.Fail("No class with the name 'CovidHospitalsController' is implemented OR Did you change the class name");
            }
            catch (Exception)
            {
                Assert.Fail("Invalid id, please provide a valid hospital id");
            }
        }

        [Test]
        public void AddBankAccount_SavesToDatabase_IDAutoGenerated_ValidModel()
        {
            //Arrange 
            var allBindings = BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;

            BankAccount accountObj = new BankAccount
            {
                AccountHolderName = "TestHolder",
                PAN = "ABCDE1234Z",
                Amount = 2000,
                Interest = 150.67,
                City = City.Delhi,
                Gender = Gender.Male,
                OpeningDate = DateTime.ParseExact("2020-03-06", "yyyy-MM-dd", null),
                KYCComplete = false
            };
            BankAccountDBContext db = new BankAccountDBContext();
            try
            {
                className = assembly.GetType("BankAccountsMgmt.Controllers.BankAccountsController");

                if (className != null)
                {
                    MethodInfo[] testMethods = className.GetMethods(allBindings);
                    MethodInfo testMethod = default;

                    foreach (var item in testMethods)
                    {
                        if (item.CustomAttributes.Count() > 0)
                        {
                            if (item.IsGenericMethod == false && item.Name.Equals("AddBankAccount")
                                && item.CustomAttributes.First().AttributeType
                                .Name.Equals("HttpPostAttribute"))
                            {
                                testMethod = item;
                                break;
                            }
                        }
                    }

                    Assert.IsNotNull(testMethod, "Action 'AddBankAccount' NOT implemented OR check spelling");

                    ConstructorInfo classConstructor = className.GetConstructor(Type.EmptyTypes);
                    object classObject = classConstructor.Invoke(new object[] { });

                    //Check if database is having records? Otherwise can't get Max()
                    if (db.BankAccounts.Count() == 0)
                    {
                        testMethod.Invoke(classObject, new object[] { accountObj });
                    }

                    //Act 
                    int maxIdBefore = db.BankAccounts.Max(i => i.AccountID);

                    var result = (RedirectToRouteResult)testMethod.Invoke(classObject, new object[] { accountObj });
                    int maxIdAfter = db.BankAccounts.Max(i => i.AccountID);

                    //Assert                     
                    Assert.That(maxIdBefore + 1 == maxIdAfter, "AccountID should be Auto Generated.");
                    Assert.AreEqual("Details", result.RouteValues["action"]);
                }
                else
                    Assert.Fail("No class with the name 'BankAccountsController' is implemented OR Did you change the class name");
            }
            catch (Exception)
            {
                Assert.Fail("Adding new account to the database failed. Exception should not be thrown. Please provide all mandatory fields valid data and check the destination action name.");
            }
        }

        [TestCase]
        public void Model_CalculateInterestMethod_WhenNoSuchMethodFound_WarnsUser()
        {
            if (modelClassName != null)
            {
                MethodInfo testMethod = modelClassName.GetMethods().Where(x => x.Name.Equals("CalculateInterest")
                                           && x.GetParameters().Count() == 0
                                           && x.ReturnType == typeof(void)).FirstOrDefault();
                Assert.IsNotNull(testMethod, "Method CalculateInterest NOT implemented as per the requirement OR check the spelling");
            }
            else
                Assert.Fail("No class with the name 'BankAccount' is implemented  as per the requirement OR Did you change the class name");
        }

        [TestCase]
        public void BankAccountModel_CalculateInterestMethod_ShouldCalculateAsPerGender()
        {
            var allBindings = BindingFlags.IgnoreCase |
                    BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;

            BankAccount accountObj = new BankAccount
            {
                AccountHolderName = "TestHolder",
                PAN = "ABCDE1234Z",
                Amount = 23000,
                City = City.Delhi,
                Gender = Gender.Male,
                OpeningDate = DateTime.ParseExact("2020-03-06", "yyyy-MM-dd", null),
                KYCComplete = false
            };

            object[] parameters = new object[] { };
            try
            {
                if (modelClassName != null)
                {
                    MethodInfo testMethod = modelClassName.GetMethod("CalculateInterest", allBindings);

                    //Testing for Male
                    testMethod.Invoke(accountObj, parameters);
                    double expected = 284.31;
                    Assert.AreEqual(expected, accountObj.Interest);

                    //Testing for Female
                    accountObj.Gender = Gender.Female;
                    testMethod.Invoke(accountObj, parameters);
                    expected = 398.03;
                    Assert.AreEqual(expected, accountObj.Interest);

                    //Testing for Others
                    accountObj.Gender = Gender.Others;
                    testMethod.Invoke(accountObj, parameters);
                    expected = 398.03;
                    Assert.AreEqual(expected, accountObj.Interest);
                }
            }
            catch (Exception ex)
            {
                Assert.Fail("Exception should not be thrown. Please check the input and application logic." + ex.Message);
            }
        }
    }
}
