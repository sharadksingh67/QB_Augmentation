using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Remote;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Reflection;

namespace CovidHospitalsUITests
{
    [TestFixture]
    public abstract class IISServerTest
    {
        private const int WebAppPort = 44330;

        private Process _webHostProcess;
        private readonly string _applicationName;

        protected IISServerTest(string applicationName)
        {
            _applicationName = applicationName;
        }

        [SetUp]
        public void TestInitialize()
        {
            // Start IISExpress here
            StartIIS();

            Initialize();
        }

        [TearDown]
        public void TestCleanup()
        {
            Cleanup();
            // Make sure that IISExpress is stopped here
            if (_webHostProcess.HasExited == false)
            {
                _webHostProcess.Kill();
            }
        }

        public abstract void Initialize();

        public abstract void Cleanup();

        private void StartIIS()
        {
            var applicationPath = GetApplicationPath(_applicationName);
            var key = Environment.Is64BitOperatingSystem ? "programfiles(x86)" : "programfiles";
            var programfiles = Environment.GetEnvironmentVariable(key);

            var iisExpressStartInfo = new ProcessStartInfo
            {
                WindowStyle = ProcessWindowStyle.Normal,
                ErrorDialog = true,
                LoadUserProfile = true,
                CreateNoWindow = false,
                UseShellExecute = false,
                Arguments = String.Format("/path:\"{0}\" /port:{1}", applicationPath, WebAppPort),
                FileName = string.Format("{0}\\IIS Express\\iisexpress.exe", programfiles)
            };
            _webHostProcess = Process.Start(iisExpressStartInfo);
        }

        protected virtual string GetApplicationPath(string applicationName)
        {
            var solutionFolder = Path.GetDirectoryName(Path.GetDirectoryName(Path.GetDirectoryName(AppDomain.CurrentDomain.BaseDirectory)));
            return Path.Combine(solutionFolder, applicationName);
        }

        public string GetAbsoluteUrl(string relativeUrl)
        {
            return String.Format(@"https://localhost:{0}/{1}", WebAppPort, relativeUrl);
        }
    }

    public abstract class SeleniumTest : IISServerTest
    {
        private RemoteWebDriver _remoteWebDriver;
        protected IWebDriver WebDriver
        {
            get { return _remoteWebDriver; }
        }

        protected SeleniumTest(string applicationName) : base(applicationName)
        {
        }

        public override void Initialize()
        {
            _remoteWebDriver = new ChromeDriver();
        }

        public override void Cleanup()
        {
            _remoteWebDriver.Dispose();
        }
    }

    [TestFixture]
    public class CovidHospitalsMgmtTests : SeleniumTest, IDisposable
    {
        public CovidHospitalsMgmtTests() : base("Covid Hospitals Management")
        {

        }

        [Test]
        public void Test_Index()
        {
            try
            {                
                WebDriver.Navigate().GoToUrl(GetAbsoluteUrl("CovidHospitals/Index"));

                //Maximize the window
                WebDriver.Manage().Window.Maximize();

                Assert.AreEqual("Index - Covid Hospitals Management", WebDriver.Title);
                var links = WebDriver.FindElements(By.TagName("a"));

                Assert.AreEqual("Covid Hospitals Management", links[0].Text);
                Assert.AreEqual("Hospitals List", links[1].Text);
                Assert.AreEqual("Create New", links[2].Text);

                IWebElement searchText1 = WebDriver.FindElement(By.XPath("//*[text() = 'Hospital Name']"));
                IWebElement searchText2 = WebDriver.FindElement(By.XPath("//*[text() = 'City']"));
                IWebElement searchText3 = WebDriver.FindElement(By.XPath("//*[text() = 'Start Date']"));
                IWebElement searchText4 = WebDriver.FindElement(By.XPath("//*[text() = 'Open for Online Registrations?']"));
                IWebElement searchText5 = WebDriver.FindElement(By.XPath("//*[text() = 'No of Beds']"));

            }
            catch (Exception)
            {
                Assert.Fail("Exception should not occur here. Verify the value entered");
            }
        }

        [Test]
        public void Test_AddCovidHospitalView()
        {
            try
            {
                WebDriver.Navigate().GoToUrl(GetAbsoluteUrl(@"CovidHospitals/AddCovidHospital"));
             
                //Maximize the window
                WebDriver.Manage().Window.Maximize();

                IWebElement searchText2 = WebDriver.FindElement(By.XPath("//*[text() = 'Create']"));
                IWebElement searchText3 = WebDriver.FindElement(By.XPath("//*[text() = 'Covid Hospital']"));
                                          
                IWebElement searchText4 = WebDriver.FindElement(By.Id("HospitalName"));
                IWebElement searchText5 = WebDriver.FindElement(By.Id("City"));
                IWebElement searchText6 = WebDriver.FindElement(By.Id("Beds"));
                IWebElement searchText7 = WebDriver.FindElement(By.Id("StartDate"));

            }
            catch (Exception)
            {
                Assert.Fail("Exception should not occur here. Verify the value entered");
            }
        }

        [Test]
        public void Test_AddCovidHospital_RequiredFields()
        {
            try
            {
                WebDriver.Navigate().GoToUrl(GetAbsoluteUrl(@"CovidHospitals/AddCovidHospital"));

                //Maximize the window
                WebDriver.Manage().Window.Maximize();

                IWebElement searchText1 = WebDriver.FindElement(By.Id("Submit"));
                searchText1.Click();
                System.Threading.Thread.Sleep(2000);

                IWebElement searchText12 = WebDriver.FindElement(By.XPath("//*[text() = 'Please Provide Hospital Name']"));
                IWebElement searchText13 = WebDriver.FindElement(By.XPath("//*[text() = 'Please Select a City']"));
                IWebElement searchText14 = WebDriver.FindElement(By.XPath("//*[text() = 'Should be between 100 and 900']"));
                IWebElement searchText15 = WebDriver.FindElement(By.XPath("//*[text() = 'Please Provide Valid Date']"));
                IWebElement searchText16 = WebDriver.FindElement(By.XPath("//*[text() = 'Please Select a City']"));

            }
            catch (Exception)
            {
                Assert.Fail("Exception should not occur here. Verify the value entered");
            }
        }

        [Test]
        public void Test_AddCovidHospital_ValidData()
        {
            try
            {
                WebDriver.Navigate().GoToUrl(GetAbsoluteUrl(@"CovidHospitals/AddCovidHospital"));

                //Maximize the window
                WebDriver.Manage().Window.Maximize();

                WebDriver.FindElement(By.Id("HospitalName")).SendKeys("Hospital1");
                WebDriver.FindElement(By.Id("City")).SendKeys("Delhi");
                WebDriver.FindElement(By.Id("Beds")).SendKeys("250");
                WebDriver.FindElement(By.Id("StartDate")).SendKeys("05/02/2020");

                WebDriver.FindElement(By.Id("Submit")).Click();

                Assert.AreEqual("Covid Hospital added successfully!", 
                                    WebDriver.FindElement(By.Id("message")).Text);
            }
            catch (Exception ex)
            {
                Assert.Fail("Exception should not occur here. Verify the value entered");
            }
        }

        [Test]
        public void Test_Details()
        {
            try
            {
                WebDriver.Navigate().GoToUrl(GetAbsoluteUrl(@"CovidHospitals/Details/2"));

                //Maximize the window
                WebDriver.Manage().Window.Maximize();

                Assert.AreEqual("Details - Covid Hospitals Management", WebDriver.Title);
                var links = WebDriver.FindElements(By.TagName("a"));

                Assert.AreEqual("Back to List", links[3].Text);
                var h4Element = WebDriver.FindElement(By.TagName("h4"));
                Assert.AreEqual("Covid Hospital added successfully!", h4Element.Text);
            }
            catch (Exception)
            {
                Assert.Fail("Exception should not occur here. Verify the value entered");
            }
        }

        [Test]
        public void Test_Details_BackToList()
        {
            try
            {
                WebDriver.Navigate().GoToUrl(GetAbsoluteUrl(@"CovidHospitals/Details/2"));

                //Maximize the window
                WebDriver.Manage().Window.Maximize();

                Assert.AreEqual("Details - Covid Hospitals Management", WebDriver.Title);
                var links = WebDriver.FindElements(By.TagName("a"));

                Assert.AreEqual("Back to List", links[3].Text);
                links[3].Click();
                Assert.AreEqual("Index - Covid Hospitals Management", WebDriver.Title);

            }
            catch (Exception)
            {
                Assert.Fail("Exception should not occur here. Verify the value entered");
            }
        }


        public void Dispose()
        {
            WebDriver.Quit();
            WebDriver.Dispose();
        }
    }
}
