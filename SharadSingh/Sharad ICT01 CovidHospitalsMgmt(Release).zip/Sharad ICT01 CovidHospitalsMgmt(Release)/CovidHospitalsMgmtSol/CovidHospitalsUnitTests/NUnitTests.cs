﻿using CovidHospitalsMgmt.Controllers;
using CovidHospitalsMgmt.Data;
using CovidHospitalsMgmt.Models;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Web.Mvc;

namespace CovidHospitalsUnitTests
{
    [TestFixture]
    public class NUnitTests
    {
        Assembly assembly;
        Type className, dbContextclassName;

        [SetUp]
        public void Setup()
        {
            assembly = Assembly.Load("CovidHospitalsMgmt");
            className = assembly.GetType("CovidHospitalsMgmt.Controllers.CovidHospitalsController");
            dbContextclassName = assembly.GetType("CovidHospitalsMgmt.Data.CovidHospitalDBContext");
        }

        [TestCase]
        public void Test_Controller_ClassExistence()
        {
            if (className == null)
                Assert.Fail("No controller class with the name 'CovidHospitalsController' is implemented OR Did you change the class name");
        }

        [TestCase]
        public void Test_DBContext_ClassExistence()
        {
            if (dbContextclassName == null)
                Assert.Fail("No DBContext class with the name 'CovidHospitalDBContext' is implemented as required OR Did you change the class name");            
        }

        [TestCase]
        public void Test1_Index_ActionMethodExist()
        {
            if (className != null)
            {
                MethodInfo testMethod = className.GetMethods().Where(x => x.Name.Equals("Index")
                                           && x.GetParameters().Count() == 0
                                           && x.ReturnType == typeof(ActionResult)).FirstOrDefault();
                Assert.IsNotNull(testMethod, "Method Index NOT implemented as per the requirement OR check the spelling");
            }
            else
                Assert.Fail("No class with the name 'CovidHospitalsController' is implemented  as per the requirement OR Did you change the class name");
        }

        [TestCase]
        public void Test2_AddCovidHospital_ActionMethodExist()
        {
            if (className != null)
            {
                MethodInfo testMethod = className.GetMethods().Where(x => x.Name.Equals("AddCovidHospital")
                                           && x.GetParameters().Count() == 0
                                           && x.ReturnType == typeof(ActionResult)).FirstOrDefault();

                Assert.IsNotNull(testMethod, "Method AddCovidHospital NOT implemented as per the requirement OR check the spelling");
            }
            else
                Assert.Fail("No class with the name 'CovidHospitalsController' is implemented  as per the requirement OR Did you change the class name");
        }

        [TestCase]
        public void Test3_AddCovidHospital_PostActionMethodExist()
        {

            if (className != null)
            {
                MethodInfo testMethod = className.GetMethods().Where(x => x.Name.Equals("AddCovidHospital")
                                            && x.GetParameters().Count() == 1
                                            && x.GetParameters().First().ParameterType == typeof(CovidHospital)
                                            && x.ReturnType == typeof(ActionResult)
                                            && x.CustomAttributes.First().AttributeType.Name
                                                    .Equals("HttpPostAttribute")).FirstOrDefault();

                Assert.IsNotNull(testMethod, "Method AddCovidHospital NOT implemented as per the requirement OR check the spelling");
            }
            else
                Assert.Fail("No class with the name 'CovidHospitalsController' is implemented  as per the requirement OR Did you change the class name");
        }

        [TestCase]
        public void Test4_Details_ActionMethodExist()
        {
            if (className != null)
            {
                MethodInfo testMethod = className.GetMethods().Where(x => x.Name.Equals("Details")
                                            && x.GetParameters().Count() == 1
                                            && x.GetParameters().First().ParameterType == typeof(int)
                                            && x.ReturnType == typeof(ActionResult)).FirstOrDefault();

                Assert.IsNotNull(testMethod, "Method Details NOT implemented as per the requirement OR check the spelling");
            }
            else
                Assert.Fail("No class with the name 'CovidHospitalsController' is implemented  as per the requirement OR Did you change the class name");
        }

        [Test]
        public void TestDetailsAction_ForInvalidId()
        {
            //Arrange 
            var allBindings = BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;
            CovidHospitalDBContext db = new CovidHospitalDBContext();
            try
            {
                className = assembly.GetType("CovidHospitalsMgmt.Controllers.CovidHospitalsController");

                if (className != null)
                {
                    MethodInfo testMethod = className.GetMethod("Details", allBindings);
                    Assert.IsNotNull(testMethod, "Action 'Details' NOT implemented OR check spelling");
                    Assert.AreEqual(typeof(ActionResult), testMethod.ReturnType, "Action 'Index' return type MUST be 'ActionResult'");

                    ConstructorInfo classConstructor = className.GetConstructor(Type.EmptyTypes);
                    object classObject = classConstructor.Invoke(new object[] { });

                    //Arrange
                    int validId = db.CovidHospitals.Max(r => r.HospitalID);//getting valid max id
                    int invalidId = validId += 5000;//adding 5000 to valid id to make it invalid to test

                    //Act
                    var viewResult = (ViewResult)testMethod.Invoke(classObject, new object[] { invalidId });
                    var hospital = (CovidHospital)viewResult.ViewData.Model;

                    //Assert
                    Assert.Null(hospital);
                }
                else
                    Assert.Fail("No class with the name 'CovidHospitalsController' is implemented OR Did you change the class name");
            }
            catch (Exception ex)
            {
                Assert.Fail("Invalid id, please provide a valid hospital id");
            }
        }

        [Test]
        public void TestDetailsAction_ForValidId()
        {
            //Arrange 
            var allBindings = BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;
            CovidHospitalDBContext db = new CovidHospitalDBContext();
            try
            {
                className = assembly.GetType("CovidHospitalsMgmt.Controllers.CovidHospitalsController");

                if (className != null)
                {
                    MethodInfo testMethod = className.GetMethod("Details", allBindings);
                    Assert.IsNotNull(testMethod, "Action 'Details' NOT implemented OR check spelling");
                    Assert.AreEqual(typeof(ActionResult), testMethod.ReturnType, "Action 'Index' return type MUST be 'ActionResult'");

                    ConstructorInfo classConstructor = className.GetConstructor(Type.EmptyTypes);
                    object classObject = classConstructor.Invoke(new object[] { });

                    //Arrange
                    int validId = db.CovidHospitals.Max(r => r.HospitalID);//getting valid max id                    

                    //Act
                    var viewResult = (ViewResult)testMethod.Invoke(classObject, new object[] { validId });
                    var hospital = (CovidHospital)viewResult.ViewData.Model;

                    //Assert
                    Assert.IsNotNull(hospital);
                }
                else
                    Assert.Fail("No class with the name 'CovidHospitalsController' is implemented OR Did you change the class name");
            }
            catch (Exception ex)
            {
                Assert.Fail("Invalid id, please provide a valid hospital id");
            }
        }


        [Test]
        public void TestIndexAction_ReturnHospitalList()
        {
            //Arrange 
            var allBindings = BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;

            CovidHospitalDBContext db = new CovidHospitalDBContext();

            try
            {
                className = assembly.GetType("CovidHospitalsMgmt.Controllers.CovidHospitalsController");

                if (className != null)
                {
                    MethodInfo testMethod = className.GetMethod("Index", allBindings);
                    Assert.IsNotNull(testMethod, "Action 'Index' NOT implemented OR check spelling");
                    Assert.AreEqual(typeof(ActionResult), testMethod.ReturnType, "Action 'Index' return type MUST be 'ActionResult'");

                    ConstructorInfo classConstructor = className.GetConstructor(Type.EmptyTypes);
                    object classObject = classConstructor.Invoke(new object[] { });

                    var viewResult = (ViewResult)testMethod.Invoke(classObject, new object[] { });
                    var hospitalList = (IEnumerable<CovidHospital>)viewResult.ViewData.Model;
                    Assert.AreEqual(db.CovidHospitals.ToList().Count, hospitalList.ToList().Count);

                    //to test list is sorted on City
                    var uCities = hospitalList.Select(c => c.City).Distinct().ToList();

                    //Copy of the List
                    var nCities = new List<City>(uCities);
                    //new List<City> { City.Delhi, City.Chennai, City.Mumbai, City.Kolkata }; //To test
                    nCities.Sort();
                    //Compare UniqueCities with Sorted UniqueCities
                    bool isSorted = uCities.SequenceEqual(nCities);
                    Assert.That(isSorted, "List should be sorted on City");
                }
                else
                    Assert.Fail("No class with the name 'CovidHospitalsController' is implemented OR Did you change the class name");
            }
            catch (Exception ex)
            {
                Assert.Fail("Exception should not be thrown. Please check the application logic");
            }
        }

        [Test]
        public void TestAddCovidHospital_SavesToDatabase_IDAutoGenerated_ValidModel()
        {
            //Arrange 
            var allBindings = BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;

            CovidHospital hospitalObj = new CovidHospital
            {
                HospitalName = "Test Hospital",
                Beds = 100,
                City = City.Delhi,
                StartDate = DateTime.ParseExact("2020-03-06", "yyyy-MM-dd", null),
                OnlineRegistrations = false
            };
            CovidHospitalDBContext db = new CovidHospitalDBContext();
            try
            {
                className = assembly.GetType("CovidHospitalsMgmt.Controllers.CovidHospitalsController");

                if (className != null)
                {
                    MethodInfo[] testMethods = className.GetMethods(allBindings);
                    MethodInfo testMethod = default;

                    foreach (var item in testMethods)
                    {
                        if (item.CustomAttributes.Count() > 0)
                        {
                            if (item.IsGenericMethod == false && item.Name.Equals("AddCovidHospital")
                                && item.CustomAttributes.First().AttributeType
                                .Name.Equals("HttpPostAttribute"))
                            {
                                testMethod = item;
                                break;
                            }
                        }
                    }
                    Assert.IsNotNull(testMethod, "Action 'AddCovidHospital' NOT implemented OR check spelling");
                    int maxIdBefore = db.CovidHospitals.Max(i => i.HospitalID);

                    ConstructorInfo classConstructor = className.GetConstructor(Type.EmptyTypes);
                    object classObject = classConstructor.Invoke(new object[] { });

                    //Act 
                    var result = (RedirectToRouteResult)testMethod.Invoke(classObject, new object[] { hospitalObj });
                    int maxIdAfter = db.CovidHospitals.Max(i => i.HospitalID);

                    //Assert                     
                    Assert.That(maxIdBefore + 1 == maxIdAfter, "HospitalID should be Auto Generated.");
                    Assert.AreEqual("Details", result.RouteValues["action"]);
                }
                else
                    Assert.Fail("No class with the name 'CovidHospitalsController' is implemented OR Did you change the class name");
            }
            catch (Exception)
            {
                Assert.Fail("Adding new hospital to the database failed. Exception should not be thrown. Please provide all mandatory fields valid data and check the destination action name.");
            }
        }

        [Test]
        public void TestAddCovidHospitalAction_NameNull()
        {
            //Arrange 
            var allBindings = BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;

            var covidHospitalsController = new CovidHospitalsController();
            CovidHospitalDBContext db = new CovidHospitalDBContext();
            CovidHospital hospital = new CovidHospital()
            {
                HospitalName = null,
                City = City.Delhi,
                Beds = 100,
                StartDate = DateTime.Today,
                OnlineRegistrations = true
            };
            //Initialize ModelState 
            var modelBinder = new ModelBindingContext()
            {
                ModelMetadata = ModelMetadataProviders.Current.GetMetadataForType(
                                  () => hospital, hospital.GetType()),
                ValueProvider = new NameValueCollectionValueProvider(
                                    new NameValueCollection(), CultureInfo.InvariantCulture)
            };
            var binder = new DefaultModelBinder().BindModel(
                             new ControllerContext(), modelBinder);

            try
            {
                className = assembly.GetType("CovidHospitalsMgmt.Controllers.CovidHospitalsController");

                if (className != null)
                {
                    MethodInfo[] testMethods = className.GetMethods(allBindings);
                    MethodInfo testMethod = default;

                    foreach (var item in testMethods)
                    {
                        if (item.CustomAttributes.Count() > 0)
                        {
                            if (item.IsGenericMethod == false && item.Name.Equals("AddCovidHospital")
                                && item.CustomAttributes.First().AttributeType
                                .Name.Equals("HttpPostAttribute"))
                            {
                                testMethod = item;
                                break;
                            }
                        }
                    }

                    Assert.IsNotNull(testMethod, "Action 'AddCovidHospital' NOT implemented OR check spelling");

                    ConstructorInfo classConstructor = className.GetConstructor(Type.EmptyTypes);
                    object classObject = classConstructor.Invoke(new object[] { });
                    ((Controller)classObject).ModelState.Clear();
                    ((Controller)classObject).ModelState.Merge(modelBinder.ModelState);

                    //Act 
                    var result = (ViewResult)testMethod.Invoke(classObject, new object[] { hospital });

                    //Assert 
                    Assert.IsTrue(result.ViewData.ModelState.Values.ToList()[0].Errors[0].ErrorMessage.Equals("Please Provide Hospital Name"),
                        "Adding hospital to the database failed. Name can't be empty, please provide valid data for Name and also check the error message");
                }
                else
                    Assert.Fail("No class with the name 'CovidHospitalsController' is implemented OR Did you change the class name");
            }
            catch (Exception)
            {
                Assert.Fail("Adding new hospital to the database failed. Name can't be empty, please provide valid data for Name");
            }
        }

        [Test]
        public void TestAddCovidHospitalAction_CityNull()
        {
            //Arrange 
            var allBindings = BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;

            var covidHospitalsController = new CovidHospitalsController();
            CovidHospitalDBContext db = new CovidHospitalDBContext();
            CovidHospital hospital = new CovidHospital()
            {
                HospitalName = "Test Name",
                City = City.Select,
                Beds = 100,
                StartDate = DateTime.Today,
                OnlineRegistrations = true
            };
            //Initialize ModelState 
            var modelBinder = new ModelBindingContext()
            {
                ModelMetadata = ModelMetadataProviders.Current.GetMetadataForType(
                                  () => hospital, hospital.GetType()),
                ValueProvider = new NameValueCollectionValueProvider(
                                    new NameValueCollection(), CultureInfo.InvariantCulture)
            };
            var binder = new DefaultModelBinder().BindModel(
                             new ControllerContext(), modelBinder);

            try
            {
                className = assembly.GetType("CovidHospitalsMgmt.Controllers.CovidHospitalsController");

                if (className != null)
                {
                    MethodInfo[] testMethods = className.GetMethods(allBindings);
                    MethodInfo testMethod = default;

                    foreach (var item in testMethods)
                    {
                        if (item.CustomAttributes.Count() > 0)
                        {
                            if (item.IsGenericMethod == false && item.Name.Equals("AddCovidHospital")
                                && item.CustomAttributes.First().AttributeType
                                .Name.Equals("HttpPostAttribute"))
                            {
                                testMethod = item;
                                break;
                            }
                        }
                    }

                    Assert.IsNotNull(testMethod, "Action 'AddCovidHospital' NOT implemented OR check spelling");

                    ConstructorInfo classConstructor = className.GetConstructor(Type.EmptyTypes);
                    object classObject = classConstructor.Invoke(new object[] { });
                    ((Controller)classObject).ModelState.Clear();
                    ((Controller)classObject).ModelState.Merge(modelBinder.ModelState);

                    //Act 
                    var result = (ViewResult)testMethod.Invoke(classObject, new object[] { hospital });

                    //Assert 
                    Assert.IsTrue(result.ViewData.ModelState.Values.ToList()[0].Errors[0].ErrorMessage.Equals("Please Select a City"),
                        "Adding hospital to the database failed. City is not selected, please select a city and also check the error message");
                }
                else
                    Assert.Fail("No class with the name 'CovidHospitalsController' is implemented OR Did you change the class name");
            }
            catch (Exception ex)
            {
                Assert.Fail("Adding new hospital to the database failed. City is not selected, please select a city ");
            }
        }

        [Test]
        public void TestAddCovidHospitalAction_BedsNull()
        {
            //Arrange 
            var allBindings = BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;

            var covidHospitalsController = new CovidHospitalsController();
            CovidHospitalDBContext db = new CovidHospitalDBContext();
            CovidHospital hospital = new CovidHospital()
            {
                HospitalName = "Test Name",
                City = City.Delhi,
                Beds = 0,
                StartDate = DateTime.Today,
                OnlineRegistrations = true
            };
            //Initialize ModelState 
            var modelBinder = new ModelBindingContext()
            {
                ModelMetadata = ModelMetadataProviders.Current.GetMetadataForType(
                                  () => hospital, hospital.GetType()),
                ValueProvider = new NameValueCollectionValueProvider(
                                    new NameValueCollection(), CultureInfo.InvariantCulture)
            };
            var binder = new DefaultModelBinder().BindModel(
                             new ControllerContext(), modelBinder);

            try
            {
                className = assembly.GetType("CovidHospitalsMgmt.Controllers.CovidHospitalsController");

                if (className != null)
                {
                    MethodInfo[] testMethods = className.GetMethods(allBindings);
                    MethodInfo testMethod = default;

                    foreach (var item in testMethods)
                    {
                        if (item.CustomAttributes.Count() > 0)
                        {
                            if (item.IsGenericMethod == false && item.Name.Equals("AddCovidHospital")
                                && item.CustomAttributes.First().AttributeType
                                .Name.Equals("HttpPostAttribute"))
                            {
                                testMethod = item;
                                break;
                            }
                        }
                    }

                    Assert.IsNotNull(testMethod, "Action 'AddCovidHospital' NOT implemented OR check spelling");

                    ConstructorInfo classConstructor = className.GetConstructor(Type.EmptyTypes);
                    object classObject = classConstructor.Invoke(new object[] { });
                    ((Controller)classObject).ModelState.Clear();
                    ((Controller)classObject).ModelState.Merge(modelBinder.ModelState);

                    //Act 
                    var result = (ViewResult)testMethod.Invoke(classObject, new object[] { hospital });

                    //Assert 
                    Assert.IsTrue(result.ViewData.ModelState.Values.ToList()[0].Errors[0].ErrorMessage.Equals("Should be between 100 and 900"),
                        "Adding hospital to the database failed. Number of Beds not provided, Please Provide Number of Beds and also check the error message");
                }
                else
                    Assert.Fail("No class with the name 'CovidHospitalsController' is implemented OR Did you change the class name");
            }
            catch (Exception ex)
            {
                Assert.Fail("Adding new hospital to the database failed. No of Beds can't be empty, please provide valid data for Beds");
            }
        }

        [Test]
        public void TestAddCovidHospitalAction_StartDateNull()
        {
            //Arrange 
            var allBindings = BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;

            var covidHospitalsController = new CovidHospitalsController();
            CovidHospitalDBContext db = new CovidHospitalDBContext();
            CovidHospital hospital = new CovidHospital()
            {
                HospitalName = "Test Name",
                City = City.Delhi,
                Beds = 200,
                //StartDate = DateTime.Today,
                OnlineRegistrations = true
            };
            //Initialize ModelState 
            var modelBinder = new ModelBindingContext()
            {
                ModelMetadata = ModelMetadataProviders.Current.GetMetadataForType(
                                  () => hospital, hospital.GetType()),
                ValueProvider = new NameValueCollectionValueProvider(
                                    new NameValueCollection(), CultureInfo.InvariantCulture)
            };
            var binder = new DefaultModelBinder().BindModel(
                             new ControllerContext(), modelBinder);

            try
            {
                className = assembly.GetType("CovidHospitalsMgmt.Controllers.CovidHospitalsController");

                if (className != null)
                {
                    MethodInfo[] testMethods = className.GetMethods(allBindings);
                    MethodInfo testMethod = default;

                    foreach (var item in testMethods)
                    {
                        if (item.CustomAttributes.Count() > 0)
                        {
                            if (item.IsGenericMethod == false && item.Name.Equals("AddCovidHospital")
                                && item.CustomAttributes.First().AttributeType
                                .Name.Equals("HttpPostAttribute"))
                            {
                                testMethod = item;
                                break;
                            }
                        }
                    }

                    Assert.IsNotNull(testMethod, "Action 'AddCovidHospital' NOT implemented OR check spelling");

                    ConstructorInfo classConstructor = className.GetConstructor(Type.EmptyTypes);
                    object classObject = classConstructor.Invoke(new object[] { });
                    ((Controller)classObject).ModelState.Clear();
                    ((Controller)classObject).ModelState.Merge(modelBinder.ModelState);

                    //Act 
                    var result = (ViewResult)testMethod.Invoke(classObject, new object[] { hospital });

                    //Assert 
                    Assert.IsTrue(result.ViewData.ModelState.Values.ToList()[0].Errors[0].ErrorMessage.Equals("Please Provide Valid Date"),
                        "Adding hospital to the database failed. Please Provide Valid Date and also check the error message");
                }
                else
                    Assert.Fail("No class with the name 'CovidHospitalsController' is implemented OR Did you change the class name");
            }
            catch (Exception ex)
            {
                Assert.Fail("Adding new hospital to the database failed. Please Provide Valid Start Date");
            }
        }

    }
}
