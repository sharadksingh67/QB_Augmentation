﻿using CovidHospitalsMgmt.Data;
using CovidHospitalsMgmt.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CovidHospitalsMgmt.Controllers
{
    [CustomFilters.CustomExceptionFilter]
    public class CovidHospitalsController : Controller
    {
        // GET
        public ActionResult Index()
        {
            var context = new CovidHospitalDBContext();
            var list = context.CovidHospitals
                                .OrderBy(h => h.City)
                                .Select(h => h)
                                .ToList<CovidHospital>();
            return View(list);
        }

        public ActionResult AddCovidHospital()
        {
            CovidHospital res = new CovidHospital();
            return View(res);
        }

        [HttpPost]
        public ActionResult AddCovidHospital(CovidHospital CovidHospital)
        {
            if (ModelState.IsValid)
            {
                ViewBag.msg = "CovidHospital added successfully!";
                var context = new CovidHospitalDBContext();            
                context.CovidHospitals.Add(CovidHospital);
                context.SaveChanges();
                return RedirectToAction("Details", 
                    new { id = CovidHospital.HospitalID });
            }
            return View();
        }
        
        public ActionResult Details(int id)
        {
            var db = new CovidHospitalDBContext();
            var model = db.CovidHospitals
                            .Where(r => r.HospitalID == id)
                            .FirstOrDefault();
            return View(model);
        }
    }
}
