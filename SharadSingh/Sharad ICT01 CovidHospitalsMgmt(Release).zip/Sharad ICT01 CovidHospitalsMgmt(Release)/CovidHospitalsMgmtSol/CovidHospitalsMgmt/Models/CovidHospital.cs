﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace CovidHospitalsMgmt.Models
{
    public enum City
    {
        Select,
        Chennai,
        Delhi,
        Kolkata,
        Mumbai
    }

    public class CovidHospital 
    {
        [Key]
        public int HospitalID { get; set; }

        [Required(ErrorMessage = "Please Provide Hospital Name")]
        [MaxLength(255)]
        [Display(Name = "Hospital Name")]
        public string HospitalName { get; set; }

        [Required, Range(1,4, ErrorMessage = "Please Select a City")]
        [Display(Name = "City")]
        public City City { get; set; }
                
        [Display(Name = "Open for Online Registrations?")]
        public bool OnlineRegistrations { get; set; }
                
        [Required]
        [Display(Name = "No of Beds")]
        [Range(100,900, ErrorMessage ="Should be between 100 and 900")]
        public int Beds { get; set; }

        [Required(ErrorMessage = "Please Provide Valid Date")]
        [DataType(DataType.Date)]
        [Display(Name = "Start Date")]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yy}", ApplyFormatInEditMode = true)]
        public DateTime? StartDate { get; set; }

    }
}