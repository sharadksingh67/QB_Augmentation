﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using CovidHospitalsMgmt.Models;

namespace CovidHospitalsMgmt.Data
{
    public class CovidHospitalDBContext : DbContext
    {
        public CovidHospitalDBContext():base("name=CHM_DB")
        {
        }
        public DbSet<CovidHospital>  CovidHospitals { get; set; }
    }
}