﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CovidHospitalsMgmt.Controllers
{
    public class CovidHospitalsController : Controller
    {
        // GET
        public ActionResult Index()
        {
            //Implement your code
            return View();
        }

        //Implement your code
    }
}
