﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;


namespace CovidHospitalsMgmt.Data
{
    public class CovidHospitalDBContext 
    {
        //Implement your code
    }
}