﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace CovidHospitalsMgmt.Models
{
    public enum City
    {
        Select,
        Chennai,
        Delhi,
        Kolkata,
        Mumbai
    }

    public class CovidHospital 
    {
        //Implement data annotations

        public int HospitalID { get; set; }

        public string HospitalName { get; set; }

        public City City { get; set; }
                
        public bool OnlineRegistrations { get; set; }
                
        public int Beds { get; set; }

        public DateTime? StartDate { get; set; }

    }
}