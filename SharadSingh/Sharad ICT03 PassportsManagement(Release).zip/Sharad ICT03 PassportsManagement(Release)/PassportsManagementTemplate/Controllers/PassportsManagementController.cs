﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.UI.WebControls;

namespace PassportsManagement.Controllers
{
    // GET: PassportsManagement
    [CustomFilters.CustomExceptionFilter]
    public class PassportsManagementController : Controller
    {
        // GET
        public ActionResult Index()
        {
            //Implement your code
            return View(list);
        }
        //Implement other required Action Methods
    }
}
