﻿using PassportsManagement.Data;
using PassportsManagement.Models;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Remote;
using System;
using System.Linq;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Reflection;

namespace PassportsManagementUITests
{
    [TestFixture]
    public abstract class IISServerTest
    {
        private const int WebAppPort = 58954;

        private Process _webHostProcess;
        private readonly string _applicationName;

        protected IISServerTest(string applicationName)
        {
            _applicationName = applicationName;
        }

        [SetUp]
        public void TestInitialize()
        {
            // Start IISExpress here
            StartIIS();

            Initialize();
        }

        [TearDown]
        public void TestCleanup()
        {
            Cleanup();
            // Make sure that IISExpress is stopped here
            if (_webHostProcess.HasExited == false)
            {
                _webHostProcess.Kill();
            }
        }

        public abstract void Initialize();

        public abstract void Cleanup();

        private void StartIIS()
        {
            var applicationPath = GetApplicationPath(_applicationName);
            var key = Environment.Is64BitOperatingSystem ? "programfiles(x86)" : "programfiles";
            var programfiles = Environment.GetEnvironmentVariable(key);

            var iisExpressStartInfo = new ProcessStartInfo
            {
                WindowStyle = ProcessWindowStyle.Normal,
                ErrorDialog = true,
                LoadUserProfile = true,
                CreateNoWindow = false,
                UseShellExecute = false,
                Arguments = String.Format("/path:\"{0}\" /port:{1}", applicationPath, WebAppPort),
                FileName = string.Format("{0}\\IIS Express\\iisexpress.exe", programfiles)
            };
            _webHostProcess = Process.Start(iisExpressStartInfo);
        }

        protected virtual string GetApplicationPath(string applicationName)
        {
            var solutionFolder = Path.GetDirectoryName(Path.GetDirectoryName(Path.GetDirectoryName(AppDomain.CurrentDomain.BaseDirectory)));
            return Path.Combine(solutionFolder, applicationName);
        }

        public string GetAbsoluteUrl(string relativeUrl)
        {
            return String.Format(@"http://localhost:{0}/{1}", WebAppPort, relativeUrl);
        }
    }

    public abstract class SeleniumTest : IISServerTest
    {
        private RemoteWebDriver _remoteWebDriver;
        protected IWebDriver WebDriver
        {
            get { return _remoteWebDriver; }
        }

        protected SeleniumTest(string applicationName) : base(applicationName)
        {
        }

        public override void Initialize()
        {
            _remoteWebDriver = new ChromeDriver();
        }

        public override void Cleanup()
        {
            _remoteWebDriver.Dispose();
        }
    }

    [TestFixture]
    public class PassportsManagementTests : SeleniumTest, IDisposable
    {
        public PassportsManagementTests() : base("Passports Management")
        {

        }

        [Test]
        public void Test_Index()
        {
            try
            {
                WebDriver.Navigate().GoToUrl(GetAbsoluteUrl("PassportsManagement/Index"));

                //Maximize the window
                WebDriver.Manage().Window.Maximize();

                Assert.AreEqual("Index - Passports Management", WebDriver.Title);

                WebDriver.FindElement(By.LinkText("Passports Management"));
                WebDriver.FindElement(By.LinkText("Passports List"));
                WebDriver.FindElement(By.LinkText("Create New"));

                IWebElement searchText0 = WebDriver.FindElement(By.XPath("//*[text() = 'Passport Holder Name']"));
                IWebElement searchText1 = WebDriver.FindElement(By.XPath("//*[text() = 'Passport Number']"));
                IWebElement searchText2 = WebDriver.FindElement(By.XPath("//*[text() = 'PAN Number']"));                
                IWebElement searchText3 = WebDriver.FindElement(By.XPath("//*[text() = 'Gender']"));
                IWebElement searchText4 = WebDriver.FindElement(By.XPath("//*[text() = 'Passport Fee']"));
                IWebElement searchText6 = WebDriver.FindElement(By.XPath("//*[text() = 'Date of Birth']"));
                IWebElement searchText7 = WebDriver.FindElement(By.XPath("//*[text() = 'Is Tatkal?']"));
                IWebElement searchText8 = WebDriver.FindElement(By.XPath("//*[text() = 'Booklet Pages']"));
                IWebElement searchText9 = WebDriver.FindElement(By.XPath("//*[text() = 'Passport Issue Type']"));

                var checkBoxElement = WebDriver.FindElement(By.Id("tatkal"));
                var submitElement = WebDriver.FindElement(By.Id("Submit"));

                PassportsDBContext context = new PassportsDBContext();
                string total = context.Passports.Count().ToString();

                var totalElement = WebDriver.FindElement(By.Id("count"));
                Assert.AreEqual(totalElement.Text, total);
            }
            catch (Exception)
            {
                Assert.Fail("Exception should not occur here. Verify the value entered");
            }
        }

        [Test]
        public void Test_AddPassportView()
        {
            try
            {
                WebDriver.Navigate().GoToUrl(GetAbsoluteUrl(@"PassportsManagement/AddPassport"));

                //Maximize the window
                WebDriver.Manage().Window.Maximize();

                Assert.AreEqual("AddPassport - Passports Management", WebDriver.Title);

                IWebElement searchTextl1 = WebDriver.FindElement(By.XPath("//*[text() = 'Create']"));
                IWebElement searchTextl2 = WebDriver.FindElement(By.XPath("//*[text() = 'Passport']"));

                IWebElement searchText1 = WebDriver.FindElement(By.XPath("//*[text() = 'Passport Holder Name']"));
                IWebElement searchText2 = WebDriver.FindElement(By.XPath("//*[text() = 'PAN Number']"));                
                IWebElement searchText4 = WebDriver.FindElement(By.XPath("//*[text() = 'Gender']"));
                IWebElement searchText3 = WebDriver.FindElement(By.XPath("//*[text() = 'Passport Issue Type']"));
                IWebElement searchText5 = WebDriver.FindElement(By.XPath("//*[text() = 'Booklet Pages']"));
                IWebElement searchText7 = WebDriver.FindElement(By.XPath("//*[text() = 'Is Tatkal?']"));
                IWebElement searchText8 = WebDriver.FindElement(By.XPath("//*[text() = 'Date of Birth']"));

            }
            catch (Exception)
            {
                Assert.Fail("Exception should not occur here. Verify the value entered");
            }
        }

        [Test]
        public void Test_AddPassport_RequiredFields()
        {
            try
            {
                WebDriver.Navigate().GoToUrl(GetAbsoluteUrl(@"PassportsManagement/AddPassport"));

                //Maximize the window
                WebDriver.Manage().Window.Maximize();

                IWebElement searchText1 = WebDriver.FindElement(By.Id("Submit"));
                searchText1.Click();
                System.Threading.Thread.Sleep(2000);

                IWebElement searchText11 = WebDriver.FindElement(By.XPath("//*[text() = 'Please Provide Passport Holder Name']"));
                IWebElement searchText12 = WebDriver.FindElement(By.XPath("//*[text() = 'Please Provide PAN Number']"));                
                IWebElement searchText13 = WebDriver.FindElement(By.XPath("//*[text() = 'Please Select Gender']"));
                IWebElement searchText14 = WebDriver.FindElement(By.XPath("//*[text() = 'Please Select Issue Type']"));
                IWebElement searchText15 = WebDriver.FindElement(By.XPath("//*[text() = 'Please Select Booklet Pages']"));
                IWebElement searchText16 = WebDriver.FindElement(By.XPath("//*[text() = 'Please Provide Date of Birth']"));
                
            }
            catch (Exception)
            {
                Assert.Fail("Exception should not occur here. Verify the value entered");
            }
        }

        [Test]
        public void Test_AddPassport_ValidData()
        {
            try
            {
                WebDriver.Navigate().GoToUrl(GetAbsoluteUrl(@"PassportsManagement/AddPassport"));

                //Maximize the window
                WebDriver.Manage().Window.Maximize();

                WebDriver.FindElement(By.Id("PassportHolderName")).SendKeys("Passport1");
                WebDriver.FindElement(By.Id("PAN")).SendKeys("ABCDE1234Z");                
                WebDriver.FindElement(By.Id("Gender")).SendKeys("Male");
                WebDriver.FindElement(By.Id("IssueType")).SendKeys("Fresh");
                WebDriver.FindElement(By.Id("Booklet")).SendKeys("Page36");                
                WebDriver.FindElement(By.Id("DOB")).SendKeys("05/02/2001");

                WebDriver.FindElement(By.Id("Submit")).Click();

                Assert.AreEqual("Passport added successfully!",
                                    WebDriver.FindElement(By.Id("message")).Text);
            }
            catch (Exception)
            {
                Assert.Fail("Exception should not occur here. Verify the value entered");
            }
        }

        [Test]
        public void Test_Details()
        {
            try
            {
                WebDriver.Navigate().GoToUrl(GetAbsoluteUrl(@"PassportsManagement/Details/2"));

                //Maximize the window
                WebDriver.Manage().Window.Maximize();

                Assert.AreEqual("Details - Passports Management", WebDriver.Title);

                WebDriver.FindElement(By.LinkText("Back to List"));

                var messageElement = WebDriver.FindElement(By.Id("message"));
                Assert.AreEqual("Passport added successfully!", messageElement.Text);
            }
            catch (Exception)
            {
                Assert.Fail("Exception should not occur here. Verify the value entered");
            }
        }

        [Test]
        public void Test_TatkalFilter()
        {
            try
            {
                WebDriver.Navigate().GoToUrl(GetAbsoluteUrl(@"PassportsManagement/Index"));

                //Maximize the window
                WebDriver.Manage().Window.Maximize();

                Passport passport1 = new Passport
                {
                    PassportHolderName = "HolderName1",
                    PAN = "ABCDE1234Z",
                    IssueType = IssueType.Fresh,
                    Booklet = Booklet.Pages36,
                    Gender = Gender.Male,
                    DOB = new DateTime(1979, 01, 01),
                    IsTatkal = true
                };

                Passport passport2 = new Passport
                {
                    PassportHolderName = "HolderName1",
                    PAN = "ABCDE1234Z",
                    IssueType = IssueType.Fresh,
                    Booklet = Booklet.Pages36,
                    Gender = Gender.Male,
                    DOB = new DateTime(1979, 01, 01),
                    IsTatkal = false
                };

                PassportsDBContext dBContext = new PassportsDBContext();

                //delete previous dummy records
                var toDelete = dBContext.Passports.Where(r => r.PassportHolderName == "HolderName1");
                dBContext.Passports.RemoveRange(toDelete);
                dBContext.SaveChanges();

                //Add New Tatkal data
                dBContext.Passports.Add(passport1);
                dBContext.Passports.Add(passport2);
                dBContext.SaveChanges();

                WebDriver.Navigate().GoToUrl(GetAbsoluteUrl(@"PassportsManagement/Index"));

                Assert.AreEqual("Index - Passports Management", WebDriver.Title);
                var check = WebDriver.FindElement(By.Id("tatkal"));
                var submit = WebDriver.FindElement(By.Id("Submit"));

                check.Click();
                submit.Click();

                //Checking checkboxes selected
                foreach (IWebElement e in WebDriver.FindElements(By.XPath("//input[@type='checkbox']")))
                {
                    if (!e.Selected)
                        Assert.Fail("Filter is not working...");
                }

                //check Interest Total after filter
                string total = dBContext.Passports
                                    .Where(s => s.IsTatkal == true)
                                    .Count().ToString();
                var totalElement = WebDriver.FindElement(By.Id("count"));
                Assert.AreEqual(totalElement.Text, total);

                check = WebDriver.FindElement(By.Id("tatkal"));
                submit = WebDriver.FindElement(By.Id("Submit"));
                check.Click();
                submit.Click();

                //Checking checkboxes not selected
                foreach (IWebElement e in WebDriver.FindElements(By.XPath("//input[@type='checkbox']")))
                {
                    if (e.Selected)
                        Assert.Fail("Filter is not working...");
                }
                //check Interest Total after filter
                total = dBContext.Passports
                                    .Where(s => s.IsTatkal == false)
                                    .Count().ToString();
                totalElement = WebDriver.FindElement(By.Id("count"));
                Assert.AreEqual(totalElement.Text, total);
            }
            catch (Exception)
            {
                Assert.Fail("Exception should not occur here. Verify the value entered");
            }
        }

        [Test]
        public void Test_Details_BackToList()
        {
            try
            {
                WebDriver.Navigate().GoToUrl(GetAbsoluteUrl(@"PassportsManagement/Details/2"));

                //Maximize the window
                WebDriver.Manage().Window.Maximize();

                Assert.AreEqual("Details - Passports Management", WebDriver.Title);
                var link = WebDriver.FindElement(By.LinkText("Back to List"));
                link.Click();
                Assert.AreEqual("Index - Passports Management", WebDriver.Title);
            }
            catch (Exception)
            {
                Assert.Fail("Exception should not occur here. Verify the value entered");
            }
        }

        public void Dispose()
        {
            WebDriver.Quit();
            WebDriver.Dispose();
        }
    }
}
