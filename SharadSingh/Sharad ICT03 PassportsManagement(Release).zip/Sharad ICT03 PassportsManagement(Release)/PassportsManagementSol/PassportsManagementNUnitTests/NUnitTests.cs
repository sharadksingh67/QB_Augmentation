﻿using PassportsManagement.Controllers;
using PassportsManagement.Data;
using PassportsManagement.Models;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Web.Mvc;

namespace PassportsUnitTests
{
    [TestFixture]
    public class NUnitTests
    {
        Assembly assembly;
        Type className, dbContextclassName, modelClassName;

        [SetUp]
        public void Setup()
        {
            assembly = Assembly.Load("PassportsManagement");
            className = assembly.GetType("PassportsManagement.Controllers.PassportsManagementController");
            modelClassName = assembly.GetType("PassportsManagement.Models.Passport");
            dbContextclassName = assembly.GetType("PassportsManagement.Data.PassportsDBContext");
        }

        [TestCase]
        public void PassportsController_WhenNoSuchClassFound_WarnsUser()
        {
            if (className == null)
                Assert.Fail("No controller class with the name 'PassportsManagementController' is implemented OR Did you change the class name");
        }

        [TestCase]
        public void DBContext_WhenNoSuchClassFound_WarnsUser()
        {
            if (dbContextclassName == null)
                Assert.Fail("No DBContext class with the name 'PassportsDBContext' is implemented as required OR Did you change the class name");
        }

        [TestCase]
        public void PassportDBContext_InitalizesDbContext()
        {
            PassportsDBContext db = new PassportsDBContext();
            try
            {
                if (className != null)
                {
                    ConstructorInfo classConstructor = className.GetConstructor(Type.EmptyTypes);
                    object classObject = classConstructor.Invoke(new object[] { });

                    Assert.IsNotNull(db);
                }
                else
                    Assert.Fail("No class with the name 'PassportsManagementController' is implemented OR Did you change the class name");
            }
            catch (Exception)
            {
                Assert.Fail("Adding Passport details to the database failed. Exception should not be thrown. Please provide all mandatory fields valid data and check the destination action name.");
            }
        }

        [TestCase]
        public void Index_WhenNoSuchActionMethodFound_WarnsUser()
        {
            if (className != null)
            {
                MethodInfo testMethod = className.GetMethods().Where(x => x.Name.Equals("Index")
                                           && x.GetParameters().Count() == 0
                                           && x.ReturnType == typeof(ActionResult)).FirstOrDefault();
                Assert.IsNotNull(testMethod, "Method Index NOT implemented as per the requirement OR check the spelling");
            }
            else
                Assert.Fail("No class with the name 'PassportsManagementController' is implemented  as per the requirement OR Did you change the class name");
        }

        [TestCase]
        public void Index_WhenNoSuchPostActionMethodFound_WarnsUser()
        {
            if (className != null)
            {
                MethodInfo testMethod = className.GetMethods().Where(x => x.Name.Equals("Index")
                                           && x.GetParameters().Count() == 1
                                           && x.GetParameters().First().ParameterType == typeof(bool)
                                           && x.ReturnType == typeof(ActionResult)
                                           && x.CustomAttributes.First().AttributeType.Name
                                                    .Equals("HttpPostAttribute")).FirstOrDefault();

                Assert.IsNotNull(testMethod, "Method Index NOT implemented as per the requirement OR check the spelling");
            }
            else
                Assert.Fail("No class with the name 'PassportsManagementController' is implemented  as per the requirement OR Did you change the class name");
        }

        [TestCase]
        public void AddPassport_WhenNoSuchActionMethodFound_WarnsUser()
        {
            if (className != null)
            {
                MethodInfo testMethod = className.GetMethods().Where(x => x.Name.Equals("AddPassport")
                                           && x.GetParameters().Count() == 0
                                           && x.ReturnType == typeof(ActionResult)).FirstOrDefault();

                Assert.IsNotNull(testMethod, "Method AddPassport NOT implemented as per the requirement OR check the spelling");
            }
            else
                Assert.Fail("No class with the name 'PassportsManagementController' is implemented  as per the requirement OR Did you change the class name");
        }

        [TestCase]
        public void AddPassport_WhenNoSuchPostActionMethodFound_WarnsUser()
        {

            if (className != null)
            {
                MethodInfo testMethod = className.GetMethods().Where(x => x.Name.Equals("AddPassport")
                                            && x.GetParameters().Count() == 1
                                            && x.GetParameters().First().ParameterType == typeof(Passport)
                                            && x.ReturnType == typeof(ActionResult)
                                            && x.CustomAttributes.First().AttributeType.Name
                                                    .Equals("HttpPostAttribute")).FirstOrDefault();

                Assert.IsNotNull(testMethod, "Method AddPassport NOT implemented as per the requirement OR check the spelling");
            }
            else
                Assert.Fail("No class with the name 'PassportsManagementController' is implemented  as per the requirement OR Did you change the class name");
        }

        [TestCase]
        public void Details_WhenNoSuchActionMethodFound_WarnsUser()
        {
            if (className != null)
            {
                MethodInfo testMethod = className.GetMethods().Where(x => x.Name.Equals("Details")
                                            && x.GetParameters().Count() == 1
                                            && x.GetParameters().First().ParameterType == typeof(int)
                                            && x.ReturnType == typeof(ActionResult)).FirstOrDefault();

                Assert.IsNotNull(testMethod, "Method Details NOT implemented as per the requirement OR check the spelling");
            }
            else
                Assert.Fail("No class with the name 'PassportsManagementController' is implemented  as per the requirement OR Did you change the class name");
        }

        [Test]
        public void Passport_Should_Not_Be_Valid_When_Some_Properties_Incorrect()
        {
            //Arrange 
            var allBindings = BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;

            var PassportsManagementController = new PassportsManagementController();
            PassportsDBContext db = new PassportsDBContext();
            Passport passport = new Passport()
            {
                PassportHolderName = null,
                PAN = null,
                IssueType = IssueType.Select,
                Booklet = Booklet.Select,
                Gender = Gender.Select,
                DOB = null,
                IsTatkal = true
            };

            //Initialize ModelState 
            var modelBinder = new ModelBindingContext()
            {
                ModelMetadata = ModelMetadataProviders.Current.GetMetadataForType(
                                  () => passport, passport.GetType()),
                ValueProvider = new NameValueCollectionValueProvider(
                                    new NameValueCollection(), CultureInfo.InvariantCulture)
            };
            var binder = new DefaultModelBinder().BindModel(
                             new ControllerContext(), modelBinder);

            try
            {
                className = assembly.GetType("PassportsManagement.Controllers.PassportsManagementController");

                if (className != null)
                {
                    MethodInfo[] testMethods = className.GetMethods(allBindings);
                    MethodInfo testMethod = default;

                    foreach (var item in testMethods)
                    {
                        if (item.CustomAttributes.Count() > 0)
                        {
                            if (item.IsGenericMethod == false && item.Name.Equals("AddPassport")
                                && item.CustomAttributes.First().AttributeType
                                .Name.Equals("HttpPostAttribute"))
                            {
                                testMethod = item;
                                break;
                            }
                        }
                    }

                    Assert.IsNotNull(testMethod, "Action 'AddPassport' NOT implemented OR check spelling");

                    ConstructorInfo classConstructor = className.GetConstructor(Type.EmptyTypes);
                    object classObject = classConstructor.Invoke(new object[] { });
                    ((Controller)classObject).ModelState.Clear();
                    ((Controller)classObject).ModelState.Merge(modelBinder.ModelState);

                    Assert.IsFalse(((Controller)classObject).ModelState.IsValid, "Verify the model state values");
                }
                else
                    Assert.Fail("No class with the name 'PassportsManagementController' is implemented OR Did you change the class name");
            }
            catch (Exception)
            {
                Assert.Fail("Adding new passport to the database failed. verify the state of model object");
            }
        }

        [Test]
        public void Passport_Should_Be_Valid_When_All_Properties_Correct()
        {
            //Arrange 
            var allBindings = BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;

            var PassportsManagementController = new PassportsManagementController();
            PassportsDBContext db = new PassportsDBContext();
            Passport passport = new Passport()
            {
                PassportHolderName = "HolderName1",
                PAN = "ABCDE1234Z",
                IssueType = IssueType.Fresh,
                Booklet = Booklet.Pages36,
                Gender = Gender.Male,
                DOB = new DateTime(1979, 01, 01),
                IsTatkal = true
            };

            //Initialize ModelState 
            var modelBinder = new ModelBindingContext()
            {
                ModelMetadata = ModelMetadataProviders.Current.GetMetadataForType(
                                  () => passport, passport.GetType()),
                ValueProvider = new NameValueCollectionValueProvider(
                                    new NameValueCollection(), CultureInfo.InvariantCulture)
            };
            var binder = new DefaultModelBinder().BindModel(
                             new ControllerContext(), modelBinder);

            try
            {
                className = assembly.GetType("PassportsManagement.Controllers.PassportsManagementController");

                if (className != null)
                {
                    MethodInfo[] testMethods = className.GetMethods(allBindings);
                    MethodInfo testMethod = default;

                    foreach (var item in testMethods)
                    {
                        if (item.CustomAttributes.Count() > 0)
                        {
                            if (item.IsGenericMethod == false && item.Name.Equals("AddPassport")
                                && item.CustomAttributes.First().AttributeType
                                .Name.Equals("HttpPostAttribute"))
                            {
                                testMethod = item;
                                break;
                            }
                        }
                    }

                    Assert.IsNotNull(testMethod, "Action 'AddPassport' NOT implemented OR check spelling");

                    ConstructorInfo classConstructor = className.GetConstructor(Type.EmptyTypes);
                    object classObject = classConstructor.Invoke(new object[] { });
                    ((Controller)classObject).ModelState.Clear();
                    ((Controller)classObject).ModelState.Merge(modelBinder.ModelState);

                    Assert.IsTrue(((Controller)classObject).ModelState.IsValid, "Verify the model state values");
                }
                else
                    Assert.Fail("No class with the name 'PassportsManagementController' is implemented OR Did you change the class name");
            }
            catch (Exception)
            {
                Assert.Fail("Adding new passport to the database failed. verify the state of model object");
            }
        }

        [Test]
        public void IndexAction_When_Invoked_Return_passportsList()
        {
            //Arrange 
            PassportsDBContext db = new PassportsDBContext();
            try
            {
                className = assembly.GetType("PassportsManagement.Controllers.PassportsManagementController");

                if (className != null)
                {
                    MethodInfo testMethod = className.GetMethods().Where(x => x.Name.Equals("Index")
                                           && x.GetParameters().Count() == 0
                                           && x.ReturnType == typeof(ActionResult)).FirstOrDefault();

                    Assert.IsNotNull(testMethod,
                        "Action 'Index' GET NOT implemented with return type 'ActionResult' OR check spelling");

                    ConstructorInfo classConstructor = className.GetConstructor(Type.EmptyTypes);
                    object classObject = classConstructor.Invoke(new object[] { });

                    var viewResult = (ViewResult)testMethod.Invoke(classObject, new object[] { });
                    var passportsList = (IEnumerable<Passport>)viewResult.ViewData.Model;
                    Assert.AreEqual(db.Passports.ToList().Count, passportsList.ToList().Count,
                        "Verify whether you fetched the data from the database correctly or not");

                    //to test list is sorted on IsTatkal
                    var uTatkal = passportsList.Select(c => c.IsTatkal).Distinct().ToList();

                    //Copy of the List
                    var nTatkal = new List<bool>(uTatkal);
                    //new List<bool> { IsTatkal.Delhi, IsTatkal.Chennai, IsTatkal.Mumbai, IsTatkal.Kolkata }; //To test
                    nTatkal.Sort();
                    //Compare UniqueTatkal with Sorted UniqueTatkal
                    bool isSorted = uTatkal.SequenceEqual(nTatkal);
                    Assert.That(isSorted, "List should be sorted on IsTatkal");
                }
                else
                    Assert.Fail("No class with the name 'PassportsManagementController' is implemented OR Did you change the class name");
            }
            catch (Exception)
            {
                Assert.Fail("Exception should not be thrown. Please check the application logic");
            }
        }

        [Test]
        public void IndexActionPOST_When_Invoked_Return_FilteredpassportsList()
        {
            //Arrange 
            PassportsDBContext db = new PassportsDBContext();
            try
            {
                className = assembly.GetType("PassportsManagement.Controllers.PassportsManagementController");

                if (className != null)
                {
                    MethodInfo testMethod = className.GetMethods().Where(x => x.Name.Equals("Index")
                                           && x.GetParameters().Count() == 1
                                           && x.GetParameters().First().ParameterType == typeof(bool)
                                           && x.ReturnType == typeof(ActionResult)).FirstOrDefault();

                    Assert.IsNotNull(testMethod,
                        "Action 'Index' POST NOT implemented with bool parameter and return type 'ActionResult' OR check spelling");

                    ConstructorInfo classConstructor = className.GetConstructor(Type.EmptyTypes);
                    object classObject = classConstructor.Invoke(new object[] { });

                    //Checking for KYC Done - true
                    var viewResult1 = (ViewResult)testMethod.Invoke(classObject, new object[] { true });
                    var passportsList1 = (IEnumerable<Passport>)viewResult1.ViewData.Model;

                    Assert.AreEqual(db.Passports.Where(r => r.IsTatkal == true).ToList().Count,
                        passportsList1.ToList().Count,
                        "Verify whether you fetched the filtered data from the database correctly or not");

                    //to test Count based on Filter

                    Assert.AreEqual(db.Passports.Where(r => r.IsTatkal == true).ToList().Count(),
                        passportsList1.ToList().Count(),
                        "Verify whether you fetched the filtered data from the database correctly or not");

                    //to test list is sorted on IsTatkal
                    var uTatkal = passportsList1
                                        .Where(c => c.IsTatkal == true)
                                        .Select(c => c.IsTatkal).Distinct().ToList();

                    //Copy of the List
                    var nTatkal = new List<bool>(uTatkal);
                    nTatkal.Sort();
                    //Compare UniqueTatkal with Sorted UniqueTatkal
                    bool isSorted = uTatkal.SequenceEqual(nTatkal);
                    Assert.That(isSorted, "List should be sorted on IsTatkal");

                    //Checking for KYC Done - false
                    var viewResult2 = (ViewResult)testMethod.Invoke(classObject, new object[] { false });
                    var passportsList2 = (IEnumerable<Passport>)viewResult2.ViewData.Model;

                    Assert.AreEqual(db.Passports.Where(r => r.IsTatkal == false).ToList().Count,
                        passportsList2.ToList().Count,
                        "Verify whether you fetched the filtered data from the database correctly or not");

                    //to test list is sorted on IsTatkal
                    var uTatkal2 = passportsList2
                                        .Where(c => c.IsTatkal == false)
                                        .Select(c => c.IsTatkal).Distinct().ToList();

                    //Copy of the List
                    var nTatkal2 = new List<bool>(uTatkal2);
                    nTatkal2.Sort();
                    //Compare UniqueTatkal with Sorted UniqueTatkal
                    bool isSorted2 = uTatkal2.SequenceEqual(nTatkal2);
                    Assert.That(isSorted2, "List should be sorted on IsTatkal");
                }
                else
                    Assert.Fail("No class with the name 'PassportsManagementController' is implemented OR Did you change the class name");
            }
            catch (Exception)
            {
                Assert.Fail("Exception should not be thrown. Please check the application logic");
            }
        }

        [Test]
        public void DetailsAction_Returns_Valid_passport_When_Given_ValidId()
        {
            //Arrange 
            var allBindings = BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;
            PassportsDBContext db = new PassportsDBContext();
            try
            {
                className = assembly.GetType("PassportsManagement.Controllers.PassportsManagementController");

                if (className != null)
                {
                    MethodInfo testMethod = className.GetMethod("Details", allBindings);
                    Assert.IsNotNull(testMethod, "Action 'Details' NOT implemented OR check spelling");
                    Assert.AreEqual(typeof(ActionResult), testMethod.ReturnType, "The return type of the Details action MUST be 'ActionResult'");

                    ConstructorInfo classConstructor = className.GetConstructor(Type.EmptyTypes);
                    object classObject = classConstructor.Invoke(new object[] { });

                    //Arrange
                    int validId = db.Passports.Max(r => r.PassportID);//getting valid max id

                    var viewResult1 = (ViewResult)testMethod.Invoke(classObject, new object[] { validId });
                    var passport1 = (Passport)viewResult1.ViewData.Model;

                    viewResult1.View = null;

                    int invalidId = validId += 5000;//adding 5000 to valid id to make it invalid to test
                    classObject = classConstructor.Invoke(new object[] { });
                    //Act
                    var viewResult2 = (ViewResult)testMethod.Invoke(classObject, new object[] { invalidId });
                    var passport2 = (Passport)viewResult2.ViewData.Model;

                    //Assert
                    Assert.IsTrue(passport1 != null && passport2 == null);
                }
                else
                    Assert.Fail("No class with the name 'PassportsController' is implemented OR Did you change the class name");
            }
            catch (Exception)
            {
                Assert.Fail("Invalid id, please provide a valid passport id");
            }
        }

        [Test]
        public void AddPassport_SavesToDatabase_IDAutoGenerated_ValidModel()
        {
            //Arrange 
            var allBindings = BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;

            Passport passportObj = new Passport
            {
                PassportHolderName = "HolderName1",
                PAN = "ABCDE1234Z",
                IssueType = IssueType.Fresh,
                Booklet = Booklet.Pages36,
                Gender = Gender.Male,
                DOB = new DateTime(1979, 01, 01),
                IsTatkal = true
            };
            PassportsDBContext db = new PassportsDBContext();
            try
            {
                className = assembly.GetType("PassportsManagement.Controllers.PassportsManagementController");

                if (className != null)
                {
                    MethodInfo[] testMethods = className.GetMethods(allBindings);
                    MethodInfo testMethod = default;

                    foreach (var item in testMethods)
                    {
                        if (item.CustomAttributes.Count() > 0)
                        {
                            if (item.IsGenericMethod == false && item.Name.Equals("AddPassport")
                                && item.CustomAttributes.First().AttributeType
                                .Name.Equals("HttpPostAttribute"))
                            {
                                testMethod = item;
                                break;
                            }
                        }
                    }

                    Assert.IsNotNull(testMethod, "Action 'AddPassport' NOT implemented OR check spelling");

                    ConstructorInfo classConstructor = className.GetConstructor(Type.EmptyTypes);
                    object classObject = classConstructor.Invoke(new object[] { });

                    //Check if database is having records? Otherwise can't get Max()
                    if (db.Passports.Count() == 0)
                    {
                        testMethod.Invoke(classObject, new object[] { passportObj });
                    }

                    //Act 
                    int maxIdBefore = db.Passports.Max(i => i.PassportID);

                    var result = (RedirectToRouteResult)testMethod.Invoke(classObject, new object[] { passportObj });
                    int maxIdAfter = db.Passports.Max(i => i.PassportID);

                    //Assert                     
                    Assert.That(maxIdBefore + 1 == maxIdAfter, "PassportID should be Auto Generated.");
                    Assert.AreEqual("Details", result.RouteValues["action"]);
                }
                else
                    Assert.Fail("No class with the name 'PassportsManagementController' is implemented OR Did you change the class name");
            }
            catch (Exception)
            {
                Assert.Fail("Adding new passport to the database failed. Exception should not be thrown. Please provide all mandatory fields valid data and check the destination action name.");
            }
        }

        [TestCase]
        public void Model_GeneratePassportNumberMethod_WhenNoSuchMethodFound_WarnsUser()
        {
            if (modelClassName != null)
            {
                MethodInfo testMethod = modelClassName.GetMethods().Where(x => x.Name.Equals("GeneratePassportNumber")
                                           && x.GetParameters().Count() == 0
                                           && x.ReturnType == typeof(void)).FirstOrDefault();
                Assert.IsNotNull(testMethod, "Method GeneratePassportNumber NOT implemented as per the requirement OR check the spelling");
            }
            else
                Assert.Fail("No class with the name 'Passport' is implemented  as per the requirement OR Did you change the class name");
        }


        [TestCase]
        public void Model_CalculateFeeMethod_WhenNoSuchMethodFound_WarnsUser()
        {
            if (modelClassName != null)
            {
                MethodInfo testMethod = modelClassName.GetMethods().Where(x => x.Name.Equals("CalculateFee")
                                           && x.GetParameters().Count() == 0
                                           && x.ReturnType == typeof(void)).FirstOrDefault();
                Assert.IsNotNull(testMethod, "Method CalculateFee NOT implemented as per the requirement OR check the spelling");
            }
            else
                Assert.Fail("No class with the name 'Passport' is implemented  as per the requirement OR Did you change the class name");
        }

        [TestCase]
        public void Model_IsMinorMethod_WhenNoSuchMethodFound_WarnsUser()
        {
            if (modelClassName != null)
            {
                MethodInfo testMethod = modelClassName.GetMethods().Where(x => x.Name.Equals("IsMinor")
                                           && x.GetParameters().Count() == 0
                                           && x.ReturnType == typeof(bool)).FirstOrDefault();
                Assert.IsNotNull(testMethod, "Method IsMinor NOT implemented as per the requirement OR check the spelling");
            }
            else
                Assert.Fail("No class with the name 'Passport' is implemented  as per the requirement OR Did you change the class name");
        }

        [TestCase]
        public void PassportModel_IsMinorMethod_ShouldCalculateAsPerDOB()
        {
            var allBindings = BindingFlags.IgnoreCase |
                    BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;

            Passport passportObj = new Passport
            {
                PassportHolderName = "HolderName1",
                PAN = "ABCDE1234Z",
                IssueType = IssueType.Fresh,
                Booklet = Booklet.Pages36,
                Gender = Gender.Male,
                DOB = new DateTime(2005, 01, 01),
                IsTatkal = false
            };

            object[] parameters = new object[] { };
            try
            {
                if (modelClassName != null)
                {
                    MethodInfo testMethod = modelClassName.GetMethod("IsMinor", allBindings);
                    testMethod.Invoke(passportObj, parameters);
                    bool expected = true;
                    Assert.AreEqual(expected, passportObj.IsMinor());

                    passportObj.DOB = new DateTime(1989, 01, 01);
                    testMethod.Invoke(passportObj, parameters);
                    expected = false;
                    Assert.AreEqual(expected, passportObj.IsMinor());
                }
            }
            catch (Exception ex)
            {
                Assert.Fail("Exception should not be thrown. Please check the input and application logic." + ex.Message);
            }
        }

        //CalculateFee to be tested for different scenario
        //      Passport Fee structure - Just for reference
        //      ------------------------------------------------------------------------------------------
        //a)	₹1500 – Fresh issuance or reissue of passport(36 pages booklet).
        //b)	₹2000 – Fresh issuance or reissue of passport(60 pages booklet).
        //c)	₹3500 – First time applicant or renewal with expedited('tatkal') service(36 pages booklet).
        //d)	₹4000 – First time applicant or renewal with expedited('tatkal') service(60 pages booklet).
        //e)	₹1000 – Fresh passport issuance for minors(below 18 years of Age).
        //f)	₹3000 – Duplicate passport(36 pages) in lieu of lost, damaged or stolen passport.
        //g)    ₹3500 – Duplicate passport(60 pages) in lieu of lost, damaged or stolen passport.

        [TestCase(IssueType.Fresh, true, Booklet.Pages36, 3500)]
        [TestCase(IssueType.Renew, true, Booklet.Pages36, 3500)]
        [TestCase(IssueType.Fresh, true, Booklet.Pages60, 4000)]
        [TestCase(IssueType.Renew, true, Booklet.Pages60, 4000)]
        public void PassportModel_CalculateFeeMethod_ShouldCalculateAsPerTatkalNBooklet(
              IssueType issueType, bool tatkal, Booklet booklet, int fee)
        {
            var allBindings = BindingFlags.IgnoreCase |
                    BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;

            Passport passportObj = new Passport
            {
                PassportHolderName = "HolderName1",
                PAN = "ABCDE1234Z",
                IssueType = issueType,
                Booklet = booklet,
                Gender = Gender.Male,
                DOB = new DateTime(1979, 01, 01),
                IsTatkal = tatkal
            };

            object[] parameters = new object[] { };
            try
            {
                if (modelClassName != null)
                {
                    MethodInfo testMethod = modelClassName.GetMethod("CalculateFee", allBindings);

                    //Testing for Fresh 36 pages
                    testMethod.Invoke(passportObj, parameters);
                    int expected = fee;
                    Assert.AreEqual(expected, passportObj.PassportFee);
                }
            }
            catch (Exception ex)
            {
                Assert.Fail("Exception should not be thrown. Please check the input and application logic." + ex.Message);
            }
        }


        [TestCase(IssueType.Fresh, Booklet.Pages36, 1500)]
        [TestCase(IssueType.Fresh, Booklet.Pages60, 2000)]
        [TestCase(IssueType.Duplicate, Booklet.Pages36, 3000)]
        [TestCase(IssueType.Duplicate, Booklet.Pages60, 3500)]
        public void PassportModel_CalculateFeeMethod_ShouldCalculateAsPerIssueNBooklet(IssueType issueType, Booklet booklet, int fee)
        {
            var allBindings = BindingFlags.IgnoreCase |
                    BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;

            Passport passportObj = new Passport
            {
                PassportHolderName = "HolderName1",
                PAN = "ABCDE1234Z",
                IssueType = issueType,
                Booklet = booklet,
                Gender = Gender.Male,
                DOB = new DateTime(1979, 01, 01),
                IsTatkal = false
            };

            object[] parameters = new object[] { };
            try
            {
                if (modelClassName != null)
                {
                    MethodInfo testMethod = modelClassName.GetMethod("CalculateFee", allBindings);

                    //Testing for Fresh 36 pages
                    testMethod.Invoke(passportObj, parameters);
                    int expected = fee;
                    Assert.AreEqual(expected, passportObj.PassportFee);
                }
            }
            catch (Exception ex)
            {
                Assert.Fail("Exception should not be thrown. Please check the input and application logic." + ex.Message);
            }
        }

        [TestCase]
        public void PassportModel_CalculateFeeMethod_ShouldCalculateAsPerMinor()
        {
            var allBindings = BindingFlags.IgnoreCase |
                    BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;

            Passport passportObj = new Passport
            {
                PassportHolderName = "HolderName1",
                PAN = "ABCDE1234Z",
                IssueType =  IssueType.Fresh,
                Booklet = Booklet.Pages36,
                Gender = Gender.Male,
                DOB = new DateTime(2005, 01, 01),
                IsTatkal = false
            };

            object[] parameters = new object[] { };
            try
            {
                if (modelClassName != null)
                {
                    MethodInfo testMethod = modelClassName.GetMethod("CalculateFee", allBindings);

                    //Testing for Fresh 36 pages
                    testMethod.Invoke(passportObj, parameters);
                    int expected = 1000;
                    Assert.AreEqual(expected, passportObj.PassportFee);
                }
            }
            catch (Exception ex)
            {
                Assert.Fail("Exception should not be thrown. Please check the input and application logic." + ex.Message);
            }
        }
    }
}
