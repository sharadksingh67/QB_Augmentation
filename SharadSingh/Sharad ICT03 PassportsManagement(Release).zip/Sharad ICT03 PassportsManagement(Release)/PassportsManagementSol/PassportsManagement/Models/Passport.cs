﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PassportsManagement.Models
{    
    public enum Gender
    {
        Select, Male, Female, Others
    }
    public enum Booklet
    {
        Select,
        Pages36,
        Pages60
    }
    public enum IssueType
    {
        Select,
        Fresh,
        Renew,
        Duplicate
    }
    public class Passport
    {
        [Key]
        public int PassportID { get; set; }

        [MaxLength(8)]
        [Display(Name = "Passport Number")]
        public string PassportNumber { get; set; }      //"A1234567"

        [Required(ErrorMessage = "Please Provide Passport Holder Name")]
        [MaxLength(50)]
        [Display(Name = "Passport Holder Name")]
        public string PassportHolderName { get; set; }

        [Required(ErrorMessage = "Please Provide PAN Number")]
        [MaxLength(10)]
        [RegularExpression(@"^[A-Z]{5}[0-9]{4}[A-Z]{1}$", ErrorMessage = "Please Provide a valid PAN")]
        [Display(Name = "PAN Number")]
        public string PAN { get; set; }

        [Required, Range(1, 3, ErrorMessage = "Please Select Gender")]
        [Display(Name = "Gender")]
        public Gender Gender { get; set; }

        [Required, Range(1, 3, ErrorMessage = "Please Select Issue Type")]
        [Display(Name = "Passport Issue Type")]
        public IssueType IssueType { get; set; }

        [Required, Range(1, 2, ErrorMessage = "Please Select Booklet Pages")]
        [Display(Name = "Booklet Pages")]
        public Booklet Booklet { get; set; }

        [Required(ErrorMessage = "Please Provide Date of Birth")]
        [DataType(DataType.Date)]
        [Display(Name = "Date of Birth")]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yy}", ApplyFormatInEditMode = true)]
        public DateTime? DOB { get; set; }

        [Display(Name = "Is Tatkal?")]
        public bool IsTatkal { get; set; }       //False Normal

        [Display(Name = "Passport Fee")]
        [DisplayFormat(DataFormatString = "{0}", ApplyFormatInEditMode = true)]
        public int PassportFee { get; set; }

        public void GeneratePassportNumber()
        {
            //Format - A1234567
            //Rules -
            //First Character of Holders'Name + 2 digits of Date of Birth's Year 
            //+ 4 digits in PAN + 1 Gender value

            PassportNumber = PassportHolderName[0]
                                    + ((DateTime)DOB).ToString("yy")
                                    + PAN.Substring(5, 4)
                                    + ((int)Gender).ToString();
        }

        public bool IsMinor()
        {
            int age = 0;
            age = DateTime.Now.Year - ((DateTime)DOB).Year;
            if (DateTime.Now.DayOfYear < ((DateTime)DOB).DayOfYear)
                age = age - 1;
            if (age < 18)
                return true;
            else
                return false;
        }

        public void CalculateFee()
        {
            int fee = 0;
            if (IssueType == IssueType.Fresh && IsMinor() && IsTatkal == false)
            {
                fee = 1000;
            }
            else if ((IssueType == IssueType.Fresh || IssueType == IssueType.Renew) && Booklet == Booklet.Pages36 && !IsMinor() && IsTatkal == false)
            {
                fee = 1500;
            }
            else if ((IssueType == IssueType.Fresh || IssueType == IssueType.Renew) && Booklet == Booklet.Pages60 && !IsMinor() && IsTatkal == false)
            {
                fee = 2000;
            }
            else if (IsTatkal == true && Booklet == Booklet.Pages36 && !IsMinor())
            {
                fee = 3500;
            }
            else if (IsTatkal == true && Booklet == Booklet.Pages60 && !IsMinor())
            {
                fee = 4000;
            }
            else if (IssueType == IssueType.Duplicate && Booklet == Booklet.Pages36 && !IsMinor() && IsTatkal == false)
            {
                fee = 3000;
            }
            else if (IssueType == IssueType.Duplicate && Booklet == Booklet.Pages60 && !IsMinor() && IsTatkal == false)
            {
                fee = 3500;
            }
            PassportFee = fee;
        }

        //      The fee for a standard passport in India
        //      -------------------------------------------------------------------------------------------
        //a)	₹1500 – Fresh issuance or reissue of passport(36 pages booklet).
        //b)	₹2000 – Fresh issuance or reissue of passport(60 pages booklet).
        //c)	₹3500 – First time applicant or renewal with expedited('tatkal') service(36 pages booklet).
        //d)	₹4000 – First time applicant or renewal with expedited('tatkal') service(60 pages booklet).
        //e)	₹1000 – Fresh passport issuance for minors(below 18 years of Age).
        //f)	₹3000 – Duplicate passport(36 pages) in lieu of lost, damaged or stolen passport.
        //g)    ₹3500 – Duplicate passport(60 pages) in lieu of lost, damaged or stolen passport.
    }
}
