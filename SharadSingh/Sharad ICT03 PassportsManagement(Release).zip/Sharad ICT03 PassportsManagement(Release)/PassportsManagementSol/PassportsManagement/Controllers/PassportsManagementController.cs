﻿using PassportsManagement.Data;
using PassportsManagement.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.UI.WebControls;

namespace PassportsManagement.Controllers
{
    // GET: PassportsManagement
    [CustomFilters.CustomExceptionFilter]
    public class PassportsManagementController : Controller
    {
        // GET
        public ActionResult Index()
        {
            var context = new PassportsDBContext();

            var list = context.Passports
                                .OrderBy(h => h.IsTatkal)
                                .Select(h => h)
                                .ToList<Passport>();
            return View(list);
        }

        [HttpPost]
        public ActionResult Index(bool tatkal)
        {
            var context = new PassportsDBContext();
            var list = context.Passports
                                .Where(x => x.IsTatkal == tatkal)
                                .OrderBy(h => h.Gender)
                                .Select(h => h)
                                .ToList<Passport>();
            return View(list);
        }

        public ActionResult AddPassport()
        {
            Passport res = new Passport();
            res.DOB = null;
            return View(res);
        }

        [HttpPost]
        public ActionResult AddPassport(Passport Passport)
        {
            if (ModelState.IsValid)
            {
                ViewBag.msg = "Passport added successfully!";
                var context = new PassportsDBContext();
                Passport.GeneratePassportNumber();
                Passport.CalculateFee();
                context.Passports.Add(Passport);
                context.SaveChanges();
                return RedirectToAction("Details",
                    new { id = Passport.PassportID });
            }
            else
            {
                return View();
            }
        }

        public ActionResult Details(int id)
        {
            var db = new PassportsDBContext();
            var model = db.Passports
                            .Where(r => r.PassportID == id)
                            .FirstOrDefault();
            return View(model);
        }
    }
}
