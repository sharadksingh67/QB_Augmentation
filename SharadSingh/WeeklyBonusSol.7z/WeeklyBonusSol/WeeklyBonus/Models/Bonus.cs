﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Models
{
    public class Bonus
    {
        public int Emp_ID { set; get; }
        public String Emp_Name { set; get; }
        public int Project_Hours { set; get; }
        public int Documentation_Hours { set; get; }
        public int Bonus_Amount { set; get; }

        //public void CalculateBonus()
        //{
        //    if (Project_Hours > 30)
        //        Bonus_Amount = 10000;
        //    else if (Project_Hours > 20)
        //        Bonus_Amount = 5000;

        //    if (Documentation_Hours > 10)
        //        Bonus_Amount += 3700;
        //    else if (Documentation_Hours > 5)
        //        Bonus_Amount += 2500;
        //}
    }
}
