using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Models;

namespace WeeklyBonus.Controllers
{
    public class WeeklyBonusController : Controller
    {

        // GET: WeeklyBonus
        public ActionResult WeeklyBonus()
        {
            return View();
        }

        [HttpPost]
        public ActionResult WeeklyBonus(Bonus weeklyBonus)
        {            
            if (weeklyBonus.Project_Hours > 30)
                weeklyBonus.Bonus_Amount = 10000;
            else if (weeklyBonus.Project_Hours > 20)
                weeklyBonus.Bonus_Amount = 5000;

            if (weeklyBonus.Documentation_Hours > 10)
                weeklyBonus.Bonus_Amount += 3700;
            else if (weeklyBonus.Documentation_Hours > 5)
                weeklyBonus.Bonus_Amount += 2500;

            return View(weeklyBonus);
        }

        public ActionResult Print(Bonus weeklyBonus)
        {
            return View(weeklyBonus);
        }
    }
}