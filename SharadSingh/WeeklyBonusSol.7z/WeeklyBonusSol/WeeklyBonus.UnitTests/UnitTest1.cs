﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Web.Mvc;
using WeeklyBonus.Controllers;
using Models;

namespace WeeklyBonus.UnitTests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestPostController1()
        {
            WeeklyBonusController controller =
                        new WeeklyBonusController();

            Bonus bonus = new Bonus()
            {
                Emp_ID = 1101,
                Emp_Name = "Emp1",
                Project_Hours = 21,
                Documentation_Hours = 11,
                Bonus_Amount = 0
            };

            var viewResult = controller.WeeklyBonus(bonus) as ViewResult;
            Bonus calculated = (Bonus)viewResult.ViewData.Model;
            Assert.AreEqual(8700, calculated.Bonus_Amount);

        }



        [TestMethod]
        public void TestPostController2()
        {
            WeeklyBonusController controller =
                        new WeeklyBonusController();

            Bonus bonus = new Bonus()
            {
                Emp_ID = 1101,
                Emp_Name = "Emp1",
                Project_Hours = 22,
                Documentation_Hours = 7,
                Bonus_Amount = 0
            };

            var viewResult = controller.WeeklyBonus(bonus) as ViewResult;
            Bonus calculated = (Bonus)viewResult.ViewData.Model;
            Assert.AreEqual(7500, calculated.Bonus_Amount);

        }
    }
}

