using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Models;

namespace WeeklyBonus.Controllers
{
    public class WeeklyBonusController : Controller
    {

        // GET: WeeklyBonus
        public ActionResult CalculateWeeklyBonus()
        {
            return View();
        }

        //Implement your code and methods

        
    }
}