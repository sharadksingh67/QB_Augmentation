﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Configuration;
using System.Linq;
using System.Web;

namespace Models
{
    public class Bonus
    {
        public int EmpID { set; get; }
        public String EmpName { set; get; }
        [IntegerValidator(MinValue = 1, MaxValue = 40, ExcludeRange = false)]
        public int ProjectHours { set; get; }
        [IntegerValidator(MinValue = 1, MaxValue = 40, ExcludeRange = false)]
        public int DocumentationHours { set; get; }
        public int BonusAmount { set; get; }
    }
}
