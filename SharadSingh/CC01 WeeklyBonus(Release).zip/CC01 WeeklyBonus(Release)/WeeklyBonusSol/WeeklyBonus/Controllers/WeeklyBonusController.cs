﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Models;

namespace WeeklyBonus.Controllers
{
    public class WeeklyBonusController : Controller
    {
        // GET: WeeklyBonus
        public ActionResult CalculateWeeklyBonus()
        {
            return View();
        }

        [HttpPost]
        public ActionResult CalculateWeeklyBonus(Bonus weeklyBonus)
        {
            if (weeklyBonus.ProjectHours >= 30 && weeklyBonus.ProjectHours <= 40)
                weeklyBonus.BonusAmount = 10000;
            else if (weeklyBonus.ProjectHours >= 20 && weeklyBonus.ProjectHours <= 40)
                weeklyBonus.BonusAmount = 5000;

            if (weeklyBonus.DocumentationHours >= 10 && weeklyBonus.DocumentationHours <= 40)
                weeklyBonus.BonusAmount += 3700;
            else if (weeklyBonus.DocumentationHours >= 5 && weeklyBonus.DocumentationHours <= 40)
                weeklyBonus.BonusAmount += 2500;

            return View(weeklyBonus);
        }

        public ActionResult Print(Bonus weeklyBonus)
        {
            return View(weeklyBonus);
        }
    }
}