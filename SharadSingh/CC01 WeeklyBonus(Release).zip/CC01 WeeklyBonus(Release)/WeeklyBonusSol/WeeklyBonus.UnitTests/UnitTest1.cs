﻿using System;
using System.Web.Mvc;
using WeeklyBonus.Controllers;
using Models;
using NUnit.Framework;
using System.Reflection;
using System.Linq;

namespace WeeklyBonus.UnitTests
{
    [TestFixture]
    public class UnitTest1
    {
        Assembly assembly;
        Type className;

        [SetUp]
        public void Setup()
        {
            assembly = Assembly.Load("WeeklyBonus");
            className = assembly.GetType("WeeklyBonus.Controllers.WeeklyBonusController");
        }

        [TestCase]
        public void Test_Controller_ClassExistence()
        {
            if (className == null)
                Assert.Fail("No controller class with the name 'WeeklyBonusController' is implemented OR Did you change the class name");
        }

        [TestCase]
        public void Test1_CalculateWeeklyBonus_ActionMethodExist()
        {            
            if (className != null)
            {
                MethodInfo testMethod = className.GetMethod("CalculateWeeklyBonus", new Type[] { });
                Attribute[] attribs = testMethod.GetCustomAttributes().ToArray();                
                int attrCount = attribs.Count();
                string attrName = string.Empty;
                if (attrCount > 0)
                {
                    attrName = testMethod.CustomAttributes.First().AttributeType.Name;
                }
                ParameterInfo[] paramsInfo = testMethod.GetParameters();     
                int parameters = testMethod.GetParameters().Length;
                Assert.Multiple(() =>
                {
                    Assert.That(parameters == 0, "Must have no parameter");     
                    Assert.That(testMethod.ReturnType == typeof(ActionResult), "Return type must be ActionResult");
                    Assert.IsNotNull(testMethod, "Method CalculateWeeklyBonus NOT implemented OR check spelling");
                });                
            }
            else
                Assert.Fail("No class with the name 'WeeklyBonusController' is implemented OR Did you change the class name");
        }

        [TestCase]
        public void Test2_CalculateWeeklyBonus_ActionMethodExist()
        {
            if (className != null)
            {
                MethodInfo testMethod = className.GetMethod("CalculateWeeklyBonus", new Type[] { typeof(Bonus) });
                
                Attribute[] attribs = testMethod.GetCustomAttributes().ToArray();                
                int attrCount = attribs.Count();
                string attrName = string.Empty;
                if (attrCount > 0)
                {
                    attrName = testMethod.CustomAttributes.First().AttributeType.Name;
                }
                ParameterInfo[] paramsInfo = testMethod.GetParameters();
                Type param1 = paramsInfo[0].ParameterType;
                int parameters = testMethod.GetParameters().Length;
                Assert.Multiple(() =>
                {
                    Assert.That(attrCount == 1, "Must have 1 attribute");
                    Assert.That(attrName == "HttpPostAttribute", "Must be HttpPostAttribute attribute");
                    Assert.That(parameters == 1, "Must have 1 parameter");
                    Assert.That(typeof(Bonus) == param1, "parameter1 must be of Type Bonus");
                    Assert.That(testMethod.ReturnType == typeof(ActionResult), "Return type must be ActionResult");
                    Assert.IsNotNull(testMethod, "Method CalculateWeeklyBonus NOT implemented OR check spelling");
                });
            }
            else
                Assert.Fail("No class with the name 'WeeklyBonusController' is implemented OR Did you change the class name");
        }


        [TestCase]
        public void Test3_Print_ActionMethodExist()
        {
            if (className != null)
            {
                MethodInfo testMethod = className.GetMethod("Print", new Type[] { typeof(Bonus) });

                ParameterInfo[] paramsInfo = testMethod.GetParameters();
                Type param1 = paramsInfo[0].ParameterType;
                int parameters = testMethod.GetParameters().Length;
                Assert.Multiple(() =>
                {
                    Assert.That(parameters == 1, "Must have 1 parameter");
                    Assert.That(typeof(Bonus) == param1, "parameter1 must be of Type Bonus");
                    Assert.That(testMethod.ReturnType == typeof(ActionResult), "Return type must be ActionResult");
                    Assert.IsNotNull(testMethod, "Method Print NOT implemented OR check spelling");
                });
            }
            else
                Assert.Fail("No class with the name 'WeeklyBonusController' is implemented OR Did you change the class name");
        }

        [TestCase]
        public void Test4_ActionMethod_CalculateWeeklyBonus()
        {
            WeeklyBonusController controller =
                        new WeeklyBonusController();

            Bonus bonus = new Bonus()
            {
                EmpID = 1101,
                EmpName = "Emp1",
                ProjectHours = 21,
                DocumentationHours = 11,
                BonusAmount = 0
            };

            var viewResult = controller.CalculateWeeklyBonus(bonus) as ViewResult;
            Bonus calculated = (Bonus)viewResult.ViewData.Model;
            NUnit.Framework.Assert.AreEqual(8700, calculated.BonusAmount);

        }



        [TestCase]
        public void Test5_ActionMethod_CalculateWeeklyBonus()
        {
            WeeklyBonusController controller =
                        new WeeklyBonusController();

            Bonus bonus = new Bonus()
            {
                EmpID = 1101,
                EmpName = "Emp1",
                ProjectHours = 22,
                DocumentationHours = 7,
                BonusAmount = 0
            };

            var viewResult = controller.CalculateWeeklyBonus(bonus) as ViewResult;
            Bonus calculated = (Bonus)viewResult.ViewData.Model;
            NUnit.Framework.Assert.AreEqual(7500, calculated.BonusAmount);

        }


        [TestCase]
        public void Test6_ActionMethod_CalculateWeeklyBonus()
        {
            WeeklyBonusController controller =
                        new WeeklyBonusController();

            Bonus bonus = new Bonus()
            {
                EmpID = 1101,
                EmpName = "Emp1",
                ProjectHours = 50,
                DocumentationHours = 50,
                BonusAmount = 0
            };

            var viewResult = controller.CalculateWeeklyBonus(bonus) as ViewResult;
            Bonus calculated = (Bonus)viewResult.ViewData.Model;
            NUnit.Framework.Assert.AreEqual(0, calculated.BonusAmount);

        }


        [TestCase]
        public void Test7_ActionMethod_CalculateWeeklyBonus()
        {
            WeeklyBonusController controller =
                        new WeeklyBonusController();

            Bonus bonus = new Bonus()
            {
                EmpID = 1101,
                EmpName = "Emp1",
                ProjectHours = -5,
                DocumentationHours = -5,
                BonusAmount = 0
            };

            var viewResult = controller.CalculateWeeklyBonus(bonus) as ViewResult;
            Bonus calculated = (Bonus)viewResult.ViewData.Model;
            NUnit.Framework.Assert.AreEqual(0, calculated.BonusAmount);

        }
    }
}

