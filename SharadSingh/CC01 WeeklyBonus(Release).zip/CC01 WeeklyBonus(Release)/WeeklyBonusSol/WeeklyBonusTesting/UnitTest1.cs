using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Diagnostics;
using System.Threading;
using OpenQA.Selenium.Remote;

namespace WeeklyBonus.UITests
{
    [TestFixture]
    class Selenium_Tests : IDisposable
    {
        String test_url = "https://localhost:44327/";
        IWebDriver driver;        

        [SetUp]
        public void start_Browser()
        {         
            // Local Selenium WebDriver
            driver = new ChromeDriver();
            driver.Manage().Window.Maximize();
        }

        [Test]
        public void TestForm()
        {
            driver.Url = test_url;
            System.Threading.Thread.Sleep(2000);
            Assert.AreEqual("WeeklyBonus", driver.Title);

            IWebElement searchText = driver.FindElement(By.Id("EmpID"));
            IWebElement searchText1 = driver.FindElement(By.Id("EmpName"));
            IWebElement searchText2 = driver.FindElement(By.Id("ProjectHours"));
            IWebElement searchText3 = driver.FindElement(By.Id("DocumentationHours"));
            IWebElement searchText4 = driver.FindElement(By.Id("Submit"));
            IWebElement searchText5 = driver.FindElement(By.LinkText("Print Bonus"));

            var links = driver.FindElements(By.TagName("a"));
            Assert.AreEqual("Print Bonus", links[0].Text);
            Console.WriteLine("Test Passed");
        }

        [Test]
        public void TestSubmit_Print_1()
        {
            driver.Url = test_url;
            System.Threading.Thread.Sleep(2000);
            IWebElement searchText4 = driver.FindElement(By.Id("Submit"));
            
            searchText4.Click();
            System.Threading.Thread.Sleep(3000);
            IWebElement searchText6 = driver.FindElement(By.Id("BonusAmount"));
            Assert.IsTrue(searchText6.Text.Contains("Your Bonus Amount: 0"));

            Console.WriteLine("Test Passed");
        }

        [Test]
        public void TestSubmit_Print_2()
        {
            driver.Url = test_url;
            System.Threading.Thread.Sleep(2000);
                        
            IWebElement searchText2 = driver.FindElement(By.Id("ProjectHours"));
            IWebElement searchText3 = driver.FindElement(By.Id("DocumentationHours"));
            searchText2.SendKeys("32");
            searchText3.SendKeys("12");
            IWebElement searchText4 = driver.FindElement(By.Id("Submit"));
            searchText4.Click();
            System.Threading.Thread.Sleep(3000);
            IWebElement searchText6 = driver.FindElement(By.Id("BonusAmount"));
            Assert.IsTrue(searchText6.Text.Contains("Your Bonus Amount: 13700"));

            IWebElement searchText5 = driver.FindElement(By.LinkText("Print Bonus"));
            searchText5.Click();
            System.Threading.Thread.Sleep(3000);

            IWebElement heading = driver.FindElement(By.XPath("//*[text() = 'WeeklyBonus']"));
            IWebElement amount = driver.FindElement(By.XPath("//*[text() = '13700']"));

            Console.WriteLine("Test Passed");
        }

        [Test]
        public void TestSubmit_Print_3()
        {
            driver.Url = test_url;
            System.Threading.Thread.Sleep(2000);

            IWebElement searchText2 = driver.FindElement(By.Id("ProjectHours"));
            IWebElement searchText3 = driver.FindElement(By.Id("DocumentationHours"));
            searchText2.SendKeys("22");
            searchText3.SendKeys("7");
            IWebElement searchText4 = driver.FindElement(By.Id("Submit"));
            searchText4.Click();
            System.Threading.Thread.Sleep(3000);
            IWebElement searchText6 = driver.FindElement(By.Id("BonusAmount"));
            Assert.IsTrue(searchText6.Text.Contains("Your Bonus Amount: 7500"));

            IWebElement searchText5 = driver.FindElement(By.LinkText("Print Bonus"));
            searchText5.Click();
            System.Threading.Thread.Sleep(3000);

            IWebElement heading = driver.FindElement(By.XPath("//*[text() = 'WeeklyBonus']"));
            IWebElement amount = driver.FindElement(By.XPath("//*[text() = '7500']"));

            Console.WriteLine("Test Passed");
        }


        [Test]
        public void TestSubmit_Print_4()
        {
            driver.Url = test_url;
            System.Threading.Thread.Sleep(2000);

            IWebElement searchText2 = driver.FindElement(By.Id("ProjectHours"));
            IWebElement searchText3 = driver.FindElement(By.Id("DocumentationHours"));
            searchText2.SendKeys("21");
            searchText3.SendKeys("11");
            IWebElement searchText4 = driver.FindElement(By.Id("Submit"));
            searchText4.Click();
            System.Threading.Thread.Sleep(3000);
            IWebElement searchText6 = driver.FindElement(By.Id("BonusAmount"));
            Assert.IsTrue(searchText6.Text.Contains("Your Bonus Amount: 8700"));

            IWebElement searchText5 = driver.FindElement(By.LinkText("Print Bonus"));
            searchText5.Click();
            System.Threading.Thread.Sleep(3000);

            IWebElement heading = driver.FindElement(By.XPath("//*[text() = 'WeeklyBonus']"));
            IWebElement amount = driver.FindElement(By.XPath("//*[text() = '8700']"));

            Console.WriteLine("Test Passed");
        }

        [TearDown]
        public void close_Browser()
        {
            driver.Quit();
            Console.WriteLine("Test Finished");
        }

        public void Dispose()
        {
            driver.Dispose();
        }
    }
}


