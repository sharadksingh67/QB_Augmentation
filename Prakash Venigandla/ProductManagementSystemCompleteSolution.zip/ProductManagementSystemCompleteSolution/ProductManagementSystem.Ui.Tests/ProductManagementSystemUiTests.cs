﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using Xunit;

namespace ProductManagementSystem.Ui.Tests
{
    public sealed class ProductManagementSystemTests : IDisposable
    {
        private readonly IWebDriver _driver;


        public ProductManagementSystemTests()
        {
            _driver = new ChromeDriver();
        }

        [Fact]
        public void Test_Index()
        {
            _driver.Navigate().GoToUrl("http://localhost:49373/product/index");

            Assert.Equal("Index - Product Management System Application", _driver.Title);
            var links =
                _driver.FindElements(By.TagName("a"));


            Assert.Equal("Product Management System", links[0].Text);

            Assert.Equal("Product List", links[1].Text);

            Assert.Equal("Create New", links[2].Text);

        }

        [Fact]
        public void Test_Details()
        {
            _driver.Navigate().GoToUrl("http://localhost:49373/Product/Details/1");

            Assert.Equal("Details - Product Management System Application", _driver.Title);
            var links =
                _driver.FindElements(By.TagName("a"));


            Assert.Equal("Back to List", links[2].Text);
            var h4Element =
                _driver.FindElement(By.TagName("h4"));
            Assert.Equal("Product added successfully!", h4Element.Text);


        }

        [Fact]
        public void Test_AddProduct_RequiredFields()
        {
            _driver.Navigate().GoToUrl("http://localhost:49373/product/addproduct");

            // Don't enter a name

            _driver.FindElement(By.Id("addProduct")).Click();

            IWebElement nameErrorMessage =
                _driver.FindElement(By.ClassName("text-danger"));

            Assert.Equal("Please provide product name", nameErrorMessage.Text);


        }

        [Fact]
        public void Test_AddProduct_ValidData()
        {
            _driver.Navigate().GoToUrl("http://localhost:49373/Product/addProduct");

            // enter a name
            _driver.FindElement(By.ClassName("text-box")).SendKeys("Amul high aroma cow ghee");

            _driver.FindElement(By.Id("addProduct")).Click();
            try
            {
                IWebElement nameErrorMessage =
                    _driver.FindElement(By.ClassName("text-danger"));


            }
            catch (Exception)
            {
                Assert.False(false);
            }
        }

        public void Dispose()
        {
            _driver.Quit();
            _driver.Dispose();
        }
    }
}
