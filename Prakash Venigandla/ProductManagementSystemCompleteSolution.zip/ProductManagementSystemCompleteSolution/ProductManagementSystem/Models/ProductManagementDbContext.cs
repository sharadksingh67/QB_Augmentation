﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.ModelConfiguration.Conventions;
using System.Linq;
using System.Web;

namespace ProductManagementSystem.Models
{
    public class ProductManagementDbContext: DbContext
    {
        public DbSet<Product> Products { get; set; }
        public ProductManagementDbContext() : base("PMS_DB")
        {

        }
        
    }
}