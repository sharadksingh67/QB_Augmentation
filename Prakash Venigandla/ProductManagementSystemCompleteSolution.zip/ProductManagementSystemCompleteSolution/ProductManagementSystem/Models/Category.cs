﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ProductManagementSystem.Models
{
    public enum Category
    {
        None,
        Electronics,
        Stationary,
        Fashion,
        Kitchen,
        Health,
        Grocery,
        Toys,
        Books,
        Home


    }
}