﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace ProductManagementSystem.Models
{
    public class Product
    {
        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage = "Please provide product name")]
        [MaxLength(255)]
        public string Name { get; set; }

        [Required(ErrorMessage = "Please provide product price")]
        [Range(1,500000,ErrorMessage ="Please Provide a valid price between Rs.1 to Rs.5,00,000")]
        public int? Price { get; set; }

        [Required(ErrorMessage = "Please provide valid manufacturing date")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yy}", ApplyFormatInEditMode = true)]
        public DateTime? MfgDate { get; set; }

        [Required(ErrorMessage = "Please provide best before")]
        [Display(Name = "Best Before")]
        public string BestBefore { get; set; }

        [Required(ErrorMessage = "Please select product category")]
        [Display(Name = "Product Category")]
        public Category ProductCategory { get; set; }

        [MaxLength(500)]
        public string Description { get; set; }

        
    }
}