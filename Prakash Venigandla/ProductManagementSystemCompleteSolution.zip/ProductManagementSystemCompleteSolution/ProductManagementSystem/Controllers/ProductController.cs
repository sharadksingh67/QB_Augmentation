﻿using ProductManagementSystem.CustomFilters;
using ProductManagementSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
namespace ProductManagementSystem.Controllers
{
    [CustomExceptionFilter]
    public class ProductController : Controller
    {


        public static ProductManagementDbContext db;
        [HttpGet]
        public ActionResult Index()
        {

            db = new ProductManagementDbContext();
            ViewBag.Message = "This is Index Action";
            var model = db.Products;
            return View(model);

        }

        [HttpGet]
        public ActionResult Details(int id)
        {
            db = new ProductManagementDbContext();
            var model = db.Products.Where(p => p.Id == id).FirstOrDefault();
            return View(model);

        }

        [HttpGet]
        public ActionResult AddProduct()
        {
            return View();
        }

        [HttpPost]
        public ActionResult AddProduct(Product product)
        {
            db = new ProductManagementDbContext();
            if (ModelState.IsValid)
            {
                db.Products.Add(product);
                db.SaveChanges();
                return RedirectToAction("Details", new { id = product.Id });
            }
            return View();

        }


    }
}