﻿// NUnit 3 tests
// See documentation : https://github.com/nunit/docs/wiki/NUnit-Documentation
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Globalization;
using System.Linq;
using System.Web.Mvc;
using NUnit.Framework;
using ProductManagementSystem.Controllers;
using ProductManagementSystem.Models;

namespace ProductManagementSystem.NUnit.Tests
{
    [TestFixture]
    class ProductControllerTests
    {
        [Test]
        public void TestIndexAction_ReturnProductList()
        {
            //Arrange
            var productController = new ProductController();
            ProductManagementDbContext db = new ProductManagementDbContext();

            //Act
            var viewResult = productController.Index() as ViewResult;
            var products = (IEnumerable<Product>)viewResult.ViewData.Model;

            //Assert
            try
            {
                Assert.AreEqual(db.Products.ToList().Count, products.ToList().Count);
            }
            catch (Exception)
            {
                Assert.Fail("Exception should not be thrown. Please check the application logic");
            }
        }

        [Test]
        public void TestAddProductAction_CategoryDefaultValue()
        {
            //Arrange
            var productController = new ProductController();
            ProductManagementDbContext db = new ProductManagementDbContext();
            Product product = new Product();
            product.Name = "Amul Butter 500g";
            //ProductCategory default value "None"
            product.Price = 240;
            product.MfgDate = DateTime.Today;
            product.BestBefore = "45 Days";
            product.Description = "Spread on Bread, Parantha, Roti, Nans, Sandwiches";

            //Act
            var result = (RedirectToRouteResult)productController.AddProduct(product);


            try
            {
                //Assert
                Assert.AreEqual(result.RouteValues["action"], "Details");
            }
            catch (Exception)
            {
                //Assert
                Assert.Fail("Adding new product to the database failed. Please check the application logic");
            }


        }

        [Test]
        public void TestAddProductAction_SavesToDatabase_ValidModel()
        {
            //Arrange
            var productController = new ProductController();
            ProductManagementDbContext db = new ProductManagementDbContext();
            Product product = new Product();
            product.Name = "Nutella 750g";
            product.ProductCategory = Category.Grocery;
            product.Price = 749;
            product.MfgDate = DateTime.Today;
            product.BestBefore = "3 Months";
            product.Description = "Spread on Bread, Parantha, Roti, Nans, Sandwiches";


            //Act
            var result = (RedirectToRouteResult)productController.AddProduct(product);


            try
            {
                //Assert
                Assert.AreEqual(result.RouteValues["action"].Equals("Details"), true);
            }
            catch (Exception)
            {
                Assert.Fail("Adding new product to the database failed.Exception should not be thrown. Please provide all mandatory fields valid data.");
            }


        }

        [Test]
        public void TestAddProductAction_NameNull()
        {
            //Arrange
            var productController = new ProductController();

            ProductManagementDbContext db = new ProductManagementDbContext();
            Product product = new Product
            {
                Name=null,
                ProductCategory = Category.Grocery,
                MfgDate = DateTime.Today,
                Price = 200,
                BestBefore = "2 Months",
                Description = "A unique and unbeatable taste"
            };

            //Init ModelState
            var modelBinder = new ModelBindingContext()
            {
                ModelMetadata = ModelMetadataProviders.Current.GetMetadataForType(
                                  () => product, product.GetType()),
                ValueProvider = new NameValueCollectionValueProvider(
                                    new NameValueCollection(), CultureInfo.InvariantCulture)
            };
            var binder = new DefaultModelBinder().BindModel(
                             new ControllerContext(), modelBinder);
            productController.ModelState.Clear();
            productController.ModelState.Merge(modelBinder.ModelState);

            try
            {
                //Act
                var viewRresult = productController.AddProduct(product) as ViewResult;
                //Assert
                Assert.AreNotEqual(viewRresult.ViewName, "Details");


            }
            catch (Exception)
            {
                //Assert
                Assert.Fail("Adding product to the database failed. Name can't be empty, please provide valid data for Name");
            }



        }

        [Test]
        public void TestAddProductAction_PriceNull()
        {
            //Arrange
            var productController = new ProductController();

            ProductManagementDbContext db = new ProductManagementDbContext();
            Product product = new Product
            {
                Name = "Sundrop Peanut Butter",
                ProductCategory = Category.Grocery,
                MfgDate = DateTime.Today,
                Price = null,
                BestBefore = "2 Months",
                Description = "A unique and unbeatable taste"
            };

            //Init ModelState
            var modelBinder = new ModelBindingContext()
            {
                ModelMetadata = ModelMetadataProviders.Current.GetMetadataForType(
                                  () => product, product.GetType()),
                ValueProvider = new NameValueCollectionValueProvider(
                                    new NameValueCollection(), CultureInfo.InvariantCulture)
            };
            var binder = new DefaultModelBinder().BindModel(
                             new ControllerContext(), modelBinder);
            productController.ModelState.Clear();
            productController.ModelState.Merge(modelBinder.ModelState);

            try
            {
                //Act
                var viewRresult = productController.AddProduct(product) as ViewResult;
                //Assert
                Assert.AreNotEqual(viewRresult.ViewName, "Details");


            }
            catch (Exception)
            {
                //Assert
                Assert.Fail("Adding product to the database failed. Name can't be empty, please provide valid data for Name");
            }



        }

        [Test]
        public void TestAddProductAction_BestBeforeNull()
        {
            //Arrange
            var productController = new ProductController();

            ProductManagementDbContext db = new ProductManagementDbContext();
            Product product = new Product
            {
                Name = "Karachi Premium Cashew Biscuits",
                ProductCategory = Category.Grocery,
                MfgDate = DateTime.Today,
                Price = 190,
                BestBefore = null,
                Description = "A unique and unbeatable taste"
            };

            //Init ModelState
            var modelBinder = new ModelBindingContext()
            {
                ModelMetadata = ModelMetadataProviders.Current.GetMetadataForType(
                                  () => product, product.GetType()),
                ValueProvider = new NameValueCollectionValueProvider(
                                    new NameValueCollection(), CultureInfo.InvariantCulture)
            };
            var binder = new DefaultModelBinder().BindModel(
                             new ControllerContext(), modelBinder);
            productController.ModelState.Clear();
            productController.ModelState.Merge(modelBinder.ModelState);

            try
            {
                //Act
                var viewRresult = productController.AddProduct(product) as ViewResult;
                //Assert
                Assert.AreNotEqual(viewRresult.ViewName, "Details");


            }
            catch (Exception)
            {
                //Assert
                Assert.Fail("Adding product to the database failed. Name can't be empty, please provide valid data for Name");
            }



        }

        [Test]
        public void TestAddProductAction_MfgDateNull()
        {
            //Arrange
            var productController = new ProductController();
            ProductManagementDbContext db = new ProductManagementDbContext();
            Product product = new Product();
            product.Name = "Horlicks";
            product.ProductCategory = Category.Health;
            //don't provide value for MfgDate field
            product.MfgDate = null;
            product.Price = 200;
            product.Description = "Health Drink that has nutrients to support immunity";
            product.BestBefore = "24 Months";
            //Init ModelState
            var modelBinder = new ModelBindingContext()
            {
                ModelMetadata = ModelMetadataProviders.Current.GetMetadataForType(
                                  () => product, product.GetType()),
                ValueProvider = new NameValueCollectionValueProvider(
                                    new NameValueCollection(), CultureInfo.InvariantCulture)
            };
            var binder = new DefaultModelBinder().BindModel(
                             new ControllerContext(), modelBinder);
            productController.ModelState.Clear();
            productController.ModelState.Merge(modelBinder.ModelState);

            try
            {
                //Act
                var viewResult = productController.AddProduct(product) as ViewResult;
                //Assert
                Assert.AreNotEqual(viewResult.ViewName, "Details");
            }
            catch (Exception)
            {
                //Assert
                Assert.Fail("Adding product to the database failed. Launch date should not be blank, please provide valid data.");
            }

        }

        [Test]
        public void TestAddProductAction_IdAutoGenerated()
        {
            var productController = new ProductController();
            ProductManagementDbContext db = new ProductManagementDbContext();
            Product product = new Product();
            product.Name = "Horlicks";
            product.ProductCategory = Category.Health;
            product.MfgDate = DateTime.Today;
            product.Price = 200;
            product.Description = "Health Drink that has nutrients to support immunity";
            product.BestBefore = "24 Months";

            //Act
            try
            {
                int maxIdBefore = db.Products.Max(r => r.Id);
                var result = (RedirectToRouteResult)productController.AddProduct(product);
                int maxIdAfter = db.Products.Max(r => r.Id);


                //Assert

                Assert.AreEqual(maxIdBefore + 1, maxIdAfter);
            }
            catch (Exception)
            {
                Assert.Fail("Adding new product to the database failed.Id should be auto generated. Please check the database scheme, ensure identity function specified on Id column");
            }

        }

        [Test]
        public void TestDetailsAction_ForValidId()
        {
            //Arrange
            var productController = new ProductController();
            ProductManagementDbContext db = new ProductManagementDbContext();
            int validId = db.Products.Max(p => p.Id);//getting valid max id
            //Act

            var viewResult = productController.Details(validId) as ViewResult;
            var product = (Product)viewResult.ViewData.Model;

            //Assert
            try
            {
                Assert.NotNull(product);
            }
            catch (Exception)
            {
                Assert.Fail("No such product, please provide a valid product id.");
            }
        }

        [Test]
        public void TestDetailsAction_ForInvalidId()
        {
            //Arrange
            var productController = new ProductController();
            ProductManagementDbContext db = new ProductManagementDbContext();
            int validId = db.Products.Max(p => p.Id);//getting valid max id
            int invalidId = validId += 5000;//adding 5000 to valid id to make it invalid to test

            //Act
            var viewResult = productController.Details(invalidId) as ViewResult;
            var product = (Product)viewResult.ViewData.Model;

            //Assert
            try
            {
                Assert.Null(product);
            }
            catch (Exception)
            {
                Assert.Fail("Invalid id, please provide a valid product id");
            }
        }

        [Test]
        public void TestAddProductAction_InitalizesDbContext()
        {
            //Arrange
            var productController = new ProductController();


            //Act
            var viewResult = productController.AddProduct(
                new Product
                {
                    Name = "Colgate Toothpaste",
                    ProductCategory = Category.Grocery,
                    MfgDate = DateTime.Today,
                    Price = 55,
                    BestBefore = "48 Months",
                    Description = "12 hour protection",
                }) as ViewResult;



            try
            {

                //Assert

                Assert.NotNull(ProductController.db);
            }
            catch (Exception)
            {
                Assert.Fail("Database creation failed, please check the connection string");
            }
        }

    }
}

    
    