﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
//DO NOT MODIFY ANYTHING HERE 
namespace ProductManagementSystem.Models
{
    /// <summary>
    /// Category enum 
    /// </summary>
    public enum Category
    {
        None,
        Electronics,
        Stationary,
        Fashion,
        Kitchen,
        Health,
        Grocery,
        Toys,
        Books,
        Home


    }
}