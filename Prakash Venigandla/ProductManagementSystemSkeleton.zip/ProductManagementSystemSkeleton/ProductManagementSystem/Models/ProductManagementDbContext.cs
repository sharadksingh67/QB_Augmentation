﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.ModelConfiguration.Conventions;
using System.Linq;
using System.Web;
//DO NOT MODIFY THE NAMESPACEv
namespace ProductManagementSystem.Models
{
    public class ProductManagementDbContext: DbContext
    {
        //code goes here
        public DbSet<Product> Products { get; set; }

        /// <summary>
        /// Constructor to initialize   ProductManagementDbContext object
        /// </summary>
        public ProductManagementDbContext() : base("PMS_DB")
        {
            //no code here
        }

    }
}