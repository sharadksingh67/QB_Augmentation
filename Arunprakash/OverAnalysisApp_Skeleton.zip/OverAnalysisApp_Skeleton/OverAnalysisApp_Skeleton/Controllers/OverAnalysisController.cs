﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using OverAnalysisApp_Skeleton.Models;

namespace OverAnalysisApp_Skeleton.Controllers
{
    public class OverAnalysisController : Controller
    {
        OverAnalysisContext db = new OverAnalysisContext();

        public ActionResult OverAnalysisReport()
        {
            /* Implement the code for displaying Over Analysis Report by
             * retrieving over analysis details of Total Runs and Extras for each over
             * using group by 'Overs' column from the 'OverAnalysis' table in the database
             * 
             */
        }
        public ActionResult CreateOverAnalysis()
        {
            /* Implement the code for creating view page for inputting
             * BallType of 'No Ball' / 'Wide Ball' / 'Right Ball' and
             * RunsTaken for each ball.
             * BallType should created as DropDownList in the view page.
             * The 'Overs' column should be displayed automatically. 'Overs' should be incremented
             * for every 6 records.
             * 
             */
        }

        [HttpPost]
        public ActionResult CreateOverAnalysis(OverAnalysis overanalysis)
        {
            /* Implement the code for saving the over analysis input details
             * from the 'CreateOverAnalysis' view page.
             * Saving the over analysis details into the 'OverAnalysis' table of
             * the database should be done after validating the RunsTaken input
             * field. The validatiion rules has been specified in entity as Range
             * attribute definition using data annotation for RunsTaken property.
             * 
             */
        }
    }
}