﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.InteropServices;
using System.Web;

namespace OverAnalysisApp_Skeleton.Models
{
    public class OverAnalysis
    {
        public int Id { get; set; }

        public int Overs { get; set; }
        public string BallType { get; set; }

        [Range(1,7,ErrorMessage = "Runs Taken should be between 1 and 7")]
        public int RunsTaken { get; set; }
    }
}