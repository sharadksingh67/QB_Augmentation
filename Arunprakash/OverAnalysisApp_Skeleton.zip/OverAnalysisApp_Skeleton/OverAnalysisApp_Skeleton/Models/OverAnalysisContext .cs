﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Data.Entity.ModelConfiguration.Conventions;

namespace OverAnalysisApp_Skeleton.Models
{
    public class OverAnalysisContext  : DbContext
    {
        public OverAnalysisContext()
            : base("OverAnalysisDB")
        {
        }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();
        }

        public virtual DbSet<OverAnalysis> OverAnalysis { get; set; }
    }
}