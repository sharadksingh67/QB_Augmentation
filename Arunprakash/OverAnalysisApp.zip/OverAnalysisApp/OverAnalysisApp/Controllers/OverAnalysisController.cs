﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using OverAnalysisApp.Models;

namespace OverAnalysisApp.Controllers
{
    public class OverAnalysisController : Controller
    {
        OverAnalysisContext db = new OverAnalysisContext();

        public ActionResult OverAnalysisReport()
        {
            var overanalysisquery = from ov in db.OverAnalysis
                                    group ov by ov.Overs into ovgroup
                                    select ovgroup;
            
            return View(overanalysisquery);
        }
        public ActionResult CreateOverAnalysis()
        {
            List<string> balltypes = new List<string>();
            balltypes.Add("No Ball");
            balltypes.Add("Wide Ball");
            balltypes.Add("Right Ball");
            ViewBag.BallTypes = new SelectList(balltypes);
            OverAnalysis overanalysis = new OverAnalysis();
            int overanalysiscount = db.OverAnalysis.Count();
            int over = 1;
            if (overanalysiscount > 0)
            {
                over = (int)(overanalysiscount / 6) + 1;
            }
            overanalysis.Overs = over;
            return View(overanalysis);
        }

        [HttpPost]
        public ActionResult CreateOverAnalysis(OverAnalysis overanalysis)
        {
            if (ModelState.IsValid)
            {
                if (overanalysis.BallType == "No Ball" || overanalysis.BallType == "Wide Ball")
                {
                    overanalysis.RunsTaken = 1;
                }
                int overanalysiscount = db.OverAnalysis.Count();
                int over = 1;
                if (overanalysiscount > 0)
                {
                    over = (int)(overanalysiscount / 6) + 1;
                }
                overanalysis.Overs = over;
                db.OverAnalysis.Add(overanalysis);
                db.SaveChanges();
                return RedirectToAction("OverAnalysisReport");
            }
            else
            {
                List<string> balltypes = new List<string>();
                balltypes.Add("No Ball");
                balltypes.Add("Wide Ball");
                balltypes.Add("Right Ball");
                ViewBag.BallTypes = new SelectList(balltypes);
                int overanalysiscount = db.OverAnalysis.Count();
                int over = 1;
                if (overanalysiscount > 0)
                {
                    over = (int)(overanalysiscount / 6) + 1;
                }
                overanalysis.Overs = over;
                return View();
            }
        }
    }
}