﻿using System;
using NUnit.Framework;
using OpenQA.Selenium;

namespace OverAnalysisApp.UITest
{
    [TestFixture]
    public class OverAnalysisAppTest : SeleniumTest
    {
        public OverAnalysisAppTest() : base("OverAnalysisApp")
        {
        }

        [Test]
        public void Test_OverAnalysisReport()
        {
            WebDriver.Navigate().GoToUrl(GetAbsoluteUrl(@"OverAnalysis/OverAnalysisReport"));
            Assert.AreEqual("OverAnalysisReport - OverAnalysis Application", WebDriver.Title);
            var links =
                WebDriver.FindElements(By.TagName("a"));
            Assert.AreEqual("OverAnalysis Application", links[0].Text);
            Assert.AreEqual("Over Analysis Report", links[1].Text);
            Assert.AreEqual("Add OverAnalysis", links[2].Text);
        }

        [Test]
        public void Test_CreateOverAnalysis_RequiredFields()
        {
            WebDriver.Navigate().GoToUrl(GetAbsoluteUrl(@"OverAnalysis/CreateOverAnalysis"));

            // Don't enter / select inputs
            WebDriver.FindElement(By.Id("addOverAnalysis")).Click();
            foreach (IWebElement iw in WebDriver.FindElements(By.ClassName("text-danger")))
            {
                try
                {
                    if (iw.Text.Length > 0)
                    {
                        Assert.AreEqual("Runs Taken should be between 1 and 7", iw.Text);
                    }
                }
                catch { }
            }
        }

        [Test]
        public void Test_CreateOverAnalysis_ValidData()
        {
            WebDriver.Navigate().GoToUrl(GetAbsoluteUrl(@"OverAnalysis/CreateOverAnalysis"));

            // Enter Runs Taken
            WebDriver.FindElement(By.Id("RunsTaken")).SendKeys("5");

            WebDriver.FindElement(By.Id("addOverAnalysis")).Click();
            try
            {
                IWebElement nameErrorMessage =
                    WebDriver.FindElement(By.ClassName("text-danger"));
            }
            catch (Exception)
            {
                Assert.IsFalse(false);
            }
        }

    }
}
