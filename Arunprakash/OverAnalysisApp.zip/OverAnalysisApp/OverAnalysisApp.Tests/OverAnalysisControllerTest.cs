﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Web.Mvc;
using NUnit.Framework;
using OverAnalysisApp;
using OverAnalysisApp.Models;

namespace OverAnalysisApp.Tests
{
    [TestFixture]
    public class OverAnalysisControllerTest
    {
        Assembly assembly;
        Type OverAnalysisControllerClass;

        [SetUp]
        public void Setup()
        {
            assembly = Assembly.Load("OverAnalysisApp");
        }

        [Test]
        public void TestOverAnalysisReport_ReturnOverAnalysisList()
        {
            var allBindings = BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;
            OverAnalysisContext db = new OverAnalysisContext();

            try
            {
                OverAnalysisControllerClass = assembly.GetType("OverAnalysisApp.Controllers.OverAnalysisController");
                if (OverAnalysisControllerClass != null)
                {
                    MethodInfo OverAnalysisReportMethod = OverAnalysisControllerClass.GetMethod("OverAnalysisReport", allBindings);
                    Assert.IsNotNull(OverAnalysisReportMethod, "Action 'OverAnalysisReport' NOT implemented OR check spelling");
                    Assert.AreEqual(typeof(ActionResult), OverAnalysisReportMethod.ReturnType, "Action 'OverAnalysisReport' return type MUST be 'ActionResult'");

                    ConstructorInfo classConstructor = OverAnalysisControllerClass.GetConstructor(Type.EmptyTypes);
                    object classObject = classConstructor.Invoke(new object[] { });

                    var viewResult = (ViewResult)OverAnalysisReportMethod.Invoke(classObject, new object[] { });
                    var overanalysisGroup = (IEnumerable<IGrouping<int,OverAnalysis>>)viewResult.ViewData.Model;
                    int overanalysisGroupCount = (from ov in db.OverAnalysis
                                            group ov by ov.Overs into ovgroup
                                            select ovgroup).Count();

                    Assert.AreEqual(overanalysisGroup.Count(), overanalysisGroupCount);
                }
                else
                    Assert.Fail("No class with the name 'OverAnalyzeController' is implemented OR Did you change the class name");
            }
            catch (Exception ex)
            {
                Assert.Fail("Exception should not be thrown. Please check the application logic");
            }
        }

        [Test]
        public void TestCreateOverAnalysis_SavesToDatabase()
        {
            //Arrange
            var allBindings = BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;
            OverAnalysis overanalysis = new OverAnalysis
            {
                BallType = "Right Ball",
                RunsTaken = 5
            };
            try
            {
                OverAnalysisControllerClass = assembly.GetType("OverAnalysisApp.Controllers.OverAnalysisController");
                if (OverAnalysisControllerClass != null)
                {
                    MethodInfo[] AllMethods = OverAnalysisControllerClass.GetMethods(allBindings);
                    MethodInfo CreateOverAnalysisMethod = null;
                    foreach (MethodInfo info in AllMethods)
                    {
                        if (info.Name == "CreateOverAnalysis")
                        {
                            if (info.CustomAttributes.Count() > 0 &&
                                info.CustomAttributes.FirstOrDefault().AttributeType.Equals(typeof(HttpPostAttribute)))
                            {
                                CreateOverAnalysisMethod = info;
                            }
                        }

                    }
                    Assert.IsNotNull(CreateOverAnalysisMethod, "Action 'CreateOverAnalysis' NOT implemented OR check spelling");
                    ConstructorInfo classConstructor = OverAnalysisControllerClass.GetConstructor(Type.EmptyTypes);
                    object classObject = classConstructor.Invoke(new object[] { });
                    //Act
                    var result = (RedirectToRouteResult)CreateOverAnalysisMethod.Invoke(classObject, new object[] { overanalysis });

                    //Assert
                    Assert.AreEqual(result.RouteValues["action"].Equals("OverAnalysisReport"), true);

                }
                else
                    Assert.Fail("No class with the name 'OverAnalysisController' is implemented OR Did you change the class name");

            }
            catch (Exception ex)
            {
                Assert.Fail("Adding OverAnalysis details to the database failed. Exception should not be thrown. Please provide all mandatory fields valid data and check the destination action name.");
            }
        }

        [Test]
        public void TestCreateOverAnalysis_TotalRunsNull()
        {
            //Arrange
            var allBindings = BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;
            OverAnalysisContext db = new OverAnalysisContext();
            OverAnalysis overanalysis = new OverAnalysis
            {
                BallType = "Right Ball",
                RunsTaken = 0
            };

            //Init ModelState
            var modelBinder = new ModelBindingContext()
            {
                ModelMetadata = ModelMetadataProviders.Current.GetMetadataForType(
                                  () => overanalysis, overanalysis.GetType()),
                ValueProvider = new NameValueCollectionValueProvider(
                                    new NameValueCollection(), CultureInfo.InvariantCulture),
                ModelState = new ModelStateDictionary()
            };
            var binder = new DefaultModelBinder().BindModel(
                             new ControllerContext(), modelBinder);

            try
            {
                OverAnalysisControllerClass = assembly.GetType("OverAnalysisApp.Controllers.OverAnalysisController");
                if (OverAnalysisControllerClass != null)
                {
                    MethodInfo[] AllMethods = OverAnalysisControllerClass.GetMethods(allBindings);
                    MethodInfo CreateOverAnalysisMethod = null;
                    foreach (MethodInfo info in AllMethods)
                    {
                        if (info.Name == "CreateOverAnalysis")
                        {
                            if (info.CustomAttributes.Count() > 0 &&
                                info.CustomAttributes.FirstOrDefault().AttributeType.Equals(typeof(HttpPostAttribute)))
                            {
                                CreateOverAnalysisMethod = info;
                            }
                        }

                    }
                    Assert.IsNotNull(CreateOverAnalysisMethod, "Action 'CreateOverAnalysis' NOT implemented OR check spelling");

                    ConstructorInfo classConstructor = OverAnalysisControllerClass.GetConstructor(Type.EmptyTypes);
                    object classObject = classConstructor.Invoke(new object[] { });

                    ((Controller)classObject).ModelState.Clear();
                    ((Controller)classObject).ModelState.Merge(modelBinder.ModelState);

                    string errorMessage = "Runs Taken should be between 1 and 7";
                    var ctx = new ValidationContext(overanalysis);
                    var results = new List<ValidationResult>();
                    if (!Validator.TryValidateObject(overanalysis, ctx, results, true))
                    {
                        foreach (ValidationResult vr in results)
                        {
                            if (vr.ErrorMessage == errorMessage)
                            {
                                Assert.IsTrue(vr.ErrorMessage.Equals(errorMessage));
                            }
                        }
                    }

                }
                else
                    Assert.Fail("No class with the name 'OverAnalysisController' is implemented OR Did you change the class name");
            }
            catch (Exception ex)
            {
                Assert.Fail("Adding OverAnalysis details to the database failed. Exception should not be thrown. Please provide all mandatory fields valid data and check the destination action name.");
            }
        }

        [Test]
        public void TestCreateOverAnalysis_InitalizesDbContext()
        {
            var allBindings = BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;
            OverAnalysisContext db = new OverAnalysisContext();

            try
            {
                OverAnalysisControllerClass = assembly.GetType("OverAnalysisApp.Controllers.OverAnalysisController");
                if (OverAnalysisControllerClass != null)
                {
                    ConstructorInfo classConstructor = OverAnalysisControllerClass.GetConstructor(Type.EmptyTypes);
                    object classObject = classConstructor.Invoke(new object[] { });

                    Assert.IsNotNull(db);
                }
                else
                    Assert.Fail("No class with the name 'OverAnalysisController' is implemented OR Did you change the class name");
            }
            catch (Exception ex)
            {
                Assert.Fail("Adding OverAnalysis details to the database failed. Exception should not be thrown. Please provide all mandatory fields valid data and check the destination action name.");
            }
        }

    }
}
