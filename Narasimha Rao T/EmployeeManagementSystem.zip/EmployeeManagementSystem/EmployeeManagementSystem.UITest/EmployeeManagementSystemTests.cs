﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;


namespace EmployeeManagementSystem.UITest
{
    public class EmployeeManagementSystemTests : IDisposable
    {
        private readonly IWebDriver _driver;

        public EmployeeManagementSystemTests()
        {
            _driver = new ChromeDriver();
        }

        [Fact]
        public void Test_Index()
        {
            _driver.Navigate().GoToUrl("http://localhost:3500/Employee/Index");

            Assert.Equal("Index - Employee Management Application", _driver.Title);
            var links =
                _driver.FindElements(By.TagName("a"));


            Assert.Equal("Employee Management System", links[0].Text);

            Assert.Equal("Create New", links[1].Text);
        }


        [Fact]
        public void Test_Details()
        {
            _driver.Navigate().GoToUrl("http://localhost:3500/Employee/Details/1");

            Assert.Equal("Details - Employee Management Application", _driver.Title);
            var links =
                _driver.FindElements(By.TagName("a"));

            Assert.Equal("Back to List", links[1].Text);  
        }

        [Fact]
        public void Test_Create_RequiredFields()
        {
            _driver.Navigate().GoToUrl("http://localhost:3500/Employee/Create");

            // Don't enter a name
            _driver.FindElement(By.Id("createEmployee")).Click();

            IWebElement nameErrorMessage =
                _driver.FindElement(By.ClassName("text-danger"));

            Assert.Equal("Please Provide Employee Name", nameErrorMessage.Text);
        }

        [Fact]
        public void Test_Delete()
        {
            _driver.Navigate().GoToUrl("http://localhost:3500/Employee/Delete/1");

            Assert.Equal("Delete - Employee Management Application", _driver.Title);

            var links =
                _driver.FindElements(By.TagName("a"));

            Assert.Equal("Back to List", links[1].Text);
                      

            var headings =
                _driver.FindElements(By.TagName("h3"));
            Assert.Equal("Are you sure you want to delete this employee?", headings[0].Text);

        }



        public void Dispose()
        {
            _driver.Quit();
            _driver.Dispose();
        }
    }
}
