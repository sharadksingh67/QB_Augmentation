﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EmployeeManagementSystem.Models;

namespace EmployeeManagementSystem.Controllers
{
    public class EmployeeController : Controller
    {
        // DataContext Class Name
       public EmployeeManagementDbContext context = new EmployeeManagementDbContext();

        public ActionResult Index()
        {
            List<Employee> empList = context.Employees.ToList();
            return View(empList);
        }

        public ActionResult Details(int id)
        {
            Employee obj = context.Employees.Find(id);
            return View(obj);
        }

        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Create(Employee obj)
        {         
            if(ModelState.IsValid == true)
            {
                context.Employees.Add(obj);
                context.SaveChanges();
                return RedirectToAction("Index");
            }
           else
            {
                return View();
            }                    
        }

        public ActionResult Delete(int id)
        {
            Employee obj = context.Employees.Find(id);
            return View(obj);
        }

        [HttpPost]
        public ActionResult Delete(string id)
        {
            Employee obj = context.Employees.Find(int.Parse(id));
            context.Employees.Remove(obj);
            context.SaveChanges();
            return RedirectToAction("Index");
        }     

    }
}
