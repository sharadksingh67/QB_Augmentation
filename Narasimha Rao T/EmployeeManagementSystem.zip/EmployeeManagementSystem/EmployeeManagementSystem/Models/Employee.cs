﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace EmployeeManagementSystem.Models
{
    public class Employee
    { 
            [Key]
            public int Empno { get; set; }

        
            [Required(ErrorMessage = "Please Provide Employee Name")]
            [MaxLength(255)]
            public string Ename { get; set; }

            [Required(ErrorMessage = "Please Provide Employee Job")]
            [MaxLength(255)]
            public string Job { get; set; }
                      
            [Required]
            public double Salary { get; set; }

        [Required]
            public int Deptno { get; set; } 
       
    }
}