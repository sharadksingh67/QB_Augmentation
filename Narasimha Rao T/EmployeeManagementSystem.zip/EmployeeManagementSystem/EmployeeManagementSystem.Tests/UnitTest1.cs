﻿using System;
using NUnit.Framework;
using System.Reflection;

namespace EmployeeManagementSystem.Tests
{
    [TestFixture]
    public class UnitTest1
    {
        [Test]
        public void TestMethod1()
        {
            try
            {  
                Assert.AreEqual(5, 5);
            }
            catch (Exception)
            {
                Assert.Fail("Exception should not be thrown. Please check the application logic");
            }
        }
    }
}
