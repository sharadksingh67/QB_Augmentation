﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EmployeeManagementSystem.Models;

namespace EmployeeManagementSystem.Controllers  // DO NOT change the namespace name
{
    public class EmployeeController : Controller    // DO NOT change the class name
    {
        // DataContext Class Name
       public EmployeeManagementDbContext context = new EmployeeManagementDbContext();

        // Add required action methods with corresponding logic

        public ActionResult Index()
        {

            return View();
        }     

    }
}
