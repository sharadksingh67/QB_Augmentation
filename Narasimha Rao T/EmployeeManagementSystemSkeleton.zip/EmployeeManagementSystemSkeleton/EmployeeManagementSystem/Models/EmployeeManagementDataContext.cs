﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;

namespace EmployeeManagementSystem.Models   // DO NOT change the namespace name
{
    // DO NOT change the class name
    public class EmployeeManagementDbContext :  DbContext  
    {
        // DO NOT change the code in this class
        public DbSet<Employee> Employees{ get; set; }

        public EmployeeManagementDbContext()
            : base("EmployeeConnection")
        {

        }
    }
}
