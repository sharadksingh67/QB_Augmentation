﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace EmployeeManagementSystem.Models   // DO NOT change the namespace name
{
    public class Employee     // DO NOT change the class name
    {
        // Prepare required properties
        // Apply required attributes on the properties to perform validations       
    }
}